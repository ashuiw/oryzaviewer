package com.ashuiw.oryzaviewer.ui.screen

import android.app.Activity
import android.content.Intent
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.derivedStateOf
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.width
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListLayoutInfo
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import com.kyant.backdrop.drawBackdrop
import androidx.compose.animation.core.animateFloat
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.union
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.runtime.snapshotFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import com.ashuiw.oryzaviewer.ui.theme.LiquidGlassColors
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.ashuiw.oryzaviewer.R
import com.ashuiw.oryzaviewer.data.repository.AppSettingsManager
import com.ashuiw.oryzaviewer.data.repository.OnboardingManager
import com.ashuiw.oryzaviewer.data.repository.RecentFilesManager
import com.ashuiw.oryzaviewer.data.repository.PdfPageBookmarksManager
import com.ashuiw.oryzaviewer.ui.components.rememberAdaptiveInk
import com.ashuiw.oryzaviewer.ui.components.UnsavedChangesDialog
import com.ashuiw.oryzaviewer.ui.components.GlassBottomSheet
import com.ashuiw.oryzaviewer.ui.components.DecryptingAnimation
import com.ashuiw.oryzaviewer.ui.components.LiquidButton
import com.ashuiw.oryzaviewer.ui.components.GlassTitlePill
import com.ashuiw.oryzaviewer.ui.components.LiquidIconButton
import com.ashuiw.oryzaviewer.ui.components.GlassBackButton
import com.ashuiw.oryzaviewer.ui.components.LocalBackToLibraryAction
import com.ashuiw.oryzaviewer.ui.components.ViewerChromeGlass
import com.ashuiw.oryzaviewer.ui.components.LiquidSaveSheet
import com.ashuiw.oryzaviewer.ui.components.liquidGlassPanel
import com.ashuiw.oryzaviewer.ui.components.viewerChromeGlass
import com.ashuiw.oryzaviewer.ui.components.viewerGlass
import com.ashuiw.oryzaviewer.ui.theme.LocalIsDarkMode
import com.ashuiw.oryzaviewer.ui.utils.rememberUISensor
import com.ashuiw.oryzaviewer.ui.viewmodel.PdfViewerViewModel
import com.ashuiw.oryzaviewer.ui.viewmodel.OcrTextRange
import com.ashuiw.oryzaviewer.ui.selection.PdfCopiedToast
import com.ashuiw.oryzaviewer.ui.selection.PdfSelectionActions
import com.ashuiw.oryzaviewer.ui.selection.PdfSelectionHandles
import com.ashuiw.oryzaviewer.ui.selection.PdfSelectionToolbar
import com.ashuiw.oryzaviewer.ui.selection.PdfTextSelectionState
import com.ashuiw.oryzaviewer.ui.selection.PdfViewportTransform
import com.ashuiw.oryzaviewer.ui.selection.TextPos
import com.ashuiw.oryzaviewer.ui.selection.pdfTextSelectionGestures
import com.ashuiw.oryzaviewer.ui.selection.rememberSelectionAutoScroller
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.layout.onGloballyPositioned
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@OptIn(kotlinx.coroutines.FlowPreview::class)
@Composable
fun PdfViewerScreen(
    backdrop: LayerBackdrop,
    viewModel: PdfViewerViewModel,
    onBack: () -> Unit,
    // True when the caller (recents / external open / a tool's output) already handed us a document
    // to load. In that case the viewer must NOT flash its "Open a PDF" picker while the pages render —
    // it shows a loading curtain that the real document fades in behind. See [ViewerLoadingCurtain].
    pendingLoad: Boolean = false,
    // "Get it" on the Office engine hint: open Settings at the engine section to show progress.
    onOpenOfficeEngineSettings: () -> Unit = {}
) {
    val state         by viewModel.uiState.collectAsState()
    val isDarkMode     = LocalIsDarkMode.current
    val isLight        = !isDarkMode
    val text           = if (isLight) Color(0xFF222222) else Color(0xFFF0F0F0)
    val sub            = if (isLight) Color(0xFF888888) else Color(0xFFAAAAAA)
    val accent         = LiquidGlassColors.Blue
    val uiSensor       = rememberUISensor()
    val context        = LocalContext.current
    val bookmarkUri    = state.originalUri ?: state.document?.uri
    val clipboard      = LocalClipboardManager.current
    val focusManager   = LocalFocusManager.current
    val activity       = context as? Activity
    val view           = LocalView.current
    val scope          = rememberCoroutineScope()

    // ── Local UI state ─────────────────────────────────────────────────────
    var controlsVisible     by rememberSaveable { mutableStateOf(true) }
    var controlsPinned      by rememberSaveable { mutableStateOf(false) }
    var readerTourStep      by rememberSaveable { mutableIntStateOf(-1) }
    var autoScroll by remember { mutableStateOf(false) }
    var autoScrollSpeed by rememberSaveable { mutableFloatStateOf(1f) }
    var viewerResumed by remember { mutableStateOf(true) }
    // True while the bottom "Editor Tools" panel is expanded — keeps the chrome from auto-hiding
    // so the user can browse tools without it disappearing.
    var editorToolsOpen     by rememberSaveable { mutableStateOf(false) }
    // True for as long as the share capsule is held morphed open. Not saveable on purpose: a
    // configuration change cancels the pointer gesture, so a persisted `true` would pin the chrome
    // open forever with no finger left to release it.
    var shareHolding        by remember { mutableStateOf(false) }
    var lastInteractionAtMs by rememberSaveable { mutableStateOf(System.currentTimeMillis()) }
    // Adobe-style single-axis reading: the viewer is vertical-only. Horizontal
    // panning is still allowed inside a zoomed page (handled in PdfContinuousPage).
    val scrollOrientation = ScrollOrientation.Vertical
    var showPageJumpDialog  by rememberSaveable { mutableStateOf(false) }
    var activeTool          by rememberSaveable { mutableStateOf(PdfEditTool.None) }
    var currentColorLong    by rememberSaveable { mutableLongStateOf(0xFF00BCD4L) }
    val currentColor         = Color(currentColorLong)
    var currentStrokeWidth  by rememberSaveable { mutableFloatStateOf(6f) }
    var activeImageId       by remember { mutableStateOf<Long?>(null) }
    var showSaveDialog      by rememberSaveable { mutableStateOf(false) }
    var showShareDialog     by remember { mutableStateOf(false) }
    var showFindBar         by rememberSaveable { mutableStateOf(false) }
    var findQuery           by rememberSaveable { mutableStateOf("") }
    val findFocusRequester   = remember { FocusRequester() }
    var passwordText        by rememberSaveable { mutableStateOf("") }
    val passwordFocusRequester = remember { FocusRequester() }
    var showSignaturePad    by remember { mutableStateOf(false) }
    var showZoomHud         by remember { mutableStateOf(false) }
    // #74: with "Dark pages in dark mode" on, every document opens with dark pages while the app is
    // dark; the moon button still switches it per document.
    val autoDarkPages = com.ashuiw.oryzaviewer.ui.theme.LocalIsDarkMode.current &&
        remember { com.ashuiw.oryzaviewer.data.repository.AppSettingsManager.getAutoDarkPages(context) }
    // Only the moon button's choice is saved; until it is used the pages follow the theme, so a
    // first frame drawn before the theme setting applies can't freeze the wrong colours.
    var darkPageOverride by rememberSaveable { mutableStateOf<Boolean?>(null) }
    // Settings > Appearance: trim page margins (#85) and book mode (#84), read once per document.
    val trimMargins = remember { com.ashuiw.oryzaviewer.data.repository.AppSettingsManager.getTrimMargins(context) }
    val bookMode = remember { com.ashuiw.oryzaviewer.data.repository.AppSettingsManager.getBookMode(context) }
    var contentCrop by remember { mutableStateOf<android.graphics.RectF?>(null) }
    LaunchedEffect(state.document?.uri, state.pageCount) {
        contentCrop = if (trimMargins && state.document != null) viewModel.contentCrop() else null
    }
    val darkPageAppearance = darkPageOverride ?: autoDarkPages
    var bookmarkedPages by remember { mutableStateOf<List<Int>>(emptyList()) }
    // Annotation (text box / sticky note) editing
    var editingAnnoId       by remember { mutableStateOf<Long?>(null) }
    // In-place edit of a line of the page's own text (Text tool tap on existing text).
    var textEditTarget      by remember { mutableStateOf<TextEditTarget?>(null) }
    // Page images handed to the share sheet together (ACTION_SEND_MULTIPLE).
    var shareMultiple: List<android.net.Uri> by remember { mutableStateOf(emptyList()) }
    var editingAnnoPage     by remember { mutableStateOf(0) }
    var editingAnnoIsNote   by remember { mutableStateOf(false) }
    var annotationDraft     by remember { mutableStateOf("") }
    var editingAnnoColor    by remember { mutableStateOf(LiquidGlassColors.Blue) }
    // Shape (rect / oval / line / arrow / stroke) editing — identified by page + list index.
    var editingShapePage    by remember { mutableStateOf<Int?>(null) }
    var editingShapeIndex   by remember { mutableStateOf(-1) }
    // Generic markup selection (move + resize of shapes / text / notes).
    var selectedAnnoPage    by remember { mutableStateOf<Int?>(null) }
    var selectedAnnoIndex   by remember { mutableStateOf(-1) }
    var selectedMarkupGroupPage by remember { mutableStateOf<Int?>(null) }
    var selectedMarkupGroup by remember { mutableStateOf<Set<Int>>(emptySet()) }
    val density              = LocalDensity.current

    LaunchedEffect(state.document?.uri) {
        if (state.document == null) return@LaunchedEffect
        // New users get the whole reader tour (tools, share, then editing text); people updating
        // from a version that already showed them the first two get just the new step.
        val needsReader = !OnboardingManager.hasSeenPdfReaderTour(context)
        val needsEditText = !OnboardingManager.hasSeenEditTextTour(context)
        if (needsReader || needsEditText) {
            delay(650)
            readerTourStep = if (needsReader) 0 else 2
            controlsPinned = true
        }
    }

    fun finishReaderTour() {
        readerTourStep = -1
        controlsPinned = false
        OnboardingManager.markPdfReaderTourSeen(context)
        OnboardingManager.markEditTextTourSeen(context)
    }

    // ── Zoom / pan state ───────────────────────────────────────────────────
    // Ported from Pdf_Tools (Karna14314): document-level zoom/pan is plain float
    // state updated *synchronously* inside the gesture loop. The earlier
    // Animatable approach launched a coroutine (snapTo) per pointer event, which
    // raced on single-page docs and made pinch/pan stutter — see settings credit.
    var scale   by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(scale) {
        if (scale > 1.05f) { showZoomHud = true; delay(900); showZoomHud = false }
        else showZoomHud = false
    }

    // ── Page annotation state ──────────────────────────────────────────────
    val annotationsByPage = remember { mutableStateMapOf<Int, MutableList<PdfMarkup>>() }
    // Screen-resolution renders of the visible part of each page while zoomed in (sharp zoom, #29).
    val detailTiles = remember { mutableStateMapOf<Int, PageDetailTile>() }
    val pageCanvasSizes   = remember { mutableStateMapOf<Int, Size>() }
    val pageBitmapSizes   = remember { mutableStateMapOf<Int, Size>() }

    fun getPageMarks(page: Int): MutableList<PdfMarkup> =
        annotationsByPage.getOrPut(page) { mutableStateListOf() }

    // Exact previews of in-place text edits: each edited page is edited for real and rendered by
    // the same engine as the page (PdfTextEditPreview), and the band around every edited line is
    // laid over the page. Until a band arrives the page shows the quick system-font preview.
    val textEditPatches = remember { mutableStateMapOf<Long, TextEditPatch>() }
    val textEditDocUri = state.document?.uri
    LaunchedEffect(textEditDocUri) {
        val uri = textEditDocUri ?: return@LaunchedEffect
        val rendered = HashMap<Int, List<Pair<Long, String>>>()
        snapshotFlow {
            annotationsByPage.entries.associate { (page, marks) ->
                page to marks.filterIsInstance<PdfMarkup.TextEditMarkup>().map { it.id to it.text }
            }.filterValues { it.isNotEmpty() }
        }.distinctUntilChanged().collectLatest { byPage ->
            delay(80)
            for ((page, signature) in byPage) {
                if (rendered[page] == signature) continue
                val canvas = pageCanvasSizes[page] ?: continue
                if (canvas.width <= 0f || canvas.height <= 0f) continue
                val marks = annotationsByPage[page]?.filterIsInstance<PdfMarkup.TextEditMarkup>().orEmpty()
                val edits = marks.mapNotNull { it.toTextReplace(canvas.width, canvas.height)?.toPdfTextEdit() }
                val bands = marks.map { it.previewBand(canvas.height) }
                val widthPx = (canvas.width * 2f).toInt().coerceIn(800, 3200)
                val bitmaps = withContext(Dispatchers.IO) {
                    com.kyant.pdfcore.text.PdfTextEditPreview.render(context, uri, page, edits, bands, widthPx)
                }
                marks.forEachIndexed { i, m ->
                    bitmaps.getOrNull(i)?.let { textEditPatches[m.id] = TextEditPatch(m.text, bands[i], it) }
                }
                rendered[page] = signature
            }
        }
    }

    // ── Unsaved-edit tracking ──────────────────────────────────────────────
    // Markups live here (not in the ViewModel), so "dirty" is: the current markups differ from what
    // was last exported. PdfMarkup variants are data classes, so a structural compare of a per-page
    // copy is exact — drawing, erasing, moving, retyping a note all flip it, undoing back to the
    // saved state clears it. Covers PDFs and Office documents alike (both render through here).
    fun markupSnapshot(): Map<Int, List<PdfMarkup>> =
        annotationsByPage.filterValues { it.isNotEmpty() }.mapValues { it.value.toList() }
    var savedMarkups        by remember { mutableStateOf<Map<Int, List<PdfMarkup>>>(emptyMap()) }
    var pendingSaveMarkups  by remember { mutableStateOf<Map<Int, List<PdfMarkup>>?>(null) }
    var exitAfterSave       by remember { mutableStateOf(false) }
    var showUnsavedDialog   by remember { mutableStateOf(false) }
    val hasUnsavedEdits     by remember { derivedStateOf { markupSnapshot() != savedMarkups } }

    // Undo history: the page each added markup landed on, newest last. Undo pops the most recent
    // entry and removes THAT page's last mark, so "undo" means the last thing the user actually
    // did. The old behaviour removed the last mark of `listState.firstVisibleItemIndex`, which is
    // the first *partially* visible page — usually a sliver of the previous page while you draw on
    // the one filling the screen, so undo silently no-op'd on an empty list. The same trap is
    // already documented for image placement at `activeImageLoc`.
    val undoStack = remember { mutableStateListOf<Int>() }

    // Declared here (rather than lower) so the image/signature launchers below can place
    // annotations onto whichever page is under the viewport centre.
    val listState = rememberLazyListState()

    LaunchedEffect(bookmarkUri) {
        bookmarkedPages = bookmarkUri?.let { PdfPageBookmarksManager.get(context, it) }.orEmpty()
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewerResumed = true
            if (event == Lifecycle.Event.ON_PAUSE) {
                viewerResumed = false
                autoScroll = false
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(autoScroll, autoScrollSpeed, state.document?.uri, activeTool, scale, viewerResumed) {
        if (!autoScroll || state.document == null || !viewerResumed || activeTool != PdfEditTool.None || scale > 1.01f) {
            if (autoScroll && (!viewerResumed || activeTool != PdfEditTool.None || scale > 1.01f || state.document == null)) autoScroll = false
            return@LaunchedEffect
        }
        var previousFrame = 0L
        while (true) {
            val frame = withFrameNanos { it }
            if (previousFrame == 0L) {
                previousFrame = frame
                continue
            }
            val elapsedSeconds = ((frame - previousFrame).coerceAtMost(50_000_000L)) / 1_000_000_000f
            previousFrame = frame
            val pixels = with(density) { 36.dp.toPx() * autoScrollSpeed * elapsedSeconds }
            if (listState.scrollBy(pixels) <= 0f) {
                autoScroll = false
                break
            }
        }
    }

    // ── Text selection (long-press, native-style handles, glass toolbar) ─────────────────────
    val textSelection = remember { PdfTextSelectionState() }
    val markupBarHost = remember { MarkupBarHost() }
    textSelection.blocksProvider = { p -> viewModel.uiState.value.ocrBlocksByPage[p].orEmpty() }
    var containerWidthPx by remember { mutableIntStateOf(0) }


    textSelection.transformProvider = { PdfViewportTransform(containerWidthPx.toFloat(), scale, offsetX) }
    val selectionAutoScroller = rememberSelectionAutoScroller(listState, textSelection)
    selectionAutoScroller.panBy = { dx ->
        val cw = containerWidthPx.toFloat()
        val maxOffsetX = ((cw * scale - cw) / 2f).coerceAtLeast(0f)
        val next = (offsetX + dx).coerceIn(-maxOffsetX, maxOffsetX)
        val applied = next - offsetX
        offsetX = next
        applied
    }
    var copiedTick by remember { mutableIntStateOf(0) }
    val haptics = LocalHapticFeedback.current

    // iOS-style momentum for the continuous page scroll: a lower-friction exponential decay
    // glides longer and settles smoothly (vs the stiffer platform spline), so even 2–3 page
    // docs feel continuous instead of stopping abruptly. Only the fling curve changes — the
    // scroll mechanics and the default stretch overscroll (rubber-band at the edges) are intact.
    // Book mode (#84): a fling turns exactly one page, however hard, like a page of a book.
    val bookSnap = remember(listState) {
        val base = androidx.compose.foundation.gestures.snapping.SnapLayoutInfoProvider(listState)
        object : androidx.compose.foundation.gestures.snapping.SnapLayoutInfoProvider by base {
            override fun calculateApproachOffset(velocity: Float, decayOffset: Float): Float = 0f
        }
    }
    val bookFling = androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior(bookSnap)
    val iosPageDecay = remember { androidx.compose.animation.core.exponentialDecay<Float>(frictionMultiplier = 0.55f) }
    val pageFling = remember(iosPageDecay) {
        object : androidx.compose.foundation.gestures.FlingBehavior {
            override suspend fun androidx.compose.foundation.gestures.ScrollScope.performFling(initialVelocity: Float): Float {
                if (kotlin.math.abs(initialVelocity) <= 1f) return initialVelocity
                var lastValue = 0f
                var velocityLeft = initialVelocity
                androidx.compose.animation.core.AnimationState(initialValue = 0f, initialVelocity = initialVelocity)
                    .animateDecay(iosPageDecay) {
                        val delta = value - lastValue
                        val consumed = scrollBy(delta)
                        lastValue = value
                        velocityLeft = this.velocity
                        // Hit an edge / content end → stop so overscroll can take over.
                        if (kotlin.math.abs(delta - consumed) > 0.5f) cancelAnimation()
                    }
                return velocityLeft
            }
        }
    }

    // The page + on-screen position where a newly placed image/signature should land: the
    // page occupying the vertical centre of the viewport, at the point the user is looking
    // at (so a sign never silently lands off-screen on page 1). Returns a null offset when
    // the page isn't measured yet → callers fall back to that page's frame centre.
    fun viewportPlacementTarget(): Pair<Int, Offset?> {
        val info = listState.layoutInfo
        val visible = info.visibleItemsInfo
        if (visible.isEmpty()) return state.currentPage to null
        val centerY = (info.viewportStartOffset + info.viewportEndOffset) / 2
        val item = visible.firstOrNull { centerY >= it.offset && centerY < it.offset + it.size }
            ?: visible.minByOrNull { kotlin.math.abs((it.offset + it.size / 2) - centerY) }!!
        val page = item.index
        val cs = pageCanvasSizes[page] ?: return page to null
        if (cs.width < 50f || cs.height < 50f) return page to null
        val topPadPx = with(density) { 6.dp.toPx() }
        val localY = (centerY - item.offset - topPadPx).coerceIn(0f, cs.height)
        val bs = pageBitmapSizes[page] ?: cs
        val frame = fitBitmapRect(cs, bs.width, bs.height)
        return page to Offset(frame.center.x, localY)
    }

    /** Record that [page] just gained a markup, so undo can find it again. */
    fun recordEdit(page: Int) { undoStack.add(page) }

    // ── Fill the PDF's own form fields in place (#68) ──
    // In Edit mode the boxes are outlined on the page; a tap ticks a checkbox / radio, or focuses a
    // text field (typed into right where it is printed) or a choice field (options in the bar).
    // Each filled value is a FormValueMarkup, so undo, unsaved-changes, save and share all apply.
    var focusedForm by remember { mutableStateOf<com.kyant.pdfcore.form.PdfFormWidget?>(null) }
    val formValues by remember {
        derivedStateOf {
            annotationsByPage.values.flatMap { l -> l.filterIsInstance<PdfMarkup.FormValueMarkup>() }
                .associate { it.fieldName to it.value }
        }
    }
    fun formValueOf(w: com.kyant.pdfcore.form.PdfFormWidget): String = formValues[w.fieldName] ?: w.value
    fun setFormValue(w: com.kyant.pdfcore.form.PdfFormWidget, value: String) {
        var found = false
        annotationsByPage.values.forEach { list ->
            val i = list.indexOfFirst { it is PdfMarkup.FormValueMarkup && it.fieldName == w.fieldName }
            if (i >= 0) {
                found = true
                if (value == w.value) list.removeAt(i) else list[i] = PdfMarkup.FormValueMarkup(w.fieldName, value)
            }
        }
        if (!found && value != w.value) {
            getPageMarks(w.pageIndex).add(PdfMarkup.FormValueMarkup(w.fieldName, value))
            recordEdit(w.pageIndex)
        }
    }


    /**
     * Remove the most recently added markup, wherever it lives. Entries can go stale — the eraser
     * and the shape editor delete marks without touching the stack — so pop past any page that has
     * since been emptied. If the history is exhausted (or was never populated) fall back to the page
     * under the viewport centre, which is the page the user is looking at.
     */
    fun undoLastEdit() {
        while (undoStack.isNotEmpty()) {
            val page = undoStack.removeAt(undoStack.lastIndex)
            val marks = getPageMarks(page)
            if (marks.isNotEmpty()) { marks.removeAt(marks.lastIndex); return }
        }
        val marks = getPageMarks(viewportPlacementTarget().first)
        if (marks.isNotEmpty()) marks.removeAt(marks.lastIndex)
    }

    /** Clear every markup on the page under the viewport centre — the one the user can see. */
    fun clearVisiblePage() {
        val page = viewportPlacementTarget().first
        getPageMarks(page).clear()
        undoStack.removeAll { it == page }
    }

    // Add a new image/signature centred at the viewport-target on the correct page, sized
    // to the page and clamped fully on-page. Shared by the image picker and signature pad.
    fun placeImageMarkup(bmp: Bitmap, isSignature: Boolean) {
        val (page, target) = viewportPlacementTarget()
        val marks = getPageMarks(page)
        val rawCs = pageCanvasSizes[page]
        val cs = if (rawCs != null && rawCs.width > 50f && rawCs.height > 50f) rawCs else Size(1000f, 1400f)
        val bs = pageBitmapSizes[page] ?: cs
        val frame = fitBitmapRect(cs, bs.width, bs.height)
        val maxW = (if (frame.width > 50f) frame.width else cs.width) * (if (isSignature) 0.45f else 0.5f)
        val ratio = bmp.height.toFloat() / bmp.width.toFloat().coerceAtLeast(1f)
        val w = maxW.coerceAtLeast(100f)
        val h = w * ratio
        val fallbackCenter = if (frame.width > 50f) frame.center else Offset(cs.width / 2f, cs.height / 2f)
        val center = target ?: fallbackCenter
        val cx = center.x.coerceIn(w / 2f, (cs.width - w / 2f).coerceAtLeast(w / 2f))
        val cy = center.y.coerceIn(h / 2f, (cs.height - h / 2f).coerceAtLeast(h / 2f))
        val id = System.nanoTime()
        marks.add(PdfMarkup.ImageMarkup(id, bmp, Offset(cx - w / 2f, cy - h / 2f), Offset(cx + w / 2f, cy + h / 2f), isSignature))
        recordEdit(page)
        activeImageId = id; activeTool = PdfEditTool.Image; controlsVisible = true
    }

    // Locate the currently selected image across ALL pages (it may live on a page other
    // than firstVisibleItemIndex, since placement targets the viewport-centre page).
    fun activeImageLoc(): Triple<Int, Int, PdfMarkup.ImageMarkup>? {
        val id = activeImageId ?: return null
        annotationsByPage.forEach { (pg, m) ->
            val i = m.indexOfLast { it is PdfMarkup.ImageMarkup && it.id == id }
            if (i >= 0) return Triple(pg, i, m[i] as PdfMarkup.ImageMarkup)
        }
        return null
    }

    // ── Launchers ─────────────────────────────────────────────────────────
    val pdfPickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { viewModel.openPdf(context, it) }
    }

    val imagePickerLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        val bmp = runCatching {
            context.contentResolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it)
            }
        }.getOrNull() ?: return@rememberLauncherForActivityResult
        // If an image is currently selected, replace its bitmap in place; otherwise place a
        // new one on the page under the viewport (never silently on page 1).
        val existingPage = annotationsByPage.entries.firstOrNull { (_, m) -> m.any { it is PdfMarkup.ImageMarkup && it.id == activeImageId } }?.key
        val existingIdx = existingPage?.let { getPageMarks(it).indexOfLast { m -> m is PdfMarkup.ImageMarkup && m.id == activeImageId } } ?: -1
        if (existingPage != null && existingIdx >= 0) {
            val marks = getPageMarks(existingPage)
            val existing = marks[existingIdx] as PdfMarkup.ImageMarkup
            val ratio = bmp.height.toFloat() / bmp.width.toFloat().coerceAtLeast(1f)
            val currentW = kotlin.math.abs(existing.end.x - existing.start.x).coerceAtLeast(20f)
            marks[existingIdx] = existing.copy(bitmap = bmp, end = Offset(existing.end.x, existing.start.y + currentW * ratio), isSignature = false)
        } else {
            placeImageMarkup(bmp, isSignature = false)
        }
    }

    // ── Immersive mode ────────────────────────────────────────────────────
    val immersiveActive = state.document != null && !controlsVisible
    DisposableEffect(activity, view, immersiveActive) {
        val ctrl = activity?.let { WindowCompat.getInsetsController(it.window, view) }
        ctrl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (immersiveActive) ctrl?.hide(WindowInsetsCompat.Type.systemBars())
        else ctrl?.show(WindowInsetsCompat.Type.systemBars())
        onDispose { ctrl?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    // ── Document lifecycle effects ─────────────────────────────────────────
    LaunchedEffect(state.document?.uri) {
        autoScroll = false
        controlsVisible = true; controlsPinned = false
        lastInteractionAtMs = System.currentTimeMillis()
        scale = 1f; offsetX = 0f
        activeTool = PdfEditTool.None
        selectedAnnoPage = null; selectedAnnoIndex = -1
        selectedMarkupGroupPage = null; selectedMarkupGroup = emptySet()
        annotationsByPage.clear(); undoStack.clear(); pageCanvasSizes.clear(); pageBitmapSizes.clear()
        savedMarkups = emptyMap(); pendingSaveMarkups = null; exitAfterSave = false; showUnsavedDialog = false
        textSelection.resetDocument(); viewModel.clearExportFeedback()
        showFindBar = false; findQuery = ""; viewModel.clearSearch()
    }

    LaunchedEffect(state.document, controlsVisible, controlsPinned, activeTool, selectedMarkupGroup.size, editorToolsOpen, shareHolding, lastInteractionAtMs) {
        if (state.document != null && controlsVisible && !controlsPinned && !autoScroll && scale <= 1.01f && activeTool == PdfEditTool.None && selectedMarkupGroup.size <= 1 && !editorToolsOpen && !shareHolding) {
            val snap = lastInteractionAtMs
            // Comfortable auto-hide window; any interaction bumps lastInteractionAtMs and
            // restarts this. It never fires while a tool is active (activeTool != None), while
            // the Editor Tools panel is open, or while the share capsule is held — a long-press
            // produces no pointer events for the viewer to see, so without that last guard the
            // chrome hid itself out from under the finger mid-gesture.
            delay(5000)
            if (controlsVisible && !controlsPinned && !autoScroll && scale <= 1.01f && activeTool == PdfEditTool.None && selectedMarkupGroup.size <= 1 && !editorToolsOpen && !shareHolding && snap == lastInteractionAtMs)
                controlsVisible = false
        }
    }

    LaunchedEffect(state.passwordUri) {
        if (state.passwordUri != null) { passwordText = ""; delay(120); passwordFocusRequester.requestFocus() }
    }

    /** Leave the viewer — via the "Save changes?" card when there are unexported markups. */
    fun requestExit() {
        if (state.document != null && hasUnsavedEdits) { controlsVisible = true; showUnsavedDialog = true }
        else onBack()
    }

    // An export started from the unsaved-changes card (or any Save) settles here: success marks the
    // exported markups as saved and, if the card asked for it, leaves; failure keeps the user here.
    LaunchedEffect(state.exportMessage, state.exportError) {
        val pending = pendingSaveMarkups ?: return@LaunchedEffect
        if (state.exportMessage != null) {
            savedMarkups = pending; pendingSaveMarkups = null
            if (exitAfterSave) { exitAfterSave = false; onBack() }
        } else if (state.exportError != null) {
            pendingSaveMarkups = null; exitAfterSave = false
        }
    }

    BackHandler(enabled = state.document != null) {
        if (!controlsVisible) controlsVisible = true else requestExit()
    }

    // ── No-document state ─────────────────────────────────────────────────
    if (state.document == null) {
        val askingPassword = state.passwordRequired && state.passwordUri != null
        // A document is on its way in (recents / external / tool output) and nothing has gone wrong
        // yet: show the loading curtain instead of the picker so the user never sees the "Open a PDF"
        // card flash before their file appears. The identical curtain is held over the loaded viewer
        // below until the first page is rendered, so the swap between these two branches is seamless.
        val openingHandedDoc = !askingPassword && state.errorMessage == null && (state.isLoading || pendingLoad)
        if (openingHandedDoc) {
            Box(Modifier.fillMaxSize()) {
                ViewerLoadingCurtain(isLight = isLight, darkPage = darkPageAppearance)
                // While a password PDF is actually being unlocked, play the padlock "decrypting"
                // animation over the fill (styled after the onboarding page-5 demos). Plain opening
                // fills (a normal load) show nothing extra — a lock would be misleading there.
                if (state.decrypting) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        DecryptingAnimation(backdrop = backdrop)
                    }
                }
            }
            return
        }
        // The password prompt is an OVERLAY on this Box, not a third row inside the Column below.
        //
        // It used to be a sibling of the "Open a PDF" card in a `spacedBy(16.dp)` Column whose middle
        // section carried `weight(1f)`. So the moment the prompt and the keyboard were both up, the
        // weighted section was squeezed and the card was chopped mid-sentence — the whole point of a
        // password dialog is that the thing behind it stays intact.
        // Opaque: paint the wallpaper itself behind the picker. Without it this branch was see-through,
        // so during the "lift" the held Tools/Home screen showed behind the new buttons and vanished
        // only when the transition ended — the buttons-first-then-background glitch.
        Box(
            Modifier
                .fillMaxSize()
                .drawBackdrop(backdrop = backdrop, shape = { androidx.compose.ui.graphics.RectangleShape }, effects = {}, highlight = { null }, shadow = null)
        ) {
            Column(
                Modifier.fillMaxSize().statusBarsPadding().padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Same trio as the loaded viewer's chrome: back circle · centered title pill · balancer.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // No `surfaceColor`, like Home's — this circle used to paint a white 8% wash that
                    // nothing else in the app does.
                    GlassBackButton(onBack = onBack, backdrop = backdrop, foreground = text)
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        GlassTitlePill(stringResource(R.string.viewer_title), backdrop)
                    }
                    Spacer(Modifier.size(40.dp))
                }
                Column(
                    Modifier.fillMaxWidth().weight(1f).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
                ) {
                    Column(
                        Modifier.fillMaxWidth().viewerGlass(backdrop, viewerChromeGlass(isDarkMode)).padding(28.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Icon(Icons.Rounded.PictureAsPdf, null, Modifier.size(56.dp), accent)
                        BasicText(stringResource(R.string.viewer_open_pdf), style = TextStyle(text, 20.sp, fontWeight = FontWeight.SemiBold))
                        BasicText(stringResource(R.string.viewer_select_file), style = TextStyle(sub, 14.sp, textAlign = TextAlign.Center))
                        LiquidButton(onClick = { pdfPickerLauncher.launch(arrayOf("*/*")) }, backdrop = backdrop, tint = accent) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Rounded.UploadFile, null, Modifier.size(18.dp), Color.White)
                                BasicText(stringResource(R.string.viewer_pick_pdf), style = TextStyle(Color.White, 15.sp, fontWeight = FontWeight.Medium))
                            }
                        }
                    }
                    state.errorMessage?.let { BasicText(it, style = TextStyle(Color(0xFFD32F2F), 14.sp)) }
                }
            }

            // ── Password prompt (in-window, so the glass samples the real backdrop) ──
            // `askingPassword` is computed at the top of this branch.

            // Dimming scrim. Deliberately NOT tap-to-dismiss, unlike LiquidPageJumpPopup: there is
            // nothing behind this to go back to — dismissing would leave a locked document and an
            // empty screen. Back already exits the viewer.
            AnimatedVisibility(
                visible = askingPassword,
                enter = fadeIn(tween(200)),
                exit = fadeOut(tween(180)),
                modifier = Modifier.fillMaxSize()
            ) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(0.45f)))
            }

            AnimatedVisibility(
                visible = askingPassword,
                // LiquidPageJumpPopup's entrance, verbatim, so the app has one dialog motion.
                enter = fadeIn(tween(220)) +
                    scaleIn(initialScale = 0.85f, animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow)),
                exit = fadeOut(tween(140)) + scaleOut(targetScale = 0.9f, animationSpec = tween(150)),
                modifier = Modifier.align(Alignment.Center).imePadding()
            ) {
                Column(
                    Modifier
                        .widthIn(max = 340.dp)
                        .fillMaxWidth(0.86f)
                        // The heavy stack, not `viewerGlass`: this is a dialog over a scrim and needs
                        // an edge of its own. No `containerColorOverride` — there is no page to sample
                        // in this branch, so the theme tint is the right one.
                        .liquidGlassPanel(backdrop, uiSensor)
                        .padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    BasicText(stringResource(R.string.pdf_password_title), style = TextStyle(text, 17.sp, fontWeight = FontWeight.SemiBold))
                    BasicText(
                        if (state.passwordAttemptFailed) stringResource(R.string.pdf_password_wrong) else stringResource(R.string.pdf_password_subtitle),
                        style = TextStyle(sub, 12.sp)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        BasicTextField(
                            value = passwordText,
                            onValueChange = { passwordText = it },
                            singleLine = true,
                            textStyle = TextStyle(text, 15.sp),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                            keyboardActions = KeyboardActions(onDone = { state.passwordUri?.let { viewModel.openPdf(context, it, passwordText) } }),
                            modifier = Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                                .background(if (isLight) Color.Black.copy(0.05f) else Color.White.copy(0.08f))
                                .padding(horizontal = 12.dp, vertical = 11.dp).focusRequester(passwordFocusRequester),
                            decorationBox = { inner ->
                                if (passwordText.isEmpty()) BasicText(stringResource(R.string.pdf_password_hint), style = TextStyle(sub, 14.sp))
                                inner()
                            }
                        )
                        LiquidButton(onClick = { state.passwordUri?.let { viewModel.openPdf(context, it, passwordText) } }, backdrop = backdrop, tint = accent) {
                            BasicText(stringResource(R.string.pdf_password_unlock), style = TextStyle(Color.White, 13.sp, FontWeight.SemiBold))
                        }
                    }
                }
            }
        }
        return
    }

    // ── PDF viewer (continuous vertical scroll, Adobe-style) ─────────────────
    val safePageCount = state.pageCount.coerceAtLeast(1)
    val viewerScope   = rememberCoroutineScope()
    LaunchedEffect(state.document?.uri) {
        if (state.document != null) {
            val targetPage = state.currentPage.coerceIn(0, safePageCount - 1)
            if (listState.firstVisibleItemIndex != targetPage) listState.scrollToItem(targetPage)
        }
    }
    val currentPageIndex = listState.firstVisibleItemIndex.coerceIn(0, safePageCount - 1)
    // Back clears an active text selection first (registered after the viewer's own BackHandler, so
    // it takes precedence), exactly like a TextView's selection mode.
    val selectionActive by remember { derivedStateOf { textSelection.hasSelection } }
    BackHandler(enabled = selectionActive) { textSelection.clear() }
    val markupSelectionActive by remember { derivedStateOf { selectedAnnoIndex >= 0 || selectedMarkupGroup.isNotEmpty() } }
    BackHandler(enabled = markupSelectionActive) {
        selectedAnnoPage = null
        selectedAnnoIndex = -1
        selectedMarkupGroupPage = null
        selectedMarkupGroup = emptySet()
    }
    // Any editing tool owns the page gestures; a selection must not linger underneath it.
    LaunchedEffect(activeTool) { if (activeTool != PdfEditTool.None) textSelection.clear() }

    // Live backdrop that captures the ACTUAL rendered page column (dark bg + PDF
    // pages), so the glass chrome reflects real content instead of the static
    // wallpaper PNG. The chrome is drawn as siblings on top of the captured Box, so
    // there is no feedback loop.
    val contentBackdrop = rememberLayerBackdrop()

    // Form filling (#68): which boxes take part, in reading order, and how a tap fills one.
    val formEditing = editorToolsOpen && state.formWidgetsByPage.isNotEmpty()
    val formOrder = remember(state.formWidgetsByPage) {
        state.formWidgetsByPage.values.flatten()
            .filter { !it.readOnly && it.type == com.kyant.pdfcore.form.PdfFormWidget.Type.TEXT }
            .sortedWith(compareBy({ it.pageIndex }, { it.top }, { it.left }))
    }
    var showFormTour by remember { mutableStateOf(!OnboardingManager.hasSeenFormFillTour(context)) }
    val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
    LaunchedEffect(formEditing) { if (!formEditing) focusedForm = null }
    LaunchedEffect(state.document?.uri) { focusedForm = null }
    // Bring the focused box into the top of the viewport, clear of the keyboard and the bar.
    LaunchedEffect(focusedForm?.key) {
        val w = focusedForm ?: return@LaunchedEffect
        val canvas = pageCanvasSizes[w.pageIndex]
        val viewport = listState.layoutInfo.viewportSize.height
        val offset = if (canvas != null) (w.top * canvas.height - viewport * 0.22f).toInt() else 0
        runCatching { listState.animateScrollToItem(w.pageIndex, offset.coerceAtLeast(0)) }
    }
    // A link on the page (#83): a jump inside the document scrolls there; a web or mail address
    // goes to the app that handles it. Other schemes (javascript:, file:, intent:) are ignored.
    val onOpenLink: (com.kyant.pdfcore.link.PdfLink) -> Unit = { link ->
        val target = link.targetPage
        if (target != null) {
            val canvas = pageCanvasSizes[target]
            val top = link.targetTop
            val offset = if (canvas != null && top != null) (top * canvas.height).toInt() else 0
            viewerScope.launch {
                runCatching { listState.animateScrollToItem(target.coerceIn(0, safePageCount - 1), offset.coerceAtLeast(0)) }
            }
        } else link.uri?.let { raw ->
            val withScheme = if (Regex("^[a-zA-Z][a-zA-Z0-9+.-]*:").containsMatchIn(raw)) raw else "https://$raw"
            val parsed = android.net.Uri.parse(withScheme)
            if (parsed.scheme?.lowercase() in setOf("http", "https", "mailto", "tel")) {
                runCatching {
                    context.startActivity(Intent(Intent.ACTION_VIEW, parsed).addCategory(Intent.CATEGORY_BROWSABLE))
                }
            }
        }
    }
    // A dropdown field's open menu, and its field's box in window space.
    var formMenu by remember { mutableStateOf<com.kyant.pdfcore.form.PdfFormWidget?>(null) }
    var formMenuAnchor by remember { mutableStateOf(androidx.compose.ui.geometry.Rect.Zero) }
    val onTapFormWidget: (com.kyant.pdfcore.form.PdfFormWidget, androidx.compose.ui.geometry.Rect) -> Unit = { w, anchor ->
        if (showFormTour) { showFormTour = false; OnboardingManager.markFormFillTourSeen(context) }
        when (w.type) {
            com.kyant.pdfcore.form.PdfFormWidget.Type.TEXT -> focusedForm = w
            com.kyant.pdfcore.form.PdfFormWidget.Type.LIST -> Unit
            com.kyant.pdfcore.form.PdfFormWidget.Type.CHOICE -> {
                focusedForm = null
                keyboard?.hide()
                formMenuAnchor = anchor
                formMenu = w
            }
            com.kyant.pdfcore.form.PdfFormWidget.Type.CHECKBOX -> {
                focusedForm = null
                haptics.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.SegmentTick)
                setFormValue(w, if (formValueOf(w) == "true") "false" else "true")
            }
            com.kyant.pdfcore.form.PdfFormWidget.Type.RADIO -> {
                focusedForm = null
                haptics.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.SegmentTick)
                setFormValue(w, w.onValue)
            }
        }
    }

    // ── Adaptive chrome contrast ────────────────────────────────────────────
    // The chrome glass floats over the page, which may be a bright white note or a
    // dark scan. Sample the current page's average luminance and flip the whole
    // chrome palette (glass surface + foreground) so text/icons are always legible:
    // dark ink on a light page, white ink on a dark page.
    //
    // Single-page documents used to be pinned to the dark branch. That was over-broad and is the
    // reason the chrome looked stuck in dark mode: a converted .docx is usually one page, so *every*
    // Word document and every one-page PDF got dark glass no matter the page or the theme.
    //
    // The reason for the pin was real, though. A lone page is centred (`Arrangement.Center` on the
    // LazyColumn below), so the chrome can float over the near-black canvas rather than over the
    // page — and at 66% the light surface set little value of its own, leaving buttons refracting
    // black while their icons took the *dark* foreground chosen from the white page. The fix is to
    // make the light surface actually opaque enough to stand on its own (78%, below) instead of
    // throwing away a correct luminance reading. Dark ink on that holds up over the black band and
    // over the page alike.
    val currentPageBitmap = state.pageBitmaps.getOrNull(currentPageIndex)
    // Whole-page luminance still drives the DIALOG panels (chromePanel / panelFg): those sit over a
    // scrim on an opaque surface, not over the live document, so a single global reading is right.
    // The floating BARS no longer use this — they sample the content directly behind each bar
    // (topFg / bottomFg, computed once containerHeightPx is known, further down). That is what makes
    // the icons dynamic per-region, kills the "doesn't flip until you scroll deep into page 3" lag,
    // and tracks the zoomed region on a single page. The old single-page white-pin is gone with it —
    // band sampling reads the dark letterbox as dark (→ white ink) on its own.
    val isLightChrome = remember(currentPageBitmap, darkPageAppearance) {
        // Dark reader draws the page inverted, so what is on screen is 1 - bitmap.
        currentPageBitmap?.let {
            val l = averageLuminance(it)
            (if (darkPageAppearance) 1f - l else l) > 0.60f
        } ?: false
    }
    // Home's tint, verbatim — the same expression GlassTitlePill and GlassSearchPill resolve — but
    // picked off the *page's* luminance instead of the theme, so a white scan in dark mode still gets
    // the light surface.
    //
    // This used to be 0.78/0.62, roughly twice Home's weight, and it was painted onto controls Home
    // leaves entirely clear: `LiquidIconButton` with no `surfaceColor` draws nothing at all in
    // `onDrawSurface`, so Home's circles are pure refraction. Over a white page a 62% #12151C slab
    // composites to about #6C6C6C, which is why the chrome read as grey blobs sitting *on* the
    // document rather than as glass floating over it. The effect stack was never the difference —
    // `LiquidIconButton` and `viewerGlass` both run vibrancy + blur 2 + lens 12x24 — only the tint was.
    val chromeGlass  = if (isLightChrome) Color(0xFFFAFAFA).copy(0.35f) else Color(0xFF1E1E1E).copy(0.35f)
    // Dialogs keep the old, heavier tint. They sit over a 45% black scrim and carry dense content, and
    // the app's own rule is that the heavy stack stays reserved for them (see ViewerGlass's KDoc).
    val chromePanel  = if (isLightChrome) Color(0xFFEFF1F4).copy(0.78f) else ViewerChromeGlass
    // The dialogs' ink deliberately does *not* take the single-page pin above. Their surface is
    // `chromePanel`, which is opaque enough to be its own background, so it is the panel the text has
    // to contrast with — not the canvas. Pinning these to white alongside the floating chrome would
    // put white text on a 78% white panel every time a one-page document happened to be light.
    val panelFg      = if (isLightChrome) Color(0xFF15171C) else Color.White
    val panelFgSoft  = if (isLightChrome) Color(0xFF15171C).copy(0.62f) else Color.White.copy(0.62f)
    // Fields sit over page patches that may be much lighter or darker than the sampled page average.
    val chromeField  = if (isLightChrome) Color.Black.copy(0.12f) else Color(0xFF111318).copy(0.74f)
    // The quick-actions sheet has a theme-owned surface, so its labels and button wells must follow
    // that surface rather than the page luminance sampled for the floating reader chrome. Those
    // can legitimately disagree (e.g. a light document while the app is in dark mode).
    val quickActionFg = if (isDarkMode) Color.White else Color(0xFF15171C)
    // Buttons refract the live document rather than the sheet's filled surface, so a faint field
    // can still resolve to near-black over a dark page while keeping dark ink. Keep the material
    // translucent, but bright/dark enough to guarantee contrast over either page luminance.
    val quickActionField = if (isDarkMode) Color.Black.copy(alpha = 0.66f) else Color.White.copy(alpha = 0.80f)

    // The top visible page drives text extraction, the chrome-tint sampling, and (via
    // `selectionPageIndex`/toolbar targets) which page an action applies to — all of that needs to
    // track the scroll position immediately, every tick.
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .distinctUntilChanged()
            .collect { idx -> viewModel.onPageChanged(idx.coerceIn(0, safePageCount - 1)) }
    }
    // Bitmap-cache eviction is a separate, DEBOUNCED signal. It used to run on every single one of
    // those ticks: during a fast scroll or fling through a many-page document (a converted .pptx,
    // scrolled through quickly, was the easiest way to see it) the "current page" advances every
    // few milliseconds, and evicting far-from-current bitmaps on every tick recycled pages that
    // were still transiting through the viewport a frame later — the freshly-evicted page then had
    // to re-render from scratch before it could be shown again, which is what "flickering"/
    // "buffering" while scrolling actually was: real re-render work, triggered far more often than
    // the eviction needed to happen. Coalescing rapid ticks into one sweep after they stop still
    // bounds memory (nothing pins pages forever, it just evicts once per settled position instead
    // of once per pixel) while never evicting a page mid-transit.
    LaunchedEffect(listState, state.originalUri, safePageCount) {
        snapshotFlow { listState.firstVisibleItemIndex.coerceIn(0, safePageCount - 1) }
            .distinctUntilChanged()
            .debounce(180)
            .collect { idx ->
                viewModel.trimBitmapCache(idx)
                state.originalUri?.let { uri ->
                    RecentFilesManager.updateProgress(context, uri, idx, safePageCount)
                }
            }
    }

    // Scroll to the page holding the active find match.
    LaunchedEffect(state.currentMatchIndex, state.findMatches) {
        val idx = state.currentMatchIndex
        val matches = state.findMatches
        if (idx >= 0 && matches.isNotEmpty()) {
            viewerScope.launch { listState.animateScrollToItem(matches[idx].pageIndex) }
        }
    }

    val drawingToolActive = activeTool in setOf(
        PdfEditTool.Draw, PdfEditTool.Highlight, PdfEditTool.Rect,
        PdfEditTool.Ellipse, PdfEditTool.Line, PdfEditTool.Arrow, PdfEditTool.Lasso
    )
    val zoomHudText = "${(scale * 100 + 0.5f).toInt()}%"

    fun scrollToPage(target: Int) {
        viewerScope.launch { listState.animateScrollToItem(target.coerceIn(0, safePageCount - 1)) }
        lastInteractionAtMs = System.currentTimeMillis()
    }

    // Smooth, critically-damped zoom — NO overshoot/bounce (premium, Apple-style ease).
    val animateZoomPan: suspend (Float, Offset) -> Unit = { targetZoom, targetPan ->
        val spec = androidx.compose.animation.core.spring<Float>(
            dampingRatio = Spring.DampingRatioNoBouncy,
            stiffness    = Spring.StiffnessMediumLow
        )
        coroutineScope {
            launch { androidx.compose.animation.core.animate(scale, targetZoom, animationSpec = spec) { v, _ -> scale = v } }
            launch { androidx.compose.animation.core.animate(offsetX, targetPan.x, animationSpec = spec) { v, _ -> offsetX = v } }
        }
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(if (isLight) Color(0xFF0A0E14).copy(0.85f) else Color(0xFF020305).copy(0.88f))
    ) {
        // Trimmed margins lay the page out wider than the screen, so it renders wider too.
        val renderWidthPx = (with(LocalDensity.current) { maxWidth.roundToPx() }.coerceAtLeast(720) /
            (contentCrop?.width() ?: 1f)).roundToInt().coerceAtMost(4096)

        // Re-render the focused page after zoom settles. Scaling a screen-sized bitmap makes PDF
        // text and fine diagrams soft; a bounded higher-resolution page keeps pinch zoom readable
        // without triggering a native render for every pointer frame.
        LaunchedEffect(state.document?.uri, currentPageIndex, renderWidthPx) {
            snapshotFlow { scale }
                .distinctUntilChanged()
                .debounce(220)
                .collect { zoom ->
                    if (zoom < 1.18f) return@collect
                    val desired = (renderWidthPx * zoom.coerceAtMost(2.5f))
                        .roundToInt()
                        .coerceAtMost(3072)
                        .coerceAtLeast(renderWidthPx)
                    if (desired > renderWidthPx) viewModel.renderPage(context, currentPageIndex, desired)
                }
        }

        // Warms the pages just ahead of (and one behind) wherever scrolling currently is, so a page's
        // render has a head start instead of only beginning once it scrolls into view — undebounced
        // is fine here since `prefetchAround`/`renderPage` are no-ops for a page already rendered or
        // already in flight.
        LaunchedEffect(currentPageIndex, renderWidthPx) {
            viewModel.prefetchAround(context, currentPageIndex, renderWidthPx)
        }

        var containerHeightPx by remember { mutableStateOf(0) }

        // Sharp zoom (#29): once a zoom / pan settles, the visible part of each on-screen page is
        // rendered at exact screen resolution and laid over the page, so text and fine diagrams stay
        // crisp at any zoom instead of being a stretched page bitmap. Cleared again near 1x.
        LaunchedEffect(state.document?.uri) {
            detailTiles.clear()
            snapshotFlow { Triple(scale, offsetX, listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset) }
                .distinctUntilChanged()
                .debounce(160)
                .collectLatest { (s, ox, _) ->
                    if (s < 1.15f) { detailTiles.clear(); return@collectLatest }
                    val cw = containerWidthPx.toFloat()
                    val ch = containerHeightPx.toFloat()
                    if (cw <= 0f || ch <= 0f) return@collectLatest
                    // The viewport in the zoom layer's own (unscaled) space: the layer scales about
                    // its top-centre and is shifted by `offsetX`.
                    val lx0 = (-cw / 2f - ox) / s + cw / 2f
                    val lx1 = (cw / 2f - ox) / s + cw / 2f
                    val ly1 = ch / s
                    val keep = HashSet<Int>()
                    for (item in listState.layoutInfo.visibleItemsInfo) {
                        val p = item.index
                        val o = textSelection.pageOrigin(p) ?: continue
                        val sz = textSelection.pageSize(p) ?: continue
                        if (sz.width <= 0f || sz.height <= 0f) continue
                        val l = maxOf(lx0, o.x); val r = minOf(lx1, o.x + sz.width)
                        val t = maxOf(0f, o.y); val b = minOf(ly1, o.y + sz.height)
                        if (r <= l || b <= t) continue
                        val region = android.graphics.RectF(
                            (l - o.x) / sz.width, (t - o.y) / sz.height, (r - o.x) / sz.width, (b - o.y) / sz.height
                        )
                        val w = ((r - l) * s).roundToInt().coerceIn(1, 4096)
                        val h = ((b - t) * s).roundToInt().coerceIn(1, 4096)
                        val bmp = viewModel.renderRegion(p, region, sz.width * s, w, h) ?: continue
                        detailTiles[p] = PageDetailTile(region, bmp)
                        keep += p
                    }
                    detailTiles.keys.retainAll(keep)
                }
        }

        // Book mode / trimmed margins: where each page really sits, for the ink sampling below.
        val pageFrameOf: (Int) -> FloatArray? = { p ->
            val c = contentCrop
            val o = textSelection.pageOrigin(p)
            val sz = textSelection.pageSize(p)
            when {
                !bookMode && c == null -> null
                // Not placed yet: a book-mode page sits inside letterbox, so count nothing for now.
                o == null || sz == null || sz.height <= 0f -> if (bookMode) floatArrayOf(0f, 1f, 0f, 0f) else null
                else -> floatArrayOf(o.y, sz.height, o.y + (c?.top ?: 0f) * sz.height, o.y + (c?.bottom ?: 1f) * sz.height)
            }
        }

        // ── Adaptive control ink, sampled per bar (Apple-style) ──────────────────────────────
        // Each bar reads the luminance of the content *directly behind it*, so on a page that is a
        // dark image up top and a white canvas below, the top bar goes white while the bottom toolbar
        // goes dark — and both update the instant that content scrolls or zooms under them, not when
        // the page becomes the first fully-visible item. Bands are in screen px; the content Box is
        // scaled about a top origin with translationY = 0, so a screen Y maps to the LazyColumn's own
        // coordinate as screenY / scale (see [bandLuminance]).
        val topBandBottomPx = with(density) { 96.dp.toPx() }
        val bottomBandDepthPx = with(density) { 140.dp.toPx() }
        var topBarLight by remember { mutableStateOf(false) }
        var bottomBarLight by remember { mutableStateOf(false) }
        // Hysteresis: flip to light at 0.62, back to dark at 0.58, so a page hovering near the
        // midpoint doesn't strobe while scrolling. The colour crossfade below smooths the flip
        // itself. The sampling runs in a coroutine off `snapshotFlow`, so scrolling recomputes the
        // luminance every frame but only an actual light/dark flip ever recomposes the chrome.
        LaunchedEffect(containerHeightPx, darkPageAppearance) {
            var firstSample = true
            snapshotFlow {
                bandLuminance(listState.layoutInfo, state.pageBitmaps, scale, 0f, topBandBottomPx, darkPageAppearance, pageFrame = pageFrameOf)
            }.collect { lum ->
                if (firstSample) {
                    topBarLight = lum > 0.60f
                    firstSample = false
                } else if (lum > 0.62f) topBarLight = true else if (lum < 0.58f) topBarLight = false
            }
        }
        LaunchedEffect(containerHeightPx, darkPageAppearance) {
            var firstSample = true
            snapshotFlow {
                val h = containerHeightPx.toFloat()
                if (h <= 0f) 0f
                else bandLuminance(listState.layoutInfo, state.pageBitmaps, scale, h - bottomBandDepthPx, h, darkPageAppearance, pageFrame = pageFrameOf)
            }.collect { lum ->
                if (firstSample) {
                    bottomBarLight = lum > 0.60f
                    firstSample = false
                } else if (lum > 0.62f) bottomBarLight = true else if (lum < 0.58f) bottomBarLight = false
            }
        }
        val topFg by animateColorAsState(if (topBarLight) Color(0xFF15171C) else Color.White, tween(200), label = "topBarInk")
        // The system status bar sits over the same band as the top chrome, so its icons follow the
        // same sampling: dark clock/battery over a white page, light over a dark one (they were white
        // on white over light pages). Restores the theme's appearance when the viewer leaves.
        DisposableEffect(activity, view, topBarLight) {
            val ctrl = activity?.let { WindowCompat.getInsetsController(it.window, view) }
            ctrl?.isAppearanceLightStatusBars = topBarLight
            onDispose { ctrl?.isAppearanceLightStatusBars = !isDarkMode }
        }
        val bottomFg by animateColorAsState(if (bottomBarLight) Color(0xFF15171C) else Color.White, tween(200), label = "bottomBarInk")
        val topFgSoft = topFg.copy(alpha = 0.62f)
        val bottomFgSoft = bottomFg.copy(alpha = 0.62f)

        // The find bar is the one control that does NOT sit at the screen edge: with the keyboard up
        // it floats at the top of the IME, so the bottom-of-screen band (behind the keyboard) is the
        // wrong reading for it. Sample the band directly above the IME instead, so its text and its
        // prev/next/close icons adapt to the page content actually behind the search bar. When the
        // keyboard is down the IME inset is 0 and this collapses to the same bottom band.
        val imeInset = WindowInsets.ime
        var findBarLight by remember { mutableStateOf(false) }
        LaunchedEffect(containerHeightPx) {
            snapshotFlow {
                val h = containerHeightPx.toFloat()
                if (h <= 0f) 0f
                else {
                    val bottom = (h - imeInset.getBottom(density)).coerceAtLeast(bottomBandDepthPx)
                    bandLuminance(listState.layoutInfo, state.pageBitmaps, scale, bottom - bottomBandDepthPx, bottom, darkPageAppearance, pageFrame = pageFrameOf)
                }
            }.collect { lum ->
                if (lum > 0.62f) findBarLight = true else if (lum < 0.58f) findBarLight = false
            }
        }
        val findFg by animateColorAsState(if (findBarLight) Color(0xFF15171C) else Color.White, tween(200), label = "findBarInk")
        val findFgSoft = findFg.copy(alpha = 0.62f)

        // ── Continuous vertical page column with document-level zoom/pan ─────
        // layerBackdrop + background live INSIDE this Box so the captured layer holds
        // the dark base + PDF pages; the glass chrome samples it (real reflections).
        Box(
            Modifier
                .fillMaxSize()
                .layerBackdrop(contentBackdrop)
                .background(if (isLight) Color(0xFF0A0E14).copy(0.85f) else Color(0xFF020305).copy(0.88f))
                .clipToBounds()
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { containerHeightPx = it.height; containerWidthPx = it.width }
                    // Book mode (#84): a sideways swipe turns the page. Outside the pan handler, so a
                    // zoomed-in pan still sees the finger first; a markup drag consumes it first.
                    .then(
                        if (!bookMode || activeTool != PdfEditTool.None) Modifier
                        else Modifier.pointerInput(state.pageCount) {
                            var dx = 0f
                            detectHorizontalDragGestures(
                                onDragStart = { dx = 0f },
                                onHorizontalDrag = { _, amount -> dx += amount },
                                onDragEnd = {
                                    if (scale <= 1.01f && !textSelection.gestureActive && kotlin.math.abs(dx) > 48.dp.toPx()) {
                                        val info = listState.layoutInfo
                                        val shown = info.visibleItemsInfo
                                            .minByOrNull { kotlin.math.abs(it.offset + it.size / 2 - info.viewportEndOffset / 2) }
                                            ?.index ?: listState.firstVisibleItemIndex
                                        val target = (shown + if (dx < 0f) 1 else -1).coerceIn(0, safePageCount - 1)
                                        viewerScope.launch { listState.animateScrollToItem(target) }
                                        lastInteractionAtMs = System.currentTimeMillis()
                                    }
                                }
                            )
                        }
                    )
                    // Long-press → select word. First in the chain so, once it fires, it can consume
                    // in the Initial pass ahead of the zoom/tap handlers and the page list.
                    .pdfTextSelectionGestures(
                        state = textSelection,
                        autoScroller = selectionAutoScroller,
                        haptics = haptics,
                        enabled = { activeTool == PdfEditTool.None },
                        onSelectionStarted = { autoScroll = false; lastInteractionAtMs = System.currentTimeMillis() }
                    )
                    .then(
                        // Keep pinch zoom available in Select Text mode. Other editing tools own
                        // the page gesture surface because their strokes/shapes need the drag.
                        if (activeTool != PdfEditTool.None) Modifier
                        else Modifier.pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false)
                                var accumulatedPan = Offset.Zero
                                // A one-finger pan only starts past touch slop, and a drag a page
                                // child claimed first (moving or resizing a markup, an image) keeps
                                // the finger for the whole gesture: the page stays put under it (#88).
                                var childOwnsDrag = false
                                var panStarted = false
                                do {
                                    val event = awaitPointerEvent()
                                    // A selection drag owns the finger: no one-finger pan underneath it.
                                    if (textSelection.gestureActive) continue
                                    val oneFinger = event.changes.count { it.pressed } <= 1
                                    if (oneFinger && event.changes.any { it.isConsumed }) childOwnsDrag = true
                                    if (childOwnsDrag && oneFinger) continue
                                    // A second finger down is unambiguously a pinch, never a tap. Without
                                    // this, these events reached the sibling `detectTapGestures` below
                                    // untouched — a fast pinch (fingers briefly reporting as separate
                                    // down/up pairs) could register as a double-tap there and its
                                    // onDoubleTap reset zoom back to 1x mid-gesture (#93).
                                    if (!oneFinger) event.changes.forEach { it.consume() }
                                    val zoomChange = event.calculateZoom()
                                    var panChange  = event.calculatePan()
                                    accumulatedPan += panChange
                                    // A tap may hide the chrome, but must not stop reading. Stop only
                                    // after a real drag or pinch takes ownership of the page.
                                    if (autoScroll && (zoomChange != 1f || accumulatedPan.getDistance() > viewConfiguration.touchSlop)) {
                                        autoScroll = false
                                    }
                                    if (!panStarted) {
                                        if (oneFinger && zoomChange == 1f && accumulatedPan.getDistance() <= viewConfiguration.touchSlop) continue
                                        // Catch up on the movement held back while waiting for slop.
                                        panStarted = true
                                        panChange = accumulatedPan
                                    }
                                    val zoomed = scale > 1.001f
                                    if (zoomChange != 1f || zoomed) {
                                        // Same reasoning as the two-finger consume above, for the
                                        // single-finger pan that continues after a pinch zooms in.
                                        event.changes.forEach { it.consume() }
                                        val cw = size.width.toFloat()
                                        val oldScale = scale
                                        val newScale = (oldScale * zoomChange).coerceIn(1f, 5f)
                                        // Real zoom ratio AFTER clamping — drives the focal correction.
                                        val effZoom = if (oldScale != 0f) newScale / oldScale else 1f
                                        val centroid = event.calculateCentroid(useCurrent = true)
                                        val center = cw / 2f
                                        val maxOffsetX = ((cw * newScale - cw) / 2f).coerceAtLeast(0f)
                                        // Synchronous state writes — no per-event coroutine (Pdf_Tools parity).
                                        scale = newScale
                                        if (newScale > 1f) {
                                            // FOCAL zoom: shift so the pinch centroid stays under the fingers
                                            // (layer origin is top-CENTER on X), THEN apply the finger pan.
                                            // Without this the page scaled around the centre, so zoom landed
                                            // "beside" where you pinched.
                                            val focalDx = if (centroid.isSpecified) (1f - effZoom) * (centroid.x - center - offsetX) else 0f
                                            offsetX = (offsetX + focalDx + panChange.x).coerceIn(-maxOffsetX, maxOffsetX)
                                            // Vertical is LazyColumn scroll in UNSCALED px (layer origin is TOP
                                            // on Y): the focal term keeps the centroid's row put, the pan term
                                            // tracks the finger (divided by scale for 1:1 at higher zoom).
                                            val focalDy = if (centroid.isSpecified) centroid.y * (1f / oldScale - 1f / newScale) else 0f
                                            val totalDy = focalDy + (-panChange.y / newScale)
                                            if (totalDy != 0f) listState.dispatchRawDelta(totalDy)
                                        } else {
                                            offsetX = 0f
                                        }
                                        lastInteractionAtMs = System.currentTimeMillis()
                                    }
                                } while (event.changes.any { it.pressed })
                            }
                        }
                    )
                    .pointerInput(activeTool) {
                        detectTapGestures(
                            onTap = {
                                // Tap outside clears a text selection (and does nothing else), like a
                                // TextView; otherwise it toggles the reading chrome.
                                // A selected markup (highlight / shape / note with its Edit bar) is
                                // dismissed the same way, from ANY page — the page-local tap layer only
                                // saw taps on its own page, so the bar could not be dismissed elsewhere.
                                if (textSelection.hasSelection) textSelection.clear()
                                else if (selectedAnnoIndex >= 0 || selectedMarkupGroup.isNotEmpty()) {
                                    selectedAnnoPage = null; selectedAnnoIndex = -1
                                    selectedMarkupGroupPage = null; selectedMarkupGroup = emptySet()
                                }
                                else if (activeTool == PdfEditTool.None) controlsVisible = !controlsVisible
                                lastInteractionAtMs = System.currentTimeMillis()
                            },
                            onDoubleTap = { tap ->
                                if (activeTool != PdfEditTool.None) return@detectTapGestures
                                val cw = size.width.toFloat()
                                val s0 = scale
                                val target = if (s0 > 1.5f) 1f else 2.5f
                                val maxOffsetX = ((cw * target - cw) / 2f).coerceAtLeast(0f)
                                // Horizontal focal: keep the tapped X under the finger
                                // (graphicsLayer origin is top-CENTER, so translationX compensates).
                                val focalX = if (target > 1f) ((cw / 2f - tap.x) * (target - 1f)).coerceIn(-maxOffsetX, maxOffsetX) else 0f
                                // Vertical focal: the layer is TOP-anchored, so keep the tapped Y
                                // under the finger by scrolling the list Δ = tap.y*(1/s0 - 1/target).
                                val scrollDelta = tap.y * (1f / s0 - 1f / target)
                                val focalSpec = androidx.compose.animation.core.spring<Float>(
                                    dampingRatio = Spring.DampingRatioNoBouncy,
                                    stiffness    = Spring.StiffnessMediumLow
                                )
                                viewerScope.launch { animateZoomPan(target, Offset(focalX, 0f)) }
                                viewerScope.launch { listState.animateScrollBy(scrollDelta, focalSpec) }
                                lastInteractionAtMs = System.currentTimeMillis()
                            }
                        )
                    }
            ) {
                val extraBottomPadding = if (scale > 1f && containerHeightPx > 0)
                    with(LocalDensity.current) { (containerHeightPx * ((scale - 1f) / scale)).toDp() } else 0.dp

                Box(
                    Modifier.fillMaxSize().graphicsLayer {
                        scaleX = scale; scaleY = scale
                        translationX = offsetX; translationY = 0f
                        transformOrigin = androidx.compose.ui.graphics.TransformOrigin(0.5f, 0f)
                    }.onGloballyPositioned { textSelection.registerLayer(it) }
                ) {
                    LazyColumn(
                        state = listState,
                        flingBehavior = if (bookMode) bookFling else pageFling,
                        userScrollEnabled = activeTool == PdfEditTool.None && scale <= 1.01f,
                        modifier = Modifier.fillMaxSize(),
                        // Center the block when it's shorter than the viewport (e.g. a
                        // single page) so it sits neatly centered instead of pinned to
                        // the top with a dark blank half below. No effect once content
                        // overflows (multi-page / zoomed), where it scrolls normally.
                        verticalArrangement = Arrangement.Center,
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                            top = if (bookMode) 0.dp else 4.dp,
                            bottom = (if (bookMode) 0.dp else 4.dp) + extraBottomPadding
                        )
                    ) {
                        items(count = safePageCount, key = { it }, contentType = { "pdfPage" }) { page ->
                            // Book mode (#84): each page fits the screen, centred in a screen-tall slot.
                            val bookSlot = if (bookMode) Modifier.fillParentMaxSize() else null
                            val bookPage = if (!bookMode) Modifier else {
                                val sz = pageBitmapSizes[page] ?: pageBitmapSizes.values.firstOrNull { it.width > 0f && it.height > 0f }
                                val aspect = sz?.takeIf { it.height > 0f }
                                    ?.let { (it.width * (contentCrop?.width() ?: 1f)) / (it.height * (contentCrop?.height() ?: 1f)) }
                                val gap = with(density) { 12.dp.toPx() }
                                if (aspect == null || containerHeightPx <= 0 || containerWidthPx <= 0) Modifier
                                else Modifier.width(with(density) { minOf(containerWidthPx.toFloat(), (containerHeightPx - gap) * aspect).toDp() })
                            }
                            // Re-request whenever this page has no bitmap (covers cache eviction
                            // while the item stays composed in the lazy list).
                            val needsRender = state.pageBitmaps.getOrNull(page) == null
                            LaunchedEffect(page, renderWidthPx, needsRender) {
                                if (needsRender) viewModel.renderPage(context, page, renderWidthPx)
                            }
                            // Dark reader keeps photographs as printed (Gander's night mode).
                            LaunchedEffect(page, darkPageAppearance, needsRender) {
                                if (darkPageAppearance && !needsRender) viewModel.ensureNightPhotos(context, page)
                            }
                            OptionalSlot(bookSlot) {
                            PdfContinuousPage(
                                page               = page,
                                backdrop           = backdrop,
                                bitmap             = state.pageBitmaps.getOrNull(page),
                                modifier           = bookPage,
                                crop               = contentCrop,
                                darkPageAppearance = darkPageAppearance,
                                nightPhotos        = if (darkPageAppearance) viewModel.nightPhotos[page].orEmpty() else emptyList(),
                                marks              = getPageMarks(page),
                                textEditPatches    = textEditPatches,
                                detailTile         = detailTiles[page],
                                formWidgets        = state.formWidgetsByPage[page].orEmpty(),
                                formValues         = formValues,
                                formEditing        = formEditing,
                                focusedFormKey     = focusedForm?.key,
                                onTapFormWidget    = onTapFormWidget,
                                onFormTextChange   = { w, v ->
                                    if (w.type == com.kyant.pdfcore.form.PdfFormWidget.Type.LIST) {
                                        haptics.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.SegmentTick)
                                    }
                                    setFormValue(w, v)
                                },
                                onFormImeNext      = { w ->
                                    val i = formOrder.indexOfFirst { it.key == w.key }
                                    focusedForm = formOrder.getOrNull(i + 1)
                                },
                                links              = state.linksByPage[page].orEmpty(),
                                onOpenLink         = onOpenLink,
                                ocrBlocks          = state.ocrBlocksByPage[page].orEmpty(),
                                findMatches        = state.findMatches,
                                currentMatchIndex  = state.currentMatchIndex,
                                showFindBar        = showFindBar,
                                activeTool         = activeTool,
                                currentColor       = currentColor,
                                currentStrokeWidth = currentStrokeWidth,
                                activeImageId      = activeImageId,
                                pageCanvasSizes    = pageCanvasSizes,
                                pageBitmapSizes    = pageBitmapSizes,
                                onInteraction      = { lastInteractionAtMs = System.currentTimeMillis() },
                                onMarkAdded        = { recordEdit(page) },
                                onToggleControls   = { controlsVisible = !controlsVisible },
                                onShowControls     = { controlsVisible = true },
                                onActiveToolChanged     = { activeTool = it },
                                onActiveImageIdChanged  = { activeImageId = it },
                                onPlaceText             = { pt ->
                                    // One Text tool: tapping the page's own text edits that line in
                                    // place (same font); tapping empty space places a new text box.
                                    val canvas = pageCanvasSizes[page]
                                    val hitLine = canvas?.takeIf { it.width > 0f && it.height > 0f }?.let { cs ->
                                        val nx = pt.x / cs.width; val ny = pt.y / cs.height
                                        state.ocrBlocksByPage[page].orEmpty().firstOrNull { b ->
                                            b.style != null && nx >= b.left - 0.004f && nx <= b.right + 0.004f &&
                                                ny >= b.top - 0.004f && ny <= b.bottom + 0.004f
                                        }
                                    }
                                    if (hitLine != null) {
                                        val existing = getPageMarks(page).firstOrNull {
                                            it is PdfMarkup.TextEditMarkup && it.blockId == hitLine.id
                                        } as? PdfMarkup.TextEditMarkup
                                        textEditTarget = TextEditTarget(page, hitLine, existing?.id)
                                    } else {
                                        val id = System.nanoTime()
                                        getPageMarks(page).add(PdfMarkup.TextBoxMarkup(id, pt, "", currentColor, 40f))
                                        recordEdit(page)
                                        editingAnnoId = id; editingAnnoPage = page; editingAnnoIsNote = false; annotationDraft = ""
                                    }
                                    activeTool = PdfEditTool.None; controlsVisible = true
                                },
                                onPlaceNote             = { pt ->
                                    val id = System.nanoTime()
                                    getPageMarks(page).add(PdfMarkup.NoteMarkup(id, pt, "", Color(0xFFFFC107)))
                                    recordEdit(page)
                                    editingAnnoId = id; editingAnnoPage = page; editingAnnoIsNote = true; annotationDraft = ""
                                    activeTool = PdfEditTool.None; controlsVisible = true
                                },
                                onEditAnnotation        = annotationEdit@{ id ->
                                    (getPageMarks(page).firstOrNull { it is PdfMarkup.TextEditMarkup && it.id == id } as? PdfMarkup.TextEditMarkup)?.let { te ->
                                        val block = state.ocrBlocksByPage[page].orEmpty().firstOrNull { it.id == te.blockId }
                                        textEditTarget = TextEditTarget(page, block, te.id)
                                        return@annotationEdit
                                    }
                                    val m = getPageMarks(page).firstOrNull {
                                        (it is PdfMarkup.TextBoxMarkup && it.id == id) || (it is PdfMarkup.NoteMarkup && it.id == id)
                                    }
                                    editingAnnoId = id; editingAnnoPage = page
                                    editingAnnoIsNote = m is PdfMarkup.NoteMarkup
                                    annotationDraft = when (m) {
                                        is PdfMarkup.TextBoxMarkup -> m.text
                                        is PdfMarkup.NoteMarkup    -> m.text
                                        else -> ""
                                    }
                                    editingAnnoColor = when (m) {
                                        is PdfMarkup.TextBoxMarkup -> m.color
                                        is PdfMarkup.NoteMarkup    -> m.color
                                        else -> LiquidGlassColors.Blue
                                    }
                                    controlsVisible = true
                                },
                                onEditShape             = { idx ->
                                    editingShapePage = page; editingShapeIndex = idx; controlsVisible = true
                                },
                                selectedMarkupIndex     = if (page == selectedAnnoPage) selectedAnnoIndex else -1,
                                selectedMarkupIndices   = if (page == selectedMarkupGroupPage) selectedMarkupGroup else emptySet(),
                                onSelectMarkup          = { idx ->
                                    if (idx < 0) {
                                        selectedAnnoPage = null; selectedAnnoIndex = -1
                                        selectedMarkupGroupPage = null; selectedMarkupGroup = emptySet()
                                    }
                                    else {
                                        selectedAnnoPage = page; selectedAnnoIndex = idx
                                        selectedMarkupGroupPage = null; selectedMarkupGroup = emptySet()
                                        textSelection.clear()
                                    }
                                },
                                onSelectMarkups        = { indices ->
                                    selectedAnnoPage = null; selectedAnnoIndex = -1
                                    selectedMarkupGroupPage = page.takeIf { indices.size > 1 }
                                    selectedMarkupGroup = indices
                                },
                                onMoveMarkups           = { indices, delta ->
                                    val pageMarks = getPageMarks(page)
                                    indices.sorted().forEach { idx ->
                                        pageMarks.getOrNull(idx)?.let { markup ->
                                            pageMarks[idx] = markup.translated(delta)
                                        }
                                    }
                                },
                                onDeleteMarkup          = { idx ->
                                    val m = getPageMarks(page)
                                    val target = m.getOrNull(idx)
                                    // A highlight/underline/strike over a multi-line selection is
                                    // several sibling markups (one per line) stamped with the same
                                    // groupId when they were created. Deleting one must delete the
                                    // whole passage, on every page it touches, or tapping the ONE
                                    // line under your finger only ever "deleted a word" out of the
                                    // paragraph you actually selected.
                                    val groupId = when (target) {
                                        is PdfMarkup.TextBlockHighlightMarkup -> target.groupId
                                        is PdfMarkup.TextBlockLineMarkup -> target.groupId
                                        else -> 0L
                                    }
                                    if (groupId != 0L) {
                                        annotationsByPage.keys.toList().forEach { pg ->
                                            val pageMarks = getPageMarks(pg)
                                            val before = pageMarks.size
                                            pageMarks.removeAll { mk ->
                                                (mk is PdfMarkup.TextBlockHighlightMarkup && mk.groupId == groupId) ||
                                                    (mk is PdfMarkup.TextBlockLineMarkup && mk.groupId == groupId)
                                            }
                                            if (pageMarks.size != before) recordEdit(pg)
                                        }
                                    } else if (idx in m.indices) {
                                        m.removeAt(idx)
                                    }
                                    selectedAnnoPage = null; selectedAnnoIndex = -1
                                    selectedMarkupGroupPage = null; selectedMarkupGroup = emptySet()
                                },
                                textSelection = textSelection,
                                markupBar = markupBarHost,
                                onMoveImageToPage = { from, img, to ->
                                    val fromSize = pageCanvasSizes[from]
                                    val toSize = pageCanvasSizes[to]
                                    if (to !in 0 until safePageCount || fromSize == null || toSize == null) false
                                    else {
                                        // Page gap = the two 6 dp item paddings, in the same unscaled px.
                                        val gapPx = with(density) { 12.dp.toPx() }
                                        val ih = img.end.y - img.start.y
                                        val top = if (to > from) img.start.y - fromSize.height - gapPx
                                                  else img.start.y + toSize.height + gapPx
                                        val ny = top.coerceIn(0f, (toSize.height - ih).coerceAtLeast(0f))
                                        getPageMarks(from).removeAll { it is PdfMarkup.ImageMarkup && it.id == img.id }
                                        getPageMarks(to).add(img.copy(start = Offset(img.start.x, ny), end = Offset(img.end.x, ny + ih)))
                                        recordEdit(from); recordEdit(to)
                                        true
                                    }
                                }
                            )
                            }
                        }
                    }
                }
            }
        }

        // ── Text-selection handles + magnifier (outside the zoom layer: fixed on-screen size) ──
        PdfSelectionHandles(
            state = textSelection,
            listState = listState,
            autoScroller = selectionAutoScroller,
            pageBitmaps = state.pageBitmaps
        )

        // ── Page scrubber (doubles as the fading scroll indicator) ─────────
        // Always present on multi-page docs so fast scrubbing is one drag away,
        // independent of the auto-hiding chrome. It brightens the moment the list
        // scrolls/flings and gently fades back to a slim idle state when at rest,
        // so it reads as an iOS-style scroll indicator without a second element.
        // Held while the rail itself is being dragged. Dragging it does not scroll the list (that
        // only happens on release), so without this the idle fade would run mid-drag and take the
        // thumbnail preview down to 40% opacity — which reads as the preview "half disappearing".
        var scrubberDragging by remember { mutableStateOf(false) }
        val scrubberBright = listState.isScrollInProgress || scrubberDragging
        val scrubberAlpha by androidx.compose.animation.core.animateFloatAsState(
            targetValue = if (scrubberBright) 1f else 0.4f,
            animationSpec = tween(durationMillis = if (scrubberBright) 120 else 600),
            label = "scrubberFade"
        )
        AnimatedVisibility(
            visible  = safePageCount > 1 && scale <= 1.01f,
            enter    = fadeIn(androidx.compose.animation.core.spring(stiffness = Spring.StiffnessMedium)) + scaleIn(initialScale = 0.92f, animationSpec = androidx.compose.animation.core.spring(dampingRatio = Spring.DampingRatioMediumBouncy)),
            exit     = fadeOut(androidx.compose.animation.core.spring(stiffness = Spring.StiffnessMedium)) + scaleOut(targetScale = 0.92f),
            modifier = Modifier.align(Alignment.CenterEnd).graphicsLayer { alpha = scrubberAlpha }.navigationBarsPadding().statusBarsPadding().padding(end = 8.dp)
        ) {
            PageScrubber(
                currentPage      = currentPageIndex,
                pageCount        = safePageCount,
                pageBitmaps      = state.pageBitmaps,
                backdrop         = contentBackdrop,
                uiSensor         = uiSensor,
                onPageChange     = { page -> scrollToPage(page) },
                onPageScrubbing  = { page -> viewModel.renderPage(context, page, 400); lastInteractionAtMs = System.currentTimeMillis() },
                onDraggingChange = { scrubberDragging = it },
                isScrolling      = listState.isScrollInProgress,
                darkPageAppearance = darkPageAppearance
            )
        }

        // ── Top + bottom controls overlay ──────────────────────────────────
        Box(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(16.dp)
        ) {
            // Top bar
            AnimatedVisibility(
                visible  = controlsVisible,
                enter    = fadeIn(tween(200)) + slideInVertically { -it / 2 },
                exit     = fadeOut(tween(150)) + slideOutVertically { -it / 2 },
                modifier = Modifier.align(Alignment.TopCenter)
            ) {
                // Home and Tools' header trio, verbatim: back circle · centred [GlassTitlePill] ·
                // search circle, 10 dp apart. The pill is the same widget carrying "Oryza Viewer" on
                // Home rather than a look-alike `LiquidButton`, so the two screens can't drift; only
                // the palette differs, because the viewer picks its chrome from the *page's*
                // luminance instead of the theme.
                //
                // Page navigation lives in the right-edge scrubber + scroll, so no oversized
                // prev/next controls cover the document.
                Row(
                    verticalAlignment     = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier              = Modifier.fillMaxWidth()
                ) {
                    // Each control picks its own ink from what is behind it (book mode's letterbox,
                    // a page edge, a photo), with the bar's band reading as the fallback.
                    val backInk = rememberAdaptiveInk(topFg)
                    val pillInk = rememberAdaptiveInk(topFg)
                    val findInk = rememberAdaptiveInk(topFg)
                    val moonInk = rememberAdaptiveInk(topFg)
                    // No `surfaceColor`, exactly as Home calls it: the circle paints nothing of its own
                    // and is pure refraction. Only the icon's colour adapts to the page.
                    GlassBackButton(
                        onBack = { requestExit() },
                        backdrop = contentBackdrop,
                        modifier = backInk.modifier,
                        foreground = backInk.color,
                        surfaceColor = Color.Unspecified,
                        onLongPressBack = if (hasUnsavedEdits) ({ requestExit() }) else LocalBackToLibraryAction.current,
                        longPressLabel = if (hasUnsavedEdits) stringResource(R.string.back) else null
                    )
                    // A weighted Box rather than two weighted spacers: the back circle and the
                    // search circle are the same 40 dp, so this centres the pill on the row exactly
                    // the way Home's header does, and a long "Page 100 / 1000" grows symmetrically.
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        GlassTitlePill(
                            text = stringResource(R.string.viewer_page_of, currentPageIndex + 1, safePageCount),
                            backdrop = contentBackdrop,
                            modifier = pillInk.modifier,
                            onClick = { showPageJumpDialog = true },
                            // Transparent, not omitted: omitting falls back to the theme's 0.35 tint,
                            // and this pill sits between two circles that paint nothing at all, so any
                            // tint at all makes it read as a slab bolted between two pieces of glass.
                            // `drawRect(Color.Transparent)` is the same no-op `LiquidIconButton`
                            // performs when it is given no `surfaceColor`.
                            surfaceColor = Color.Transparent,
                            contentColor = pillInk.color,
                            // The enclosing AnimatedVisibility already slides and fades the whole bar
                            // in every time the chrome returns; the pill's own spring would stack on
                            // top of that and read as a stutter. Same call the find bar makes.
                            animateIn = false
                        )
                    }
                    LiquidIconButton(
                        onClick = {
                            showFindBar = !showFindBar
                            if (showFindBar) viewModel.triggerOcrForAllPages(context)
                            else { focusManager.clearFocus(); viewModel.clearSearch(); findQuery = "" }
                        },
                        backdrop = contentBackdrop,
                        modifier = findInk.modifier
                    ) {
                        Icon(Icons.Rounded.Search, stringResource(R.string.viewer_find), Modifier.size(20.dp), findInk.color)
                    }
                    LiquidIconButton(
                        onClick = { darkPageOverride = !darkPageAppearance },
                        backdrop = contentBackdrop,
                        modifier = moonInk.modifier
                    ) {
                        Icon(
                            if (darkPageAppearance) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                            stringResource(if (darkPageAppearance) R.string.viewer_page_colors_original else R.string.viewer_page_dark_mode),
                            Modifier.size(20.dp),
                            moonInk.color
                        )
                    }
                }
            }

            // Brief confirmation that the optional Office engine rendered this file, so installing
            // it has a visible effect (before, nothing told the user which renderer was used).
            var showEngineChip by remember(state.renderedByOfficeEngine, state.document) {
                mutableStateOf(state.renderedByOfficeEngine)
            }
            LaunchedEffect(showEngineChip) {
                if (showEngineChip) { kotlinx.coroutines.delay(2800L); showEngineChip = false }
            }
            AnimatedVisibility(
                visible  = showEngineChip,
                enter    = fadeIn(spring(stiffness = 300f)),
                exit     = fadeOut(tween(220)),
                modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 76.dp)
            ) {
                Row(
                    Modifier
                        .viewerGlass(contentBackdrop, viewerChromeGlass(isDarkMode), shape = { com.kyant.shapes.Capsule })
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(7.dp)
                ) {
                    Icon(Icons.Rounded.AutoAwesome, null, Modifier.size(16.dp), LiquidGlassColors.Teal)
                    BasicText(
                        stringResource(R.string.office_engine_rendered),
                        style = TextStyle(topFg, 13.sp, fontWeight = FontWeight.SemiBold)
                    )
                }
            }

            // One-time Office engine suggestion after a built-in Office render. Glass fades only
            // (translating glass re-runs its blur + lens).
            AnimatedVisibility(
                visible  = state.showOfficeEngineHint && controlsVisible,
                enter    = fadeIn(spring(stiffness = 300f)),
                exit     = fadeOut(tween(150)),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 92.dp)
            ) {
                OfficeEngineHintCard(
                    backdrop  = contentBackdrop,
                    isDark    = isDarkMode,
                    fg        = bottomFg,
                    onGet     = {
                        com.ashuiw.oryzaviewer.office.OfficeEngine.installer(context).install()
                        viewModel.dismissOfficeEngineHint(context)
                        com.ashuiw.oryzaviewer.office.OfficeEngine.focusSettingsSection.value = true
                        onOpenOfficeEngineSettings()
                    },
                    onDismiss = { viewModel.dismissOfficeEngineHint(context) }
                )
            }

            AnimatedVisibility(
                visible = controlsVisible && selectedMarkupGroup.size > 1,
                enter = fadeIn(tween(140)) + scaleIn(initialScale = 0.96f),
                exit = fadeOut(tween(120)) + scaleOut(targetScale = 0.96f),
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 88.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Lasso-selecting several markups and asking to delete them was previously only
                    // possible one at a time (the group pill only offered "Done"/deselect) — the same
                    // "selecting a group doesn't let you delete the group" complaint as the highlight
                    // groupId fix above, for the lasso tool's own multi-select.
                    LiquidButton(
                        onClick = {
                            val page = selectedMarkupGroupPage
                            if (page != null) {
                                val m = getPageMarks(page)
                                selectedMarkupGroup.sortedDescending().forEach { i -> if (i in m.indices) m.removeAt(i) }
                                recordEdit(page)
                            }
                            selectedMarkupGroup = emptySet()
                            selectedMarkupGroupPage = null
                            lastInteractionAtMs = System.currentTimeMillis()
                        },
                        backdrop = contentBackdrop,
                        tint = LiquidGlassColors.Red
                    ) {
                        Icon(Icons.Rounded.Delete, stringResource(R.string.delete), Modifier.size(16.dp), Color.White)
                    }
                    LiquidButton(
                        onClick = {
                            selectedMarkupGroup = emptySet()
                            selectedMarkupGroupPage = null
                            lastInteractionAtMs = System.currentTimeMillis()
                        },
                        backdrop = contentBackdrop,
                        surfaceColor = chromeField
                    ) {
                        BasicText(
                            stringResource(R.string.viewer_lasso_selected_count, selectedMarkupGroup.size) +
                                " · " + stringResource(R.string.viewer_lasso_done),
                            style = TextStyle(bottomFg, 13.sp, fontWeight = FontWeight.SemiBold)
                        )
                    }
                }
            }

            // Bottom toolbar
            AnimatedVisibility(
                visible  = controlsVisible,
                enter    = fadeIn(tween(200)) + slideInVertically { it / 2 },
                exit     = fadeOut(tween(150)) + slideOutVertically { it / 2 },
                modifier = Modifier.align(Alignment.BottomCenter)
            ) {
                val activeItem = activeImageLoc()?.third

                PdfViewerBottomToolbar(
                    readerTourStep     = readerTourStep,
                    onReaderTourNext   = { if (readerTourStep < 2) readerTourStep += 1 else finishReaderTour() },
                    onReaderTourDismiss = ::finishReaderTour,
                    activeTool         = activeTool,
                    drawingToolActive  = drawingToolActive,
                    showFindBar        = showFindBar,
                    showSignaturePad   = showSignaturePad,
                    autoScrollActive = autoScroll,
                    autoScrollSpeed = autoScrollSpeed,
                    activeImageId      = activeImageId,
                    currentColor       = currentColor,
                    currentColorLong   = currentColorLong,
                    currentStrokeWidth = currentStrokeWidth,
                    zoomScale          = scale,
                    hasEdits           = annotationsByPage.values.any { it.isNotEmpty() },
                    isExporting        = state.isExporting,
                    exportError        = state.exportError,
                    exportMessage      = state.exportMessage,
                    lastExportedUri    = state.lastExportedUri,
                    activeIsSignature  = activeItem?.isSignature == true,
                    // Undo is history-driven, not page-driven. Two earlier attempts keyed it to a
                    // page index — first `state.currentPage` (async, lagged behind the scroll), then
                    // `listState.firstVisibleItemIndex` (the first *partially* visible page, which
                    // while you draw is usually a sliver of the PREVIOUS page). Both removed from the
                    // wrong, usually empty, list. There is no page index that reliably means "what
                    // the user just did", so the viewer records each addition instead.
                    canUndo            = undoStack.isNotEmpty() || annotationsByPage.any { it.value.isNotEmpty() },
                    onUndo             = { undoLastEdit(); lastInteractionAtMs = System.currentTimeMillis() },
                    onClearPage        = { clearVisiblePage(); lastInteractionAtMs = System.currentTimeMillis() },
                    onSetActiveTool    = {
                        activeTool = it
                        if (it == PdfEditTool.None) activeImageId = null
                        selectedAnnoPage = null; selectedAnnoIndex = -1
                        if (it != PdfEditTool.None) { selectedMarkupGroupPage = null; selectedMarkupGroup = emptySet() }
                        textSelection.clear()
                    },
                    onToggleFindBar    = {
                        showFindBar = !showFindBar
                        if (showFindBar) viewModel.triggerOcrForAllPages(context)
                        else { focusManager.clearFocus(); viewModel.clearSearch(); findQuery = "" }
                    },
                    onShowSignaturePad = { showSignaturePad = true },
                    onPickImage        = { activeImageId = null; imagePickerLauncher.launch("image/*") },
                    onZoomStep         = { step ->
                        val startScale = scale
                        val targetScale = (startScale + step).coerceIn(1f, 5f)
                        if (targetScale != startScale) {
                            // Keep the point under the viewport centre steady while the glass
                            // zoom rail changes scale, just like a focal pinch or double tap.
                            val focusY = containerHeightPx / 2f
                            val scrollDelta = focusY * (1f / startScale - 1f / targetScale)
                            val focalSpec = androidx.compose.animation.core.spring<Float>(
                                dampingRatio = Spring.DampingRatioNoBouncy,
                                stiffness = Spring.StiffnessMediumLow
                            )
                            viewerScope.launch { animateZoomPan(targetScale, Offset(offsetX, 0f)) }
                            viewerScope.launch { listState.animateScrollBy(scrollDelta, focalSpec) }
                        }
                        lastInteractionAtMs = System.currentTimeMillis()
                    },
                    onResetZoom        = { scope.launch { animateZoomPan(1f, Offset.Zero) }
                                          lastInteractionAtMs = System.currentTimeMillis() },
                    onShowSaveDialog   = { showSaveDialog = true },
                    onImageDone        = { activeImageId = null; activeTool = PdfEditTool.None },
                    onReplaceImage     = {
                        if (activeItem?.isSignature == true) showSignaturePad = true
                        else imagePickerLauncher.launch("image/*")
                    },
                    onDeleteImage      = {
                        activeImageLoc()?.let { (pg, idx, _) -> getPageMarks(pg).removeAt(idx) }
                        activeImageId = null; activeTool = PdfEditTool.None
                    },
                    onSetColorLong   = { currentColorLong = it },
                    onSetStrokeWidth = { currentStrokeWidth = it },
                    onDismissExportFeedback = { viewModel.clearExportFeedback() },
                    onOpenExportedFile = { state.lastExportedUri?.let { viewModel.openPdf(context, it) } },
                    onOpenAnotherPdf   = { pdfPickerLauncher.launch(arrayOf("*/*")) },
                    onEditorOpenChanged = { editorToolsOpen = it },
                    // Bumping the timestamp on RELEASE is half the fix: otherwise the hold ends and
                    // the effect resumes a window that is already most of the way expired, so the
                    // chrome blinks out a moment after the finger lifts.
                    onShareHoldChanged = { shareHolding = it; lastInteractionAtMs = System.currentTimeMillis() },
                    // Share now opens the export chooser instead of firing a PDF straight out — a
                    // .docx used to always leave as the converted PDF, silently. The dialog lets the
                    // user pick the original file vs a PDF (and encrypt the PDF). See ExportShareDialog.
                    onShareDocument    = { showShareDialog = true },
                    onToggleAutoScroll = {
                        autoScroll = !autoScroll
                        controlsVisible = true
                        lastInteractionAtMs = System.currentTimeMillis()
                    },
                    onCycleAutoScrollSpeed = {
                        autoScrollSpeed = when (autoScrollSpeed) {
                            0.75f -> 1f
                            1f -> 1.5f
                            1.5f -> 2f
                            else -> 0.75f
                        }
                        lastInteractionAtMs = System.currentTimeMillis()
                    },
                    onRecolorSignature = { cl ->
                        activeImageLoc()?.let { (pg, idx, sig) ->
                            if (sig.isSignature) getPageMarks(pg)[idx] = sig.copy(bitmap = recolorSignatureBitmap(sig.bitmap, Color(cl).toArgb()))
                        }
                    },
                    backdrop = contentBackdrop,
                    uiSensor = uiSensor,
                    fg       = bottomFg,
                    fgSoft   = bottomFgSoft,
                    glass    = chromeGlass,
                    chip     = chromeField,
                    docKind  = com.ashuiw.oryzaviewer.utils.docKindOf(state.fileName)
                )
            }
        }

        // ── Find bar ──────────────────────────────────────────────────────
        AnimatedVisibility(
            visible  = showFindBar,
            enter    = fadeIn(tween(220)) + expandVertically(tween(280), Alignment.Bottom) + scaleIn(initialScale = 0.96f),
            exit     = fadeOut(tween(150)) + shrinkVertically(tween(180), Alignment.Bottom) + scaleOut(targetScale = 0.96f),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .windowInsetsPadding(WindowInsets.navigationBars.union(WindowInsets.ime))
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            PdfSearchBar(
                query             = findQuery,
                matchCount        = state.findMatches.size,
                currentMatchIndex = state.currentMatchIndex,
                focusRequester    = findFocusRequester,
                backdrop          = contentBackdrop,
                uiSensor          = uiSensor,
                fg                = findFg,
                fgSoft            = findFgSoft,
                // Clear, like the top bar's title pill and circles — only the ink adapts.
                surface           = Color.Transparent,
                onQueryChange     = { q -> findQuery = q; viewModel.searchText(q) },
                onPrevMatch       = { viewModel.prevMatch(); lastInteractionAtMs = System.currentTimeMillis() },
                onNextMatch       = { viewModel.nextMatch(); lastInteractionAtMs = System.currentTimeMillis() },
                onClose           = { showFindBar = false; focusManager.clearFocus(); findQuery = ""; viewModel.clearSearch() }
            )
        }

        // ── Floating liquid-glass selection toolbar (above the chrome, like the platform's) ──
        suspend fun selectionTextLoaded(): String {
            val span = textSelection.pageSpan() ?: return ""
            val missing = span.any { it !in viewModel.uiState.value.ocrBlocksByPage }
            if (missing) {
                viewModel.triggerOcrForAllPages(context)
                withTimeoutOrNull(10_000) {
                    viewModel.uiState.first { st -> span.all { it in st.ocrBlocksByPage } }
                }
            }
            return textSelection.selectedText()
        }
        fun startSafely(intent: Intent) {
            runCatching {
                if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        }
        fun applyToSelection(
            snapToWords: Boolean = false,
            block: (page: Int, marks: MutableList<PdfMarkup>, range: OcrTextRange, groupId: Long) -> Boolean
        ) {
            // One id for every markup this single call creates, even across pages (a highlight can
            // span a page break) and across the several per-line markups one multi-line selection
            // becomes. Lets a later tap-to-delete remove the whole passage instead of one line of it
            // — see [PdfMarkup.TextBlockHighlightMarkup.groupId].
            val groupId = System.nanoTime()
            textSelection.rangesByPage().forEach { (page, ranges) ->
                val marks = getPageMarks(page)
                var changed = false
                // Marking actions (highlight / underline / strike) cover whole words, like Acrobat:
                // a handle dragged back a few characters must not leave "Engin|eering" half-marked.
                val pageBlocks = if (snapToWords) state.ocrBlocksByPage[page].orEmpty().associateBy { it.id } else emptyMap()
                ranges.forEach { raw ->
                    val r = if (snapToWords) pageBlocks[raw.blockId]?.let { raw.snappedToWords(it.text) } ?: raw else raw
                    if (block(page, marks, r, groupId)) changed = true
                }
                if (changed) recordEdit(page)
            }
            lastInteractionAtMs = System.currentTimeMillis()
        }
        val selectionActions = PdfSelectionActions(
            onCopy = {
                viewerScope.launch {
                    val t = selectionTextLoaded()
                    if (t.isNotBlank()) {
                        clipboard.setText(AnnotatedString(t))
                        haptics.performHapticFeedback(HapticFeedbackType.Confirm)
                        copiedTick++
                    }
                    textSelection.clear()
                }
            },
            onSelectAll = {
                // The whole document. Pages whose text is not extracted yet join the highlight as
                // they load (the end caret is clamped per page).
                viewModel.triggerOcrForAllPages(context)
                textSelection.select(TextPos(0, 0), TextPos(safePageCount - 1, Int.MAX_VALUE))
            },
            onShare = {
                viewerScope.launch {
                    val t = selectionTextLoaded()
                    if (t.isNotBlank()) {
                        startSafely(Intent.createChooser(
                            Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t), null
                        ))
                    }
                    textSelection.clear()
                }
            },
            onHighlight = { colorLong ->
                currentColorLong = colorLong
                applyToSelection(snapToWords = true) { _, m, r, groupId ->
                    // Re-highlighting replaces (recolours) highlights inside the range instead of stacking.
                    m.removeAll { it is PdfMarkup.TextBlockHighlightMarkup && it.blockId == r.blockId && it.start >= r.start && it.end <= r.end }
                    m.add(PdfMarkup.TextBlockHighlightMarkup(r.blockId, Color(colorLong), 0.38f, r.start, r.end, groupId))
                    true
                }
                textSelection.clear()
            },
            onUnderline = {
                applyToSelection(snapToWords = true) { _, m, r, groupId ->
                    if (m.any { it is PdfMarkup.TextBlockLineMarkup && it.blockId == r.blockId && it.start == r.start && it.end == r.end && !it.strikeThrough }) false
                    else m.add(PdfMarkup.TextBlockLineMarkup(r.blockId, Color(currentColorLong), 3f, 1f, false, r.start, r.end, groupId))
                }
                textSelection.clear()
            },
            onStrike = {
                applyToSelection(snapToWords = true) { _, m, r, groupId ->
                    if (m.any { it is PdfMarkup.TextBlockLineMarkup && it.blockId == r.blockId && it.start == r.start && it.end == r.end && it.strikeThrough }) false
                    else m.add(PdfMarkup.TextBlockLineMarkup(r.blockId, Color(currentColorLong), 3f, 1f, true, r.start, r.end, groupId))
                }
                textSelection.clear()
            },
            onRemoveHighlight = {
                textSelection.rangesByPage().forEach { (page, ranges) ->
                    val marks = getPageMarks(page)
                    var changed = false
                    ranges.forEach { r ->
                        // Trim, don't blanket-remove: a highlighted PARAGRAPH is one or more
                        // TextBlockHighlightMarkup per line (see groupId above), and each line's own
                        // markup can easily cover more than the word you then select inside it —
                        // removing the whole markup on any overlap deleted the highlight off the
                        // entire line for a one-word selection. Split the overlapping markup instead,
                        // keeping whatever's left on either side of the removed span.
                        var i = 0
                        while (i < marks.size) {
                            val m = marks[i] as? PdfMarkup.TextBlockHighlightMarkup
                            if (m == null || m.blockId != r.blockId || m.start >= r.end || m.end <= r.start) {
                                i++; continue
                            }
                            val replacements = buildList {
                                if (m.start < r.start) add(m.copy(start = m.start, end = r.start))
                                if (m.end > r.end) add(m.copy(start = r.end, end = m.end))
                            }
                            marks.removeAt(i)
                            marks.addAll(i, replacements)
                            i += replacements.size
                            changed = true
                        }
                    }
                    if (changed) recordEdit(page)
                }
                textSelection.clear()
            },
            onSearch = {
                val q = textSelection.selectedText().replace(Regex("\\s+"), " ").trim().take(80)
                textSelection.clear()
                if (q.isNotEmpty()) {
                    showFindBar = true
                    findQuery = q
                    viewModel.triggerOcrForAllPages(context)
                    viewModel.searchText(q)
                }
            },
            onProcessText = { component ->
                viewerScope.launch {
                    val t = selectionTextLoaded()
                    if (t.isNotBlank()) {
                        startSafely(
                            Intent(Intent.ACTION_PROCESS_TEXT)
                                .setComponent(component)
                                .setType("text/plain")
                                .putExtra(Intent.EXTRA_PROCESS_TEXT, t)
                                .putExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, true)
                        )
                    }
                }
            },
            // Long-press a word → "Edit text": rewrite that line in place, in its own font.
            editableLine = {
                val ranges = textSelection.rangesByPage()
                val single = ranges.entries.singleOrNull()?.takeIf { it.value.map { r -> r.blockId }.distinct().size == 1 }
                single?.let { (pg, rs) ->
                    state.ocrBlocksByPage[pg].orEmpty().firstOrNull { it.id == rs.first().blockId && it.style != null }
                        ?.let { pg to it }
                }
            },
            onEditText = { pg, block ->
                val existing = getPageMarks(pg).firstOrNull {
                    it is PdfMarkup.TextEditMarkup && it.blockId == block.id
                } as? PdfMarkup.TextEditMarkup
                // Only what was selected is edited; the rest of the line stays exactly as it is.
                val selected = textSelection.rangesByPage()[pg].orEmpty().filter { it.blockId == block.id }
                val range = if (selected.isEmpty()) null else {
                    val a = selected.minOf { it.start }.coerceIn(0, block.text.length)
                    val b = selected.maxOf { it.end }.coerceIn(a, block.text.length)
                    (a until b).takeIf { b > a && (a > 0 || b < block.text.length) }
                }
                textSelection.clear()
                textEditTarget = TextEditTarget(pg, block, existing?.id, range)
            }
        )
        // A lambda, evaluated inside the toolbar: reading the selection here would recompose this
        // whole screen on every handle-drag step.
        val hasHighlightOverlap: () -> Boolean = {
            textSelection.hasSelection && textSelection.rangesByPage().any { (page, ranges) ->
                annotationsByPage[page].orEmpty().any { m ->
                    m is PdfMarkup.TextBlockHighlightMarkup && ranges.any { r -> r.blockId == m.blockId && m.start < r.end && m.end > r.start }
                }
            }
        }
        // Floating contextual chrome, in the title-chip glass over the live page, with ink sampled from
        // the document behind each control (same band sampling as the bars).
        val pageLuminanceAt: (Float, Float) -> Float = { top, bottom ->
            bandLuminance(listState.layoutInfo, state.pageBitmaps, scale, top, bottom, darkPageAppearance, pageFrame = pageFrameOf)
        }
        PdfMarkupBarLayer(
            host = markupBarHost,
            textSelection = textSelection,
            listState = listState,
            backdrop = contentBackdrop,
            luminanceAt = pageLuminanceAt,
            appearanceKey = darkPageAppearance
        )
        PdfSelectionToolbar(
            state = textSelection,
            listState = listState,
            backdrop = contentBackdrop,
            actions = selectionActions,
            highlightColor = currentColor,
            hasHighlightOverlap = hasHighlightOverlap,
            luminanceAt = pageLuminanceAt,
            appearanceKey = darkPageAppearance
        )
        // The form accessory: previous / next field, Done, and a choice field's options.
        focusedForm?.let { w ->
            BackHandler { focusedForm = null }
            val i = formOrder.indexOfFirst { it.key == w.key }
            val imeUp = androidx.compose.foundation.layout.WindowInsets.ime.getBottom(LocalDensity.current) > 0
            PdfFormAccessoryBar(
                widget = w,
                backdrop = contentBackdrop,
                ink = panelFg,
                glass = chromePanel,
                canPrevious = i > 0,
                canNext = i in 0 until formOrder.lastIndex,
                onPrevious = { formOrder.getOrNull(i - 1)?.let { focusedForm = it } },
                onNext = { formOrder.getOrNull(i + 1)?.let { focusedForm = it } },
                onDone = { keyboard?.hide(); focusedForm = null },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .imePadding()
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp)
                    .padding(bottom = if (imeUp) 8.dp else 104.dp)
            )
        }
        PdfFormChoiceMenu(
            widget = formMenu,
            anchor = formMenuAnchor,
            value = formMenu?.let { formValueOf(it) }.orEmpty(),
            // The menu belongs to the page, so dark reader makes it dark too, whatever the app theme.
            dark = darkPageAppearance || com.ashuiw.oryzaviewer.ui.theme.LocalIsDarkMode.current,
            onPick = { option ->
                formMenu?.let { w ->
                    haptics.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.SegmentTick)
                    setFormValue(w, option)
                }
                formMenu = null
            },
            onDismiss = { formMenu = null }
        )
        com.ashuiw.oryzaviewer.ui.components.GlassGuideCallout(
            visible = showFormTour && state.formWidgetsByPage.isNotEmpty() && focusedForm == null && formMenu == null,
            title = stringResource(R.string.tour_form_title),
            message = stringResource(R.string.tour_form_message),
            backdrop = contentBackdrop,
            isLastStep = true,
            onNext = { showFormTour = false; OnboardingManager.markFormFillTourSeen(context) },
            onSkip = { showFormTour = false; OnboardingManager.markFormFillTourSeen(context) },
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(start = 16.dp, end = 16.dp, top = 76.dp)
        )

        PdfCopiedToast(
            trigger = copiedTick,
            backdrop = contentBackdrop,
            modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = 112.dp),
            onLight = bottomBarLight
        )

        // ── Page-jump popup (in-window, so it samples the liquid-glass backdrop) ──
        LiquidPageJumpPopup(
            visible      = showPageJumpDialog,
            currentPage  = currentPageIndex,
            pageCount    = safePageCount,
            backdrop     = contentBackdrop,
            bookmarkedPages = bookmarkedPages,
            onDismiss    = { showPageJumpDialog = false },
            onJumpToPage = { targetPage -> showPageJumpDialog = false; scrollToPage(targetPage) },
            onToggleCurrentBookmark = {
                bookmarkUri?.let { uri -> bookmarkedPages = PdfPageBookmarksManager.toggle(context, uri, currentPageIndex) }
            },
            onRemoveBookmark = { page ->
                bookmarkUri?.let { uri -> bookmarkedPages = PdfPageBookmarksManager.toggle(context, uri, page) }
            }
        )

        // ── In-place edit of the page's own text ──
        textEditTarget?.let { target ->
            val list = getPageMarks(target.page)
            val existing = target.markupId?.let { id ->
                list.firstOrNull { it is PdfMarkup.TextEditMarkup && it.id == id } as? PdfMarkup.TextEditMarkup
            }
            val original = existing?.original ?: target.block?.text.orEmpty()
            val current = existing?.text ?: original
            val segment = target.selection?.let { sel ->
                selectionInCurrent(original, current, sel.first, sel.last + 1).takeIf { !it.isEmpty() }
            }
            TextEditDialog(
                initialText = segment?.let { current.substring(it.first, it.last + 1) } ?: current,
                original = segment?.let { current.substring(it.first, it.last + 1) } ?: original,
                selectionOnly = segment != null,
                backdrop = contentBackdrop,
                canRevert = existing != null && segment == null,
                onDismiss = { textEditTarget = null },
                onRevert = {
                    list.removeAll { it is PdfMarkup.TextEditMarkup && it.id == existing?.id }
                    recordEdit(target.page)
                    selectedAnnoPage = null; selectedAnnoIndex = -1
                    textEditTarget = null
                },
                onSave = { edited ->
                    val newText = segment?.let { current.replaceRange(it.first, it.last + 1, edited) } ?: edited
                    if (existing != null) {
                        val i = list.indexOf(existing)
                        if (i >= 0) {
                            if (newText == existing.original) list.removeAt(i) else list[i] = existing.copy(text = newText)
                            recordEdit(target.page)
                        }
                    } else if (newText != original) {
                        val block = target.block
                        val style = block?.style
                        val canvas = pageCanvasSizes[target.page]
                        if (block != null && style != null && canvas != null) {
                            list.add(textEditMarkupFor(block, style, canvas, state.pageBitmaps.getOrNull(target.page), newText))
                            recordEdit(target.page)
                        }
                    }
                    selectedAnnoPage = null; selectedAnnoIndex = -1
                    textEditTarget = null
                }
            )
        }

        // ── Text / note editor (in-window, samples the real page backdrop) ──
        editingAnnoId?.let { annoId ->
            fun matches(m: PdfMarkup) =
                (m is PdfMarkup.TextBoxMarkup && m.id == annoId) || (m is PdfMarkup.NoteMarkup && m.id == annoId)
            AnnotationEditorDialog(
                isNote = editingAnnoIsNote,
                initialText = annotationDraft,
                initialColor = editingAnnoColor,
                backdrop = contentBackdrop,
                onDismiss = {
                    getPageMarks(editingAnnoPage).removeAll { m -> matches(m) &&
                        ((m is PdfMarkup.TextBoxMarkup && m.text.isBlank()) || (m is PdfMarkup.NoteMarkup && m.text.isBlank())) }
                    editingAnnoId = null
                },
                onDelete = {
                    getPageMarks(editingAnnoPage).removeAll { matches(it) }
                    editingAnnoId = null
                },
                initialFontSize = getPageMarks(editingAnnoPage)
                    .firstOrNull { it is PdfMarkup.TextBoxMarkup && it.id == annoId }
                    ?.let { (it as PdfMarkup.TextBoxMarkup).fontSize },
                onSave = { newText, newColor, newSize ->
                    val list = getPageMarks(editingAnnoPage)
                    val idx = list.indexOfFirst { matches(it) }
                    if (idx >= 0) {
                        if (newText.isBlank() && list[idx] is PdfMarkup.TextBoxMarkup) list.removeAt(idx)
                        else list[idx] = when (val m = list[idx]) {
                            is PdfMarkup.TextBoxMarkup -> m.copy(text = newText, color = newColor, fontSize = newSize ?: m.fontSize)
                            is PdfMarkup.NoteMarkup    -> m.copy(text = newText, color = newColor)
                            else -> m
                        }
                    }
                    editingAnnoId = null
                }
            )
        }

        // ── Shape editor (recolour / delete a placed rect / oval / line / arrow / stroke) ──
        editingShapePage?.let { shapePage ->
            val list = getPageMarks(shapePage)
            val shape = list.getOrNull(editingShapeIndex)
            if (shape != null && shape.isRecolorable()) {
                ShapeEditorPopup(
                    initialColor = shape.shapeColor(),
                    backdrop = contentBackdrop,
                    uiSensor = uiSensor,
                    fg = panelFg,
                    fgSoft = panelFgSoft,
                    surface = chromePanel,
                    field = chromeField,
                    onColorChange = { c ->
                        val cur = list.getOrNull(editingShapeIndex)
                        if (cur != null && cur.isRecolorable()) list[editingShapeIndex] = cur.recolored(c)
                        lastInteractionAtMs = System.currentTimeMillis()
                    },
                    onDelete = {
                        if (editingShapeIndex in list.indices) list.removeAt(editingShapeIndex)
                        editingShapePage = null; editingShapeIndex = -1
                    },
                    onDismiss = { editingShapePage = null; editingShapeIndex = -1 }
                )
            } else {
                editingShapePage = null; editingShapeIndex = -1
            }
        }

        // ── Save Document — REAL in-window glass (samples the live page) ──
        LiquidSaveSheet(
            visible         = showSaveDialog,
            initialFileName = state.document?.name?.substringBeforeLast('.')?.let { "${it}_Edited" } ?: "Document",
            backdrop        = contentBackdrop,
            uiSensor        = uiSensor,
            fg              = panelFg,
            fgSoft          = panelFgSoft,
            surface         = chromePanel,
            field           = chromeField,
            onDismiss       = { showSaveDialog = false; exitAfterSave = false },
            onSave          = { fileName, overrideUri ->
                showSaveDialog = false
                val snapshot = markupSnapshot()
                val overlays = buildExportOverlays(annotationsByPage, state.ocrBlocksByPage, pageCanvasSizes, pageBitmapSizes)
                if (overlays.isNotEmpty()) {
                    pendingSaveMarkups = snapshot
                    viewModel.exportEditedPdf(context, overlays, fileName, overrideUri)
                } else {
                    // Nothing exportable (e.g. only empty text boxes) — nothing to lose either.
                    savedMarkups = snapshot
                    if (exitAfterSave) { exitAfterSave = false; onBack() }
                }
            }
        )

        // ── Unsaved changes — same card as the spreadsheet, refracting the live page ──
        // Save routes through the normal Save sheet (file name / location), then leaves once the
        // export succeeds (see the exportMessage effect above).
        UnsavedChangesDialog(
            visible   = showUnsavedDialog,
            onDiscard = { showUnsavedDialog = false; onBack() },
            onCancel  = { showUnsavedDialog = false },
            onSave    = { showUnsavedDialog = false; exitAfterSave = true; showSaveDialog = true },
            backdrop  = contentBackdrop
        )

        // ── Share / export chooser ──
        // Original vs PDF (with optional encryption). `originalExt` is null for a plain PDF, which
        // collapses the dialog to just the encrypt toggle.
        val shareExt = state.fileName.substringAfterLast('.', "").uppercase()
        // The file a Share or a Save a copy hands over, built off the main thread: copy/encrypt into
        // cacheDir/shared, which the app FileProvider serves (file_paths.xml cache-path "/").
        fun buildSharePayload(format: ShareFormat, encrypt: Boolean, password: String): Pair<android.net.Uri, String>? =
            runCatching {
                fun wrap(u: android.net.Uri): android.net.Uri =
                    if (u.scheme == "file")
                        androidx.core.content.FileProvider.getUriForFile(
                            context, "${context.packageName}.provider", java.io.File(u.path!!)
                        )
                    else u
                val shareDir = java.io.File(context.cacheDir, "shared").apply { mkdirs() }
                // Unsaved edits travel with the share: build an edited copy first and
                // make every PDF-derived format (PDF, images, text) from it.
                val edited: android.net.Uri? = if (hasUnsavedEdits && format != ShareFormat.ORIGINAL) {
                    val overlays = buildExportOverlays(annotationsByPage, state.ocrBlocksByPage, pageCanvasSizes, pageBitmapSizes)
                    val name = state.fileName.substringBeforeLast('.').ifBlank { "document" }
                        .replace(Regex("[^A-Za-z0-9._-]"), "_")
                    viewModel.writeEditedCopy(context, overlays, java.io.File(shareDir, "${name}_edited.pdf"))
                } else null
                val sourcePdf = edited ?: state.document?.uri
                when (format) {
                    ShareFormat.IMAGES -> sourcePdf?.let { pdf ->
                        val stem = state.fileName.substringBeforeLast('.').ifBlank { "page" }
                            .replace(Regex("[^A-Za-z0-9._-]"), "_")
                        val count = state.pageCount.coerceAtLeast(1)
                        val uris = ArrayList<android.net.Uri>()
                        for (p in 0 until count) {
                            val bmp = com.kyant.pdfcore.raster.PdfRasterizer.rasterizePageBitmap(context, pdf, p) ?: continue
                            val f = java.io.File(shareDir, "${stem}_${p + 1}.png")
                            f.outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, it) }
                            bmp.recycle()
                            uris += androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.provider", f)
                        }
                        shareMultiple = uris
                        uris.firstOrNull()?.let { it to "image/png" }
                    }
                    ShareFormat.TEXT -> sourcePdf?.let { pdf ->
                        val stem = state.fileName.substringBeforeLast('.').ifBlank { "document" }
                            .replace(Regex("[^A-Za-z0-9._-]"), "_")
                        val f = java.io.File(shareDir, "$stem.txt")
                        f.writeText(viewModel.extractAllText(context, pdf))
                        androidx.core.content.FileProvider.getUriForFile(context, "${context.packageName}.provider", f) to "text/plain"
                    }
                    ShareFormat.ORIGINAL -> state.originalUri?.let { orig ->
                        // Mirror the original into our own storage so the target app can
                        // actually read it — a SAF uri from another provider can't be
                        // re-granted to a third app.
                        val safeName = state.fileName.ifBlank { "document.$shareExt" }
                            .replace(Regex("[^A-Za-z0-9._-]"), "_")
                        val out = java.io.File(shareDir, "${System.currentTimeMillis()}_$safeName")
                        context.contentResolver.openInputStream(orig)?.use { input ->
                            out.outputStream().use { input.copyTo(it) }
                        } ?: return@runCatching null
                        androidx.core.content.FileProvider.getUriForFile(
                            context, "${context.packageName}.provider", out
                        ) to (context.contentResolver.getType(orig) ?: "application/octet-stream")
                    }
                    ShareFormat.PDF -> sourcePdf?.let { pdf ->
                        if (encrypt && password.isNotBlank()) {
                            val out = java.io.File(shareDir, "protected_${System.currentTimeMillis()}.pdf")
                            val outUri = androidx.core.content.FileProvider.getUriForFile(
                                context, "${context.packageName}.provider", out
                            )
                            com.kyant.pdfcore.security.PdfSecurityService.encryptToUri(context, pdf, outUri, password)
                            outUri to "application/pdf"
                        } else {
                            wrap(pdf) to "application/pdf"
                        }
                    }
                }
            }.getOrNull()
        // Save a copy (#76): the file the user picked, as it is (or as the chosen format), to a
        // place they choose. The format etc. wait here while the system save screen is up.
        var pendingSaveCopy by remember { mutableStateOf<Triple<ShareFormat, Boolean, String>?>(null) }
        val saveCopyLauncher = rememberLauncherForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
        ) { res ->
            val target = res.data?.data
            val req = pendingSaveCopy
            pendingSaveCopy = null
            if (res.resultCode != android.app.Activity.RESULT_OK || target == null || req == null) return@rememberLauncherForActivityResult
            viewerScope.launch {
                val ok = withContext(Dispatchers.IO) {
                    runCatching {
                        val (src, _) = buildSharePayload(req.first, req.second, req.third) ?: return@runCatching false
                        shareMultiple = emptyList()
                        context.contentResolver.openInputStream(src)?.use { input ->
                            context.contentResolver.openOutputStream(target, "w")?.use { input.copyTo(it) }
                        } != null
                    }.getOrDefault(false)
                }
                android.widget.Toast.makeText(
                    context,
                    if (ok) R.string.viewer_save_copy_done else R.string.viewer_save_copy_failed,
                    android.widget.Toast.LENGTH_SHORT
                ).show()
            }
        }
        ExportShareDialog(
            visible     = showShareDialog,
            originalExt = if (shareExt.isNotBlank() && shareExt != "PDF") shareExt else null,
            backdrop    = contentBackdrop,
            onDismiss   = { showShareDialog = false },
            onPrint     = state.document?.uri?.let { docUri ->
                {
                    showShareDialog = false
                    if (!com.ashuiw.oryzaviewer.utils.PdfPrint.print(context, docUri, state.fileName.substringBeforeLast('.')))
                        android.widget.Toast.makeText(context, R.string.docx_print_failed, android.widget.Toast.LENGTH_SHORT).show()
                }
            },
            onSaveCopy  = { format, encrypt, password ->
                showShareDialog = false
                // Unedited, a copy keeps the file's own name (no "_Edited").
                val stem = state.fileName.substringBeforeLast('.').ifBlank { "document" }
                val (name, mime) = when (format) {
                    ShareFormat.ORIGINAL -> state.fileName.ifBlank { "document.${shareExt.lowercase()}" } to
                        (state.originalUri?.let { context.contentResolver.getType(it) } ?: "application/octet-stream")
                    ShareFormat.TEXT -> "$stem.txt" to "text/plain"
                    else -> (if (hasUnsavedEdits) "${stem}_Edited.pdf" else "$stem.pdf") to "application/pdf"
                }
                pendingSaveCopy = Triple(format, encrypt, password)
                runCatching {
                    saveCopyLauncher.launch(
                        Intent(Intent.ACTION_CREATE_DOCUMENT)
                            .addCategory(Intent.CATEGORY_OPENABLE)
                            .setType(mime)
                            .putExtra(Intent.EXTRA_TITLE, name)
                    )
                }.onFailure { pendingSaveCopy = null }
            },
            onShare     = { format, encrypt, password ->
                showShareDialog = false
                viewerScope.launch {
                    val payload = withContext(Dispatchers.IO) { buildSharePayload(format, encrypt, password) }
                    if (payload != null) {
                        val (shareUri, mime) = payload
                        val many = shareMultiple
                        shareMultiple = emptyList()
                        val send = if (many.size > 1) {
                            android.content.Intent(android.content.Intent.ACTION_SEND_MULTIPLE).apply {
                                type = mime
                                putParcelableArrayListExtra(android.content.Intent.EXTRA_STREAM, ArrayList(many))
                                addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                        } else android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = mime
                            putExtra(android.content.Intent.EXTRA_STREAM, shareUri)
                            addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        }
                        runCatching {
                            context.startActivity(
                                android.content.Intent.createChooser(send, null)
                                    .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                            )
                        }
                    }
                }
            }
        )

        // ── Opening curtain ────────────────────────────────────────────────
        // The very same dark curtain the no-document branch shows while a handed-in file loads, now
        // held over the freshly-loaded viewer until page 1 has actually rendered — so the reader is
        // never flashed a blank white page card. Because both branches paint the identical opaque
        // fill and spinner, the hand-off between them is invisible; only when the first bitmap arrives
        // does this fade away, letting the real document appear underneath. That is what makes tapping
        // a recent read as "wait a beat, then the PDF fades in" instead of a hard cut to an empty page.
        val firstPageRendered = state.pageBitmaps.getOrNull(state.currentPage) != null
        var revealDocument by remember { mutableStateOf(false) }
        LaunchedEffect(firstPageRendered) {
            if (firstPageRendered && !revealDocument) {
                // Lift the curtain once the page has actually been drawn — two frames, not a fixed
                // 140 ms guess that left a fast-loading file waiting behind an empty curtain.
                androidx.compose.runtime.withFrameNanos { }
                androidx.compose.runtime.withFrameNanos { }
                revealDocument = true
            }
        }
        AnimatedVisibility(
            visible  = !revealDocument,
            // A quicker, ease-out dissolve: the page is ready, so get out of its way.
            exit     = fadeOut(tween(300, easing = androidx.compose.animation.core.LinearOutSlowInEasing)),
            modifier = Modifier.fillMaxSize()
        ) {
            ViewerLoadingCurtain(isLight = isLight, darkPage = darkPageAppearance)
        }
    }

    // ── Dialogs ───────────────────────────────────────────────────────────

    if (showSignaturePad) {
        SignaturePadDialog(
            backdrop = backdrop,
            onDismiss = { showSignaturePad = false },
            onSignatureCaptured = { bmp ->
                showSignaturePad = false
                runCatching {
                    val safeBmp = when {
                        bmp.isRecycled -> null
                        bmp.config == Bitmap.Config.HARDWARE || !bmp.isMutable -> bmp.copy(Bitmap.Config.ARGB_8888, true)
                        else -> bmp
                    }
                    if (safeBmp != null && safeBmp.width > 0 && safeBmp.height > 0) {
                        placeImageMarkup(safeBmp, isSignature = true)
                    }
                }
            }
        )
    }

}

/**
 * A plain opaque fill shown while a handed-in document loads — no spinner, no indicator, nothing to
 * look at. It exists only so that (a) the "Open a PDF" picker never flashes before the pages arrive,
 * and (b) the loaded viewer can fade in from behind it. It's identical in the no-document branch and
 * the loaded overlay, so the branch swap is seamless; when the first page is ready the overlay simply
 * fades out (see the AnimatedVisibility that hosts it) to reveal the PDF. That fade is the whole
 * "opening" animation — deliberately just a dissolve.
 */
@Composable
private fun ViewerLoadingCurtain(isLight: Boolean, darkPage: Boolean = false) {
    val bg = if (isLight) Color(0xFF0A0E14) else Color(0xFF05070B)
    // A sheet of paper where page 1 will land (same top inset as the page list), so the opening zoom
    // shows a document arriving rather than a black void; the real page fades in over it.
    val sheet = if (darkPage) Color(0xFF16181C) else Color(0xFFF7F7F5)
    val shimmer = androidx.compose.animation.core.rememberInfiniteTransition(label = "sheetShimmer")
    val glow = shimmer.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable<Float>(tween(1100), androidx.compose.animation.core.RepeatMode.Reverse),
        label = "sheetGlow"
    )
    Box(Modifier.fillMaxSize().background(bg)) {
        Box(
            Modifier
                .padding(top = 10.dp)
                .fillMaxWidth()
                .aspectRatio(1f / 1.414f)
                .graphicsLayer { alpha = 0.92f + 0.08f * glow.value }
                .background(sheet)
        )
    }
}

/**
 * Cheap average perceptual luminance (0..1) of a page bitmap, sampled at a tiny
 * resolution. Drives the viewer's adaptive chrome contrast (dark ink on light pages,
 * white ink on dark pages).
 */
/**
 * Perceptual luminance of a vertical slice `[fTop, fBottom]` (fractions of height) of [bitmap],
 * sampled on a sparse 8x5 grid across the central 80% of the width. Deliberately uses `getPixel`
 * on the live bitmap rather than `createScaledBitmap` so it is cheap enough to run per scroll frame.
 * Central-width only: the far edges are usually margins that don't sit under a control.
 */
private fun regionLuminance(bitmap: Bitmap, fTop: Float, fBottom: Float): Float = runCatching {
    val w = bitmap.width
    val h = bitmap.height
    if (w <= 0 || h <= 0) return@runCatching 0f
    val y0 = (fTop.coerceIn(0f, 1f) * h).toInt().coerceIn(0, h - 1)
    val y1 = (fBottom.coerceIn(0f, 1f) * h).toInt().coerceIn(y0 + 1, h)
    val x0 = (w * 0.1f).toInt().coerceIn(0, w - 1)
    val x1 = (w * 0.9f).toInt().coerceIn(x0 + 1, w)
    val cols = 8
    val rows = 5
    var sum = 0.0
    var n = 0
    for (r in 0 until rows) {
        val py = (y0 + (y1 - y0) * (r + 0.5f) / rows).toInt().coerceIn(0, h - 1)
        for (c in 0 until cols) {
            val px = (x0 + (x1 - x0) * (c + 0.5f) / cols).toInt().coerceIn(0, w - 1)
            val p = bitmap.getPixel(px, py)
            val rr = ((p shr 16) and 0xFF) / 255.0
            val gg = ((p shr 8) and 0xFF) / 255.0
            val bb = (p and 0xFF) / 255.0
            sum += 0.299 * rr + 0.587 * gg + 0.114 * bb
            n++
        }
    }
    if (n == 0) 0f else (sum / n).toFloat()
}.getOrDefault(0f)

/**
 * Average luminance of the document content behind a screen-space horizontal band
 * `[screenTopPx, screenBottomPx]`, i.e. behind one of the floating bars.
 *
 * The content Box scales about a top origin with `translationY = 0`, and the LazyColumn's
 * `visibleItemsInfo.offset` is already in list-local (unscaled, viewport-relative, centring-folded)
 * coordinates — so a screen Y maps to list-local as `screenY / scale`. Each visible page item that
 * intersects the band contributes its overlapping slice, weighted by how much of the band it covers.
 * Returns 0 (→ dark → white ink) when the band sits over the empty letterbox with no page under it,
 * which is exactly what a single unzoomed page's centred layout should read as behind its bars.
 */
private fun bandLuminance(
    layoutInfo: LazyListLayoutInfo,
    pageBitmaps: List<Bitmap?>,
    scale: Float,
    screenTopPx: Float,
    screenBottomPx: Float,
    // Dark page appearance draws every page through an RGB-inverting colour matrix, so the pixels
    // on screen are 1 - (bitmap). Sampling the bitmap as-is read a white page behind a black one and
    // picked dark ink — the "icons invisible in dark mode" bug. Mirror the matrix here.
    inverted: Boolean = false,
    // Where a page really is, when it doesn't fill its list item: (bitmap frame top, frame height,
    // visible top, visible bottom) in the same list-local px. Book mode letterboxes the page inside
    // a screen-tall item, and trimmed margins show only part of a larger frame (#84, #85).
    pageFrame: (Int) -> FloatArray? = { null }
): Float {
    val s = scale.coerceAtLeast(0.01f)
    val lTop = screenTopPx / s
    val lBottom = screenBottomPx / s
    var lum = 0.0
    var weight = 0.0
    for (item in layoutInfo.visibleItemsInfo) {
        if (item.size <= 0) continue
        val f = pageFrame(item.index)
        val frameTop = f?.get(0) ?: item.offset.toFloat()
        val frameH = f?.get(1) ?: item.size.toFloat()
        if (frameH <= 0f) continue
        val io = f?.get(2) ?: frameTop
        val ib = f?.get(3) ?: (frameTop + frameH)
        val interTop = maxOf(io, lTop)
        val interBottom = minOf(ib, lBottom)
        val cover = interBottom - interTop
        if (cover <= 0f) continue
        val bmp = pageBitmaps.getOrNull(item.index) ?: continue
        val fTop = (interTop - frameTop) / frameH
        val fBottom = (interBottom - frameTop) / frameH
        val l = regionLuminance(bmp, fTop, fBottom)
        lum += (if (inverted) 1f - l else l).toDouble() * cover
        weight += cover.toDouble()
    }
    return if (weight <= 0.0) 0f else (lum / weight).toFloat()
}

private fun averageLuminance(bitmap: Bitmap): Float = runCatching {
    val w = 12
    val h = 16
    val scaled = Bitmap.createScaledBitmap(bitmap, w, h, true)
    val pixels = IntArray(w * h)
    scaled.getPixels(pixels, 0, w, 0, 0, w, h)
    if (scaled != bitmap) scaled.recycle()
    var sum = 0.0
    for (p in pixels) {
        val r = ((p shr 16) and 0xFF) / 255.0
        val g = ((p shr 8) and 0xFF) / 255.0
        val b = (p and 0xFF) / 255.0
        sum += 0.299 * r + 0.587 * g + 0.114 * b
    }
    (sum / pixels.size).toFloat()
}.getOrDefault(0f)

/**
 * Grows a line-local `[start, end)` range to whole-word boundaries (letters, digits and in-word
 * apostrophes/hyphens), after trimming surrounding spaces. Used by the marking actions only; copy and
 * share keep the exact selection.
 */
internal fun OcrTextRange.snappedToWords(text: String): OcrTextRange {
    if (text.isEmpty()) return this
    fun inWord(c: Char) = c.isLetterOrDigit() || c == '\'' || c == '\u2019' || c == '-' || c == '_'
    var a = start.coerceIn(0, text.length)
    var b = end.coerceIn(a, text.length)
    while (a < b && text[a].isWhitespace()) a++
    while (b > a && text[b - 1].isWhitespace()) b--
    if (a >= b) return this
    while (a > 0 && inWord(text[a - 1]) && inWord(text[a])) a--
    while (b < text.length && inWord(text[b]) && inWord(text[b - 1])) b++
    return copy(start = a, end = b)
}

/** [content] centred in a box with [slot] when there is one, otherwise placed as it is. */
@Composable
private fun OptionalSlot(slot: Modifier?, content: @Composable () -> Unit) {
    if (slot != null) Box(slot, contentAlignment = Alignment.Center) { content() } else content()
}
