package com.kyant.pdfcore.text

import android.content.Context
import android.net.Uri
import com.kyant.pdfcore.internal.PdfBox
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import com.tom_roush.pdfbox.text.TextPosition
import kotlin.math.abs
import kotlin.math.min

data class PdfTextBlock(
    val id: String,
    val text: String,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    // Per-text-character normalized x bounds, parallel to [text]. Enable word-precise
    // highlighting of a matched substring instead of the whole line.
    val charLefts: FloatArray = FloatArray(0),
    val charRights: FloatArray = FloatArray(0),
    /** How the line is drawn (from its first glyph) — lets an in-place edit preview match it. */
    val style: PdfTextStyle? = null
)

/**
 * A line's typography: [emNorm] is the font size and [baselineNorm] the baseline's y, both as
 * fractions of the (display) page height; the traits drive the closest Android typeface.
 */
data class PdfTextStyle(
    val fontName: String,
    val emNorm: Float,
    val baselineNorm: Float,
    val rgb: Int,
    val bold: Boolean,
    val italic: Boolean,
    val serif: Boolean,
    val mono: Boolean
)

/** A search hit as a normalized rect around the exact matched word(s), not the whole line. */
data class PdfSearchMatch(
    val pageIndex: Int,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
)

interface PdfTextService {
    fun extractPage(context: Context, uri: Uri, pageIndex: Int): List<PdfTextBlock>
    fun searchAll(context: Context, uri: Uri, query: String, pageCount: Int): List<PdfSearchMatch>
}

class PdfTextServiceImpl : PdfTextService {

    override fun extractPage(context: Context, uri: Uri, pageIndex: Int): List<PdfTextBlock> {
        PdfBox.ensureInitialized(context)
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                PDDocument.load(stream).use { doc ->
                    if (pageIndex !in 0 until doc.numberOfPages) return@runCatching emptyList()
                    extractPageBlocks(doc, pageIndex)
                }
            } ?: emptyList()
        }.getOrElse { emptyList() }
    }

    override fun searchAll(
        context: Context,
        uri: Uri,
        query: String,
        pageCount: Int
    ): List<PdfSearchMatch> {
        if (query.isBlank()) return emptyList()
        PdfBox.ensureInitialized(context)
        val lower = query.trim().lowercase()
        return runCatching {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                PDDocument.load(stream).use { doc ->
                    buildList {
                        for (pageIdx in 0 until min(doc.numberOfPages, pageCount)) {
                            extractPageBlocks(doc, pageIdx).forEach { block ->
                                addAll(block.matchRects(lower, pageIdx))
                            }
                        }
                    }
                }
            } ?: emptyList()
        }.getOrElse { emptyList() }
    }

    private fun extractPageBlocks(doc: PDDocument, pageIndex: Int): List<PdfTextBlock> {
        val page = doc.getPage(pageIndex)
        val rotation = page.rotation
        val box = page.cropBox ?: page.mediaBox ?: return emptyList()
        val pageW: Float
        val pageH: Float
        if (rotation == 90 || rotation == 270) {
            pageW = box.height
            pageH = box.width
        } else {
            pageW = box.width
            pageH = box.height
        }
        if (pageW <= 0f || pageH <= 0f) return emptyList()

        val stripper = PositionCapturingStripper().apply {
            startPage = pageIndex + 1
            endPage = pageIndex + 1
        }
        runCatching { stripper.getText(doc) }

        return groupPositionsIntoLines(stripper.positions, pageW, pageH, pageIndex, stripper.colors)
    }

    /** Per-font ascent/descent as fractions of the em, cached for the page being grouped. */
    private val fontMetricsCache = java.util.IdentityHashMap<Any, FloatArray>()

    private fun fontMetrics(tp: TextPosition): FloatArray {
        val font = tp.font ?: return DefaultMetrics
        return synchronized(fontMetricsCache) { fontMetricsCache[font] } ?: run {
            runCatching {
                val fd = font.fontDescriptor
                var ascent = fd?.ascent ?: 0f
                var descent = fd?.descent ?: 0f
                if (ascent <= 0f) ascent = fd?.capHeight?.takeIf { it > 0f }?.times(1.18f) ?: 0f
                if (ascent <= 0f || descent >= 0f) {
                    val bbox = font.boundingBox
                    if (ascent <= 0f && bbox != null) ascent = bbox.upperRightY
                    if (descent >= 0f && bbox != null) descent = bbox.lowerLeftY
                }
                // Glyph-space units are 1/1000 em for everything but Type 3 fonts. Clamp so a broken
                // descriptor (some PDFs carry 0 or bbox-sized values) can't produce absurd boxes.
                val a = (ascent / 1000f).takeIf { it.isFinite() && it > 0f }?.coerceIn(0.62f, 1.05f) ?: DefaultMetrics[0]
                val d = (-descent / 1000f).takeIf { it.isFinite() && it > 0f }?.coerceIn(0.12f, 0.32f) ?: DefaultMetrics[1]
                floatArrayOf(a, d)
            }.getOrDefault(DefaultMetrics).also { m -> synchronized(fontMetricsCache) { fontMetricsCache[font] = m } }
        }
    }

    /** Rendered font size in page units: the text rendering matrix's Y scale. */
    private fun emSize(tp: TextPosition): Float {
        val ys = tp.yScale
        if (ys.isFinite() && ys > 0.5f) return ys
        val pt = tp.fontSizeInPt
        return if (pt.isFinite() && pt > 0.5f) pt else tp.height.coerceAtLeast(1f) / 0.7f
    }

    private fun glyphAscent(tp: TextPosition): Float = emSize(tp) * fontMetrics(tp)[0]
    private fun glyphDescent(tp: TextPosition): Float = emSize(tp) * fontMetrics(tp)[1]

    private fun groupPositionsIntoLines(
        positions: List<TextPosition>,
        pageWidth: Float,
        pageHeight: Float,
        pageIndex: Int,
        colors: Map<TextPosition, Int> = emptyMap()
    ): List<PdfTextBlock> {
        if (positions.isEmpty()) return emptyList()
        synchronized(fontMetricsCache) { fontMetricsCache.clear() }

        val avgH = positions.map { it.height }.average().toFloat().coerceAtLeast(2f)
        val lineGap = avgH * 0.6f

        // Group by similar Y (baseline) into lines
        val sorted = positions.sortedBy { it.y }
        val lines = mutableListOf<MutableList<TextPosition>>()
        for (pos in sorted) {
            val last = lines.lastOrNull()
            if (last == null || abs(pos.y - last.first().y) > lineGap) {
                lines.add(mutableListOf(pos))
            } else {
                last.add(pos)
            }
        }

        // A "line" above is every glyph sharing a baseline across the FULL page width, so on a
        // two-column page the left and right columns' lines merged into one block ("...end of left
        // sentence start of right sentence..."). Split each line wherever the horizontal gap between
        // consecutive glyphs is far wider than any word space (> ~3x the line's average glyph
        // width): column gutters and wide table gaps become separate blocks, ordinary word spacing
        // (even justified) never reaches that.
        val segments = lines.flatMap { line ->
            val byX = line.sortedBy { it.x }
            val avgW = byX.map { it.width }.filter { it > 0f }.average().toFloat()
                .takeIf { !it.isNaN() && it > 0f } ?: avgH * 0.5f
            val splitGap = avgW * 3f
            val out = mutableListOf<MutableList<TextPosition>>()
            var lastRight = -Float.MAX_VALUE
            for (tp in byX) {
                if (out.isEmpty() || (lastRight > -Float.MAX_VALUE && tp.x - lastRight > splitGap)) {
                    out.add(mutableListOf(tp))
                } else {
                    out.last().add(tp)
                }
                lastRight = maxOf(lastRight, tp.x + tp.width)
            }
            out
        }

        return segments.mapIndexedNotNull { lineIdx, linePositions ->
            val byX = linePositions.sortedBy { it.x }
            val avgGlyphWidth = byX.map { it.width }.filter { it > 0f }.average().toFloat()
                .takeIf { it.isFinite() && it > 0f } ?: 1f
            val naturalGaps = byX.zipWithNext { previous, next -> next.x - (previous.x + previous.width) }
                // Large outliers are word spaces, not a useful estimate of glyph tracking.
                .filter { it.isFinite() && it > 0f && it < avgGlyphWidth * 0.55f }
                .sorted()
            val typicalTracking = naturalGaps.getOrNull(naturalGaps.size / 2) ?: 0f
            // A gap is a word break only when it clearly exceeds both the line's ordinary
            // tracking and a fraction of the average glyph width. Using just the current glyph's
            // width split tracked/justified words (especially after narrow letters) into pieces.
            val inferredWordGap = maxOf(
                avgGlyphWidth * 0.42f,
                (typicalTracking * 1.6f + avgGlyphWidth * 0.08f).coerceAtMost(avgGlyphWidth * 0.85f)
            )
            // Build the line text AND per-character x bounds together so indices stay aligned.
            val sb = StringBuilder()
            val cl = ArrayList<Float>()
            val cr = ArrayList<Float>()
            var lastRight = -Float.MAX_VALUE
            byX.forEach { tp ->
                val u = tp.unicode ?: ""
                if (u.isEmpty()) return@forEach
                val gap = tp.x - lastRight
                if (lastRight > -Float.MAX_VALUE && gap > inferredWordGap) {
                    sb.append(' '); cl.add(lastRight); cr.add(tp.x)
                }
                val x0 = tp.x; val x1 = tp.x + tp.width; val n = u.length
                for (i in u.indices) {
                    sb.append(u[i])
                    cl.add(x0 + (x1 - x0) * i / n)
                    cr.add(x0 + (x1 - x0) * (i + 1) / n)
                }
                lastRight = x1
            }
            val raw = sb.toString()
            val startI = raw.indexOfFirst { !it.isWhitespace() }
            val endI = raw.indexOfLast { !it.isWhitespace() }
            if (startI < 0) return@mapIndexedNotNull null
            val text = raw.substring(startI, endI + 1)
            val charLefts = FloatArray(endI - startI + 1) { (cl[startI + it] / pageWidth).coerceIn(0f, 1f) }
            val charRights = FloatArray(endI - startI + 1) { (cr[startI + it] / pageWidth).coerceIn(0f, 1f) }

            val minX = byX.minOf { it.x }
            val maxX = byX.maxOf { it.x + it.width }
            // Vertical extent from the FONT's ascent/descent at the rendered size, not
            // TextPosition.height: PdfBox's height is often near the x-height and the old box ended
            // at the baseline, so highlights sat low — clipping ascenders/caps above and leaving
            // descenders (g, p, y) hanging out below.
            val minY = byX.minOf { it.y - glyphAscent(it) }.coerceAtLeast(0f)
            val maxY = byX.maxOf { it.y + glyphDescent(it) }

            val first = byX.first()
            PdfTextBlock(
                id     = "$pageIndex-$lineIdx",
                text   = text,
                left   = (minX / pageWidth).coerceIn(0f, 1f),
                top    = (minY / pageHeight).coerceIn(0f, 1f),
                right  = (maxX / pageWidth).coerceIn(0f, 1f),
                bottom = (maxY / pageHeight).coerceIn(0f, 1f),
                charLefts  = charLefts,
                charRights = charRights,
                style = styleOf(first, pageHeight, colors[first] ?: 0)
            )
        }
    }
}

/** All occurrences of [lower] (already lower-cased) in this line, as tight word rects. */
fun PdfTextBlock.matchRects(lower: String, pageIndex: Int): List<PdfSearchMatch> {
    if (lower.isEmpty() || charLefts.isEmpty()) return emptyList()
    val bt = text.lowercase()
    val out = ArrayList<PdfSearchMatch>()
    // Right-to-left text is stored in visual order: look for the query's visual form too (#72).
    for (q in PdfBidi.searchForms(lower)) {
        var from = 0
        while (true) {
            val idx = bt.indexOf(q, from)
            if (idx < 0) break
            val endC = idx + q.length - 1
            if (idx < charLefts.size && endC < charRights.size) {
                out.add(PdfSearchMatch(pageIndex, charLefts[idx], top, charRights[endC], bottom))
            } else {
                out.add(PdfSearchMatch(pageIndex, left, top, right, bottom))
            }
            from = idx + q.length
        }
    }
    return out
}

private class PositionCapturingStripper : PDFTextStripper() {
    val positions = mutableListOf<TextPosition>()
    /** Fill colour each glyph was drawn in (only known while the page is being processed). */
    val colors = java.util.IdentityHashMap<TextPosition, Int>()

    override fun processTextPosition(text: TextPosition) {
        if (!text.unicode.isNullOrBlank()) {
            positions.add(text)
            runCatching { graphicsState.nonStrokingColor.toRGB() }.getOrNull()?.let { colors[text] = it }
        }
    }
}

private fun styleOf(tp: TextPosition, pageHeight: Float, rgb: Int): PdfTextStyle? = runCatching {
    val font = tp.font
    val name = (font?.name ?: "").substringAfter('+')
    val lower = name.lowercase()
    val d = font?.fontDescriptor
    val m = tp.textMatrix
    val em = kotlin.math.hypot(m.getValue(1, 0), m.getValue(1, 1)).takeIf { it > 0f } ?: tp.fontSizeInPt
    val mono = listOf("courier", "mono", "consol", "menlo").any { lower.contains(it) } || d?.isFixedPitch == true
    PdfTextStyle(
        fontName = name,
        emNorm = em / pageHeight,
        baselineNorm = tp.y / pageHeight,
        rgb = rgb,
        bold = listOf("bold", "black", "heavy", "semibold", "demi").any { lower.contains(it) } ||
            d?.isForceBold == true || (d?.fontWeight ?: 400f) >= 600f,
        italic = lower.contains("italic") || lower.contains("oblique") || d?.isItalic == true,
        serif = !mono && !lower.contains("sans") && (d?.isSerif == true ||
            listOf("times", "serif", "georgia", "garamond", "cambria", "book", "minion", "palatino", "baskerville").any { lower.contains(it) }),
        mono = mono
    )
}.getOrNull()

/** Typical Latin face: ascent 0.80 em, descent 0.20 em. */
private val DefaultMetrics = floatArrayOf(0.80f, 0.20f)
