package com.ashuiw.oryzaviewer.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.fastCoerceIn
import androidx.compose.ui.util.fastRoundToInt
import androidx.compose.ui.util.lerp
import com.ashuiw.oryzaviewer.ui.theme.LocalIsDarkMode
import com.ashuiw.oryzaviewer.ui.theme.LiquidGlassColors
import com.ashuiw.oryzaviewer.ui.utils.DampedDragAnimation
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberBackdrop
import com.kyant.backdrop.backdrops.rememberCombinedBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.highlight.Highlight
import com.kyant.backdrop.shadow.InnerShadow
import com.kyant.backdrop.shadow.Shadow
import com.kyant.shapes.Capsule
import kotlin.math.abs

@Composable
fun LiquidSlider(
    value: () -> Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    visibilityThreshold: Float,
    backdrop: Backdrop,
    modifier: Modifier = Modifier
) {
    val isDarkMode = LocalIsDarkMode.current
    val isLightTheme = !isDarkMode
    val accentColor = LiquidGlassColors.Blue
    val trackColor = if (isLightTheme) Color(0xFF787878).copy(0.2f) else Color(0xFF787880).copy(0.36f)

    val trackBackdrop = rememberLayerBackdrop()

    BoxWithConstraints(
        modifier = modifier.fillMaxWidth(),
        contentAlignment = Alignment.CenterStart
    ) {
        val trackWidth = constraints.maxWidth.coerceAtLeast(1)
        val isLtr = LocalLayoutDirection.current == LayoutDirection.Ltr
        val animationScope = rememberCoroutineScope()
        val currentValue = value().coerceIn(valueRange.start, valueRange.endInclusive)
        val onValueChangeState = rememberUpdatedState(onValueChange)
        var didDrag by remember { mutableStateOf(false) }
        var isDragging by remember { mutableStateOf(false) }

        val dampedDragAnimation = remember(
            animationScope,
            isLtr,
            trackWidth,
            valueRange.start,
            valueRange.endInclusive,
            visibilityThreshold
        ) {
            DampedDragAnimation(
                animationScope = animationScope,
                initialValue = currentValue,
                valueRange = valueRange,
                visibilityThreshold = visibilityThreshold,
                initialScale = 1f,
                pressedScale = 1.5f,
                onDragStarted = {
                    didDrag = false
                    isDragging = true
                },
                onDragStopped = {
                    isDragging = false
                    if (didDrag) {
                        onValueChangeState.value(targetValue.coerceIn(valueRange.start, valueRange.endInclusive))
                    }
                    didDrag = false
                },
                onDrag = { _, dragAmount ->
                    val delta = (valueRange.endInclusive - valueRange.start) * (dragAmount.x / trackWidth.toFloat())
                    if (delta != 0f) {
                        didDrag = true
                        val nextValue =
                            if (isLtr) (targetValue + delta).coerceIn(valueRange.start, valueRange.endInclusive)
                            else (targetValue - delta).coerceIn(valueRange.start, valueRange.endInclusive)
                        updateValue(nextValue)
                        onValueChangeState.value(nextValue)
                    }
                }
            )
        }

        // Squash-and-stretch of the thumb along its travel (LiquidTracker technique).
        val stretch = rememberLiquidStretchState(stretchFactor = 0.4f, minScale = 0.85f, maxScale = 1.2f)
        LaunchedEffect(dampedDragAnimation, stretch, trackWidth) {
            snapshotFlow { dampedDragAnimation.progress }
                .collect { p -> stretch.onPositionSample(p * trackWidth) }
        }

        LaunchedEffect(currentValue, isDragging, dampedDragAnimation) {
            if (!isDragging && abs(dampedDragAnimation.targetValue - currentValue) > visibilityThreshold) {
                dampedDragAnimation.updateValue(currentValue)
            }
        }

        Box(Modifier.layerBackdrop(trackBackdrop)) {
            Box(
                Modifier
                    .clip(Capsule)
                    .background(trackColor)
                    .pointerInput(trackWidth, isLtr, valueRange.start, valueRange.endInclusive) {
                        detectTapGestures { position ->
                            val delta =
                                (valueRange.endInclusive - valueRange.start) * (position.x / trackWidth.toFloat())
                            val targetValue =
                                (if (isLtr) valueRange.start + delta
                                else valueRange.endInclusive - delta)
                                    .coerceIn(valueRange)
                            dampedDragAnimation.animateToValue(targetValue)
                            onValueChangeState.value(targetValue)
                        }
                    }
                    .height(6f.dp)
                    .fillMaxWidth()
            )

            Box(
                Modifier
                    .clip(Capsule)
                    .background(accentColor)
                    .height(6f.dp)
                    .layout { measurable, constraints ->
                        val placeable = measurable.measure(constraints)
                        val width = (constraints.maxWidth * dampedDragAnimation.progress).fastRoundToInt()
                        layout(width, placeable.height) {
                            placeable.place(0, 0)
                        }
                    }
            )
        }

        Box(
            Modifier
                .graphicsLayer {
                    translationX =
                        (-size.width / 2f + trackWidth * dampedDragAnimation.progress)
                            .fastCoerceIn(-size.width / 4f, trackWidth - size.width * 3f / 4f) * if (isLtr) 1f else -1f
                }
                .then(dampedDragAnimation.modifier)
                .liquidStretch(stretch)
                .drawBackdrop(
                    backdrop = rememberCombinedBackdrop(
                        backdrop,
                        rememberBackdrop(trackBackdrop) { drawBackdrop ->
                            val progress = dampedDragAnimation.pressProgress
                            val scaleX = lerp(2f / 3f, 1f, progress)
                            val scaleY = lerp(0f, 1f, progress)
                            scale(scaleX, scaleY) { drawBackdrop() }
                        }
                    ),
                    shape = { Capsule },
                    effects = {
                        val progress = dampedDragAnimation.pressProgress
                        // At rest the thumb is an opaque white capsule (see onDrawSurface), so a blur
                        // of what is under it would be invisible work. Only refract once pressed.
                        if (progress > 0f) blur(8f.dp.toPx() * (1f - progress))
                        lens(
                            10f.dp.toPx() * progress,
                            14f.dp.toPx() * progress,
                            chromaticAberration = true
                        )
                    },
                    highlight = {
                        val progress = dampedDragAnimation.pressProgress
                        // Alpha 0 at rest: skip it outright, so an idle thumb never builds the
                        // highlight shader at all.
                        if (progress <= 0f) null else Highlight.Ambient.copy(
                            width = Highlight.Ambient.width / 1.5f,
                            blurRadius = Highlight.Ambient.blurRadius / 1.5f,
                            alpha = progress
                        )
                    },
                    shadow = null,
                    innerShadow = {
                        val progress = dampedDragAnimation.pressProgress
                        if (progress <= 0f) null else InnerShadow(radius = 4f.dp * progress, alpha = progress)
                    },
                    // Fully covered by the opaque white surface at rest — see LiquidToggle.
                    onDrawBackdrop = { drawBackdrop ->
                        if (dampedDragAnimation.pressProgress > 0f) drawBackdrop()
                    },
                    layerBlock = {
                        scaleX = dampedDragAnimation.scaleX
                        scaleY = dampedDragAnimation.scaleY
                    },
                    onDrawSurface = {
                        val progress = dampedDragAnimation.pressProgress
                        drawRect(Color.White.copy(alpha = 1f - progress))
                    }
                )
                .size(40f.dp, 24f.dp)
        )
    }
}
