package com.ashuiw.oryzaviewer.ui.viewmodel

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ashuiw.oryzaviewer.data.repository.GitHubStarPromptManager
import com.ashuiw.oryzaviewer.data.repository.RecentFile
import com.ashuiw.oryzaviewer.data.repository.RecentFilesManager
import com.ashuiw.oryzaviewer.data.repository.SaveLocationManager
import com.ashuiw.oryzaviewer.R
import com.ashuiw.oryzaviewer.ui.utils.StarPromptEventBus
import com.kyant.pdfcore.editor.PdfEditor
import com.kyant.pdfcore.model.PdfDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * One page in the organiser: which source page it came from, the extra rotation the
 * user applied, and a cached thumbnail.
 */
data class OrganizerPage(
    val originalIndex: Int,
    val rotation: Int = 0,
    val thumbnail: Bitmap? = null
)

data class PageOrganizerUiState(
    val sourceFileName: String = "",
    val sourceUri: Uri? = null,
    val pages: List<OrganizerPage> = emptyList(),
    /** Stable ids (= originalIndex) of currently multi-selected pages. */
    val selectedIds: Set<Int> = emptySet(),
    val isLoading: Boolean = false,
    val isSaving: Boolean = false,
    val resultMessage: String? = null,
    val errorMessage: String? = null,
    val lastOutputUri: Uri? = null,
    val saveLocationLabel: String = "Downloads (default)",
    /** (originalIndex, rotation) of every page as last loaded / saved — the "clean" layout. */
    val savedLayout: List<Pair<Int, Int>> = emptyList()
) {
    /** Reordered, rotated or deleted pages that haven't been written to a PDF yet. */
    val dirty: Boolean get() = pages.isNotEmpty() && layoutOf(pages) != savedLayout
}

internal fun layoutOf(pages: List<OrganizerPage>) = pages.map { it.originalIndex to Math.floorMod(it.rotation, 360) }

class PageOrganizerViewModel(private val editor: PdfEditor) : ViewModel() {
    private val _uiState = MutableStateFlow(PageOrganizerUiState())
    val uiState: StateFlow<PageOrganizerUiState> = _uiState.asStateFlow()

    fun onSelectFile(context: Context, uri: Uri) {
        _uiState.value = PageOrganizerUiState(isLoading = true)
        viewModelScope.launch {
            try {
                runCatching {
                    context.contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                val name = queryFileName(context, uri) ?: "Unknown.pdf"
                val pages = withContext(Dispatchers.IO) { renderThumbnails(context, uri) }
                _uiState.value = PageOrganizerUiState(
                    sourceFileName = name,
                    sourceUri = uri,
                    pages = pages.mapIndexed { i, bmp -> OrganizerPage(originalIndex = i, thumbnail = bmp) },
                    savedLayout = List(pages.size) { i -> i to 0 }
                )
            } catch (e: Exception) {
                _uiState.value = PageOrganizerUiState(errorMessage = context.getString(R.string.organize_open_failed))
            }
        }
    }

    fun rotatePage(index: Int, deltaDegrees: Int = 90) {
        val pages = _uiState.value.pages.toMutableList()
        if (index !in pages.indices) return
        val current = pages[index]
        pages[index] = current.copy(rotation = (((current.rotation + deltaDegrees) % 360) + 360) % 360)
        _uiState.value = _uiState.value.copy(pages = pages, resultMessage = null)
    }

    fun deletePage(index: Int) {
        val pages = _uiState.value.pages.toMutableList()
        if (index !in pages.indices || pages.size <= 1) return
        val removed = pages.removeAt(index)
        _uiState.value = _uiState.value.copy(
            pages = pages,
            selectedIds = _uiState.value.selectedIds - removed.originalIndex,
            resultMessage = null
        )
    }

    // ── Selection ─────────────────────────────────────────────────────────────

    fun toggleSelect(id: Int) {
        val sel = _uiState.value.selectedIds.toMutableSet()
        if (!sel.add(id)) sel.remove(id)
        _uiState.value = _uiState.value.copy(selectedIds = sel, resultMessage = null)
    }

    fun clearSelection() {
        _uiState.value = _uiState.value.copy(selectedIds = emptySet())
    }

    fun selectAll() {
        _uiState.value = _uiState.value.copy(selectedIds = _uiState.value.pages.map { it.originalIndex }.toSet())
    }

    fun rotateSelected(deltaDegrees: Int = 90) {
        val sel = _uiState.value.selectedIds
        if (sel.isEmpty()) return
        val pages = _uiState.value.pages.map {
            if (it.originalIndex in sel) it.copy(rotation = (((it.rotation + deltaDegrees) % 360) + 360) % 360) else it
        }
        _uiState.value = _uiState.value.copy(pages = pages, resultMessage = null)
    }

    fun deleteSelected(context: Context) {
        val sel = _uiState.value.selectedIds
        if (sel.isEmpty()) return
        val pages = _uiState.value.pages.filterNot { it.originalIndex in sel }
        if (pages.isEmpty()) {
            _uiState.value = _uiState.value.copy(errorMessage = context.getString(R.string.organize_cannot_delete_all))
            return
        }
        _uiState.value = _uiState.value.copy(pages = pages, selectedIds = emptySet(), resultMessage = null)
    }

    // ── Drag reorder ────────────────────────────────────────────────────────────

    /**
     * Moves the pages identified by [ids] (kept in their current relative order) so they
     * land at [targetIndex] in the full list. Powers both single- and multi-page drag.
     */
    fun movePagesTo(ids: List<Int>, targetIndex: Int) {
        if (ids.isEmpty()) return
        val current = _uiState.value.pages
        val idSet = ids.toSet()
        val moving = current.filter { it.originalIndex in idSet }
        if (moving.isEmpty()) return
        val remaining = current.filterNot { it.originalIndex in idSet }
        val removedBefore = current.take(targetIndex.coerceIn(0, current.size)).count { it.originalIndex in idSet }
        val insertAt = (targetIndex - removedBefore).coerceIn(0, remaining.size)
        val result = remaining.toMutableList().apply { addAll(insertAt, moving) }
        _uiState.value = _uiState.value.copy(pages = result, resultMessage = null)
    }

    /** [onSaved] runs only after the new PDF was written. */
    fun save(context: Context, fileName: String, overrideUri: Uri? = null, onSaved: (() -> Unit)? = null) {
        val src = _uiState.value.sourceUri ?: return
        val pages = _uiState.value.pages
        if (pages.isEmpty()) return
        _uiState.value = _uiState.value.copy(isSaving = true, errorMessage = null, resultMessage = null, lastOutputUri = null)
        viewModelScope.launch {
            var created: Uri? = null
            try {
                val target = if (fileName.endsWith(".pdf", true)) fileName else "$fileName.pdf"
                val saveLabel = SaveLocationManager.getSavePathDisplay(context)
                val outUri = withContext(Dispatchers.IO) { createOutputUri(context, target, overrideUri) }
                created = outUri
                val source = PdfDocument(uri = src, name = _uiState.value.sourceFileName)
                val order = pages.map { it.originalIndex }
                val rotations = pages.associate { it.originalIndex to it.rotation }.filterValues { it != 0 }
                withContext(Dispatchers.IO) { editor.applyPageEdits(context, source, order, rotations, outUri) }
                created = null

                withContext(Dispatchers.IO) {
                    RecentFilesManager.addRecent(context, RecentFile(
                        name = queryFileName(context, outUri) ?: target,
                        uriString = outUri.toString(),
                        timestamp = System.currentTimeMillis(),
                        pageCount = pages.size
                    ))
                }
                _uiState.value = _uiState.value.copy(
                    isSaving = false,
                    lastOutputUri = outUri,
                    saveLocationLabel = saveLabel,
                    resultMessage = context.getString(R.string.organize_success, pages.size, saveLabel),
                    savedLayout = layoutOf(pages)
                )
                onSaved?.invoke()
                val shouldPrompt = withContext(Dispatchers.IO) { GitHubStarPromptManager.recordSuccess(context) }
                if (shouldPrompt) StarPromptEventBus.requestPrompt()
            } catch (e: Exception) {
                // Don't leave an empty PDF behind in Downloads.
                created?.let { uri -> withContext(Dispatchers.IO) { runCatching { context.contentResolver.delete(uri, null, null) } } }
                GitHubStarPromptManager.recordFailure(context)
                _uiState.value = _uiState.value.copy(isSaving = false, errorMessage = context.getString(R.string.organize_save_failed))
            }
        }
    }

    fun clearFeedback() {
        _uiState.value = _uiState.value.copy(resultMessage = null, errorMessage = null)
    }

    private fun renderThumbnails(context: Context, uri: Uri): List<Bitmap?> {
        val fd = context.contentResolver.openFileDescriptor(uri, "r") ?: return emptyList()
        return fd.use {
            val renderer = android.graphics.pdf.PdfRenderer(it)
            try {
                (0 until renderer.pageCount).map { i ->
                    runCatching {
                        val page = renderer.openPage(i)
                        val thumbWidth = 300
                        val scale = thumbWidth.toFloat() / page.width
                        val thumbHeight = (page.height * scale).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(thumbWidth, thumbHeight, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        page.render(bmp, null, null, android.graphics.pdf.PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        page.close()
                        bmp
                    }.getOrNull()
                }
            } finally {
                renderer.close()
            }
        }
    }

    private fun queryFileName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) c.getString(idx) else null
            } else null
        }
    } catch (_: Exception) { null }

    private fun createOutputUri(context: Context, fileName: String, overrideUri: Uri?): Uri {
        val customUri = overrideUri ?: SaveLocationManager.getSaveUri(context)
        if (customUri != null) {
            runCatching {
                val docUri = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, customUri)
                docUri?.createFile("application/pdf", fileName)?.uri
            }.getOrNull()?.let { return it }
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw IllegalStateException("Unable to create output in Downloads")
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            if (!dir.exists()) dir.mkdirs()
            val file = java.io.File(dir, fileName)
            if (!file.exists()) file.createNewFile()
            FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        }
    }
}
