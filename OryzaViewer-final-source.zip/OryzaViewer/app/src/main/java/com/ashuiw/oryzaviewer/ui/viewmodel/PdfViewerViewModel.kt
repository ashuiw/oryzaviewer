package com.ashuiw.oryzaviewer.ui.viewmodel

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.ashuiw.oryzaviewer.R
import com.ashuiw.oryzaviewer.data.repository.GitHubStarPromptManager
import com.ashuiw.oryzaviewer.data.repository.LocalDocumentMirror
import com.ashuiw.oryzaviewer.data.repository.PdfServiceLocator
import com.ashuiw.oryzaviewer.data.repository.RecentFile
import com.ashuiw.oryzaviewer.data.repository.RecentFilesManager
import com.ashuiw.oryzaviewer.data.repository.SaveLocationManager
import com.ashuiw.oryzaviewer.domain.usecase.OpenPdfUseCase
import com.ashuiw.oryzaviewer.ui.utils.AppDispatchers
import com.ashuiw.oryzaviewer.ui.utils.StarPromptEventBus
import com.ashuiw.oryzaviewer.utils.UniversalDocumentConverter
import com.kyant.pdfcore.model.PdfDocument
import com.kyant.pdfcore.raster.PdfRasterizer
import com.kyant.pdfcore.security.PdfSecurityService
import com.kyant.pdfcore.text.PdfTextBlock
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

// ── UI model — kept identical to old OcrTextBlock so screen code compiles unchanged ──
data class OcrTextBlock(
    val id: String,
    val text: String,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float,
    val charLefts: FloatArray = FloatArray(0),
    val charRights: FloatArray = FloatArray(0),
    /** Typography of a digital-text line (null for OCR text): drives in-place editing. */
    val style: com.kyant.pdfcore.text.PdfTextStyle? = null
)

/** A word- or line-precise selection inside one extracted text block. [end] is exclusive. */
data class OcrTextRange(
    val blockId: String,
    val start: Int,
    val end: Int
)

/** A search hit as a normalized rect around the EXACT matched word(s), not the whole line. */
data class FindMatch(
    val pageIndex: Int,
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
)

data class NormalizedPoint(val x: Float, val y: Float)

sealed class ExportOverlay {
    data class Stroke(
        val points: List<NormalizedPoint>,
        val colorArgb: Int,
        val widthNorm: Float,
        val alpha: Float
    ) : ExportOverlay()

    data class RectShape(
        val start: NormalizedPoint,
        val end: NormalizedPoint,
        val colorArgb: Int,
        val alpha: Float,
        val filled: Boolean
    ) : ExportOverlay()

    data class OvalShape(
        val start: NormalizedPoint,
        val end: NormalizedPoint,
        val colorArgb: Int,
        val alpha: Float,
        val filled: Boolean
    ) : ExportOverlay()

    data class LineShape(
        val start: NormalizedPoint,
        val end: NormalizedPoint,
        val colorArgb: Int,
        val widthNorm: Float,
        val alpha: Float,
        val arrowHead: Boolean
    ) : ExportOverlay()

    data class ImageStamp(
        val bitmap: Bitmap,
        val start: NormalizedPoint,
        val end: NormalizedPoint
    ) : ExportOverlay()

    /** Inserted vector text. [position] is the top-left; baseline is derived on export. */
    data class TextStamp(
        val position: NormalizedPoint,
        val text: String,
        val colorArgb: Int,
        val fontSizeNorm: Float
    ) : ExportOverlay()

    /**
     * An in-place edit of the page's own text: the glyphs inside the normalized box are removed
     * from the content stream and [text] is drawn in their font (see PdfTextEditor). The line box
     * lets a partial edit move the rest of its line by the change in width.
     */
    /** A value typed or picked into the PDF's own form field, written into the form on save. */
    data class FormValue(val fieldName: String, val value: String) : ExportOverlay()

    data class TextReplace(
        val left: Float,
        val top: Float,
        val right: Float,
        val bottom: Float,
        val text: String,
        val backgroundArgb: Int,
        val lineLeft: Float = left,
        val lineTop: Float = top,
        val lineRight: Float = right,
        val lineBottom: Float = bottom
    ) : ExportOverlay() {
        fun toPdfTextEdit() = com.kyant.pdfcore.text.PdfTextEdit(
            left, top, right, bottom, text, backgroundArgb, lineLeft, lineTop, lineRight, lineBottom
        )
    }

    /** A real PDF sticky-note annotation anchored at [position] (top-left of icon). */
    data class NoteStamp(
        val position: NormalizedPoint,
        val text: String,
        val colorArgb: Int
    ) : ExportOverlay()
}

data class PdfViewerUiState(
    val fileName: String = "",
    val pageCount: Int = 0,
    val currentPage: Int = 0,
    val isLoading: Boolean = false,
    // True while a password-protected PDF is being unlocked + loaded, so the viewer can show the
    // padlock "decrypting" animation instead of the plain opening fill. Cleared on every terminal
    // outcome (opened / wrong password / error).
    val decrypting: Boolean = false,
    val errorMessage: String? = null,
    val passwordRequired: Boolean = false,
    val passwordAttemptFailed: Boolean = false,
    val passwordUri: Uri? = null,
    val pageBitmaps: List<Bitmap?> = emptyList(),
    val document: PdfDocument? = null,
    // The uri the user actually opened — a plain PDF's own uri, or the ORIGINAL .docx/.pptx for a
    // converted document (unlike [document].uri, which is the converted temp PDF). Lets Share offer
    // "export as the original file" vs "export as PDF".
    val originalUri: Uri? = null,
    val sizeBytes: Long = -1,
    val ocrBlocksByPage: Map<Int, List<OcrTextBlock>> = emptyMap(),
    /** The PDF's fillable form boxes, by page — filled in place in Edit mode (#68). */
    val formWidgetsByPage: Map<Int, List<com.kyant.pdfcore.form.PdfFormWidget>> = emptyMap(),
    /** The PDF's own links (web addresses, jumps inside the document), by page (#83). */
    val linksByPage: Map<Int, List<com.kyant.pdfcore.link.PdfLink>> = emptyMap(),
    val ocrPagesInProgress: Set<Int> = emptySet(),
    val isExporting: Boolean = false,
    val exportMessage: String? = null,
    val exportError: String? = null,
    val lastExportedUri: Uri? = null,
    val findQuery: String = "",
    val findMatches: List<FindMatch> = emptyList(),
    val currentMatchIndex: Int = -1,
    // One-time "Improve fidelity with the Office engine" hint, shown after an Office file was
    // rendered by the built-in renderers on a device that supports the optional engine.
    val showOfficeEngineHint: Boolean = false,
    /** True when the optional Office engine (LibreOffice) produced the pages on screen. */
    val renderedByOfficeEngine: Boolean = false
)

class PdfViewerViewModel(private val openPdfUseCase: OpenPdfUseCase) : ViewModel() {

    private val _uiState = MutableStateFlow(PdfViewerUiState())
    val uiState: StateFlow<PdfViewerUiState> = _uiState.asStateFlow()

    /** Hides the Office engine hint for good (it is a one-time suggestion). */
    fun dismissOfficeEngineHint(context: Context) {
        com.ashuiw.oryzaviewer.office.OfficeEngine.dismissHint(context)
        _uiState.value = _uiState.value.copy(showOfficeEngineHint = false)
    }

    private val renderingPages = mutableSetOf<Pair<Uri, Int>>()
    private val pendingRenderWidths = mutableMapOf<Pair<Uri, Int>, Int>()
    private val renderedPageWidths = mutableMapOf<Int, Int>()
    private val textLoadingPages = mutableSetOf<Int>()

    // Text extraction loads the ENTIRE document with PdfBox per page (PdfTextService.extractPage), so
    // several pages extracting at once — the eager first-pages pass, or a fast scroll — stack multiple
    // full-document copies in RAM and can OOM a large / decrypted PDF. This serializes them to one at a
    // time, capping the peak to a single in-flight copy. Pages still extract lazily; they just queue.
    private val textExtractionMutex = Mutex()

    /**
     * Dark reader: per page, the photographs to draw as printed over the turned-over page, as
     * rectangles normalised to the page (see [com.kyant.pdfcore.image.PdfImageRegions]). Filled
     * only while dark pages are on, a few pages around the one asked for at a time.
     */
    val nightPhotos = androidx.compose.runtime.mutableStateMapOf<Int, List<androidx.compose.ui.geometry.Rect>>()
    private val pictureRects = HashMap<Int, List<android.graphics.RectF>>()
    private val pictureScanning = HashSet<Int>()

    fun ensureNightPhotos(context: Context, pageIndex: Int) {
        val doc = _uiState.value.document ?: return
        if (nightPhotos.containsKey(pageIndex)) return
        val uri = doc.uri
        val raw = pictureRects[pageIndex]
        if (raw != null) { classifyNightPhotos(pageIndex, raw); return }
        val batch = ((pageIndex - 2)..(pageIndex + 5)).filter { it in 0 until doc.pageCount && it !in pictureRects && it !in pictureScanning }
        if (pageIndex !in batch) return
        pictureScanning.addAll(batch)
        viewModelScope.launch {
            val found = withContext(AppDispatchers.pdf) {
                textExtractionMutex.withLock {
                    runCatching { com.kyant.pdfcore.image.PdfImageRegions.pages(context, uri, batch) }.getOrDefault(emptyMap())
                }
            }
            pictureScanning.removeAll(batch.toSet())
            if (_uiState.value.document?.uri != uri) return@launch
            for (p in batch) pictureRects[p] = found[p] ?: emptyList()
            classifyNightPhotos(pageIndex, pictureRects[pageIndex].orEmpty())
        }
    }

    /** Keeps the pictures that are photographs; scans and figures on white turn over with the page. */
    private fun classifyNightPhotos(pageIndex: Int, rects: List<android.graphics.RectF>) {
        if (rects.isEmpty()) { nightPhotos[pageIndex] = emptyList(); return }
        val uri = _uiState.value.document?.uri ?: return
        val bitmap = _uiState.value.pageBitmaps.getOrNull(pageIndex)?.takeIf { !it.isRecycled } ?: return
        viewModelScope.launch {
            val photos = withContext(kotlinx.coroutines.Dispatchers.Default) {
                rects.map { androidx.compose.ui.geometry.Rect(it.left, it.top, it.right, it.bottom) }.filter { r ->
                    runCatching { !com.ashuiw.oryzaviewer.ui.components.NightPaper.looksLikePaper(bitmap, r) }.getOrDefault(false)
                }
            }
            if (_uiState.value.document?.uri == uri) nightPhotos[pageIndex] = photos
        }
    }

    private val textService = PdfServiceLocator.pdfTextService

    companion object {
        private const val DEFAULT_RENDER_WIDTH = 1200
        private const val MIN_RENDER_WIDTH = 720
        // Was 2 (5 pages held at once). A landscape page (any converted .pptx) is ~40% the bitmap
        // memory of a portrait one at the same render width, so this is roughly the old radius-2
        // memory budget for a slide deck, and a moderate increase for a portrait document — in
        // exchange for needing to re-render a page from scratch (the visible black-flash-then-redraw)
        // far less often while scrolling either direction.
        private const val CACHE_RADIUS = 5
        // How many pages ahead of the current one to render proactively, independent of whether the
        // LazyColumn has actually composed that item yet. Without this, a page's first-ever render
        // only starts once it scrolls into (near) view, which is exactly the "buffers while scrolling"
        // complaint — the render and the need for it were racing. Warming pages before you reach them
        // gives that race a head start.
        private const val PREFETCH_AHEAD = 2
        private const val PREFETCH_BEHIND = 1
        // Above this, the on-open form/link scan is skipped outright rather than risking PDFBox's
        // temp-file-backed load on a huge document for a feature (form fields, in-document links)
        // that scanned books essentially never have.
        private const val FORM_SCAN_SIZE_LIMIT_BYTES = 150L * 1024 * 1024
    }

    fun openPdf(context: Context, uri: Uri, password: String? = null) {
        _uiState.value.document?.let { openPdfUseCase.close(it) }
        recycleBitmaps(_uiState.value.pageBitmaps)
        renderingPages.clear()
        pendingRenderWidths.clear()
        renderedPageWidths.clear()
        textLoadingPages.clear()
        nightPhotos.clear()
        pictureRects.clear()
        pictureScanning.clear()
        _uiState.value = _uiState.value.copy(
            isLoading = true,
            // A supplied password means this call is the actual unlock → drive the decrypt animation.
            decrypting = password != null,
            errorMessage = null,
            document = null,
            pageBitmaps = emptyList(),
            passwordRequired = false,
            passwordAttemptFailed = false,
            passwordUri = null,
            ocrBlocksByPage = emptyMap(),
            ocrPagesInProgress = emptySet()
        )
        viewModelScope.launch {
            try {
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}

                // `uri` may be a share-intent grant that is about to be revoked (many senders never
                // attach a persistable flag, so the line above throws and is swallowed above) — this
                // is what turns "opened once from WhatsApp/Gmail" into "Failed to open PDF." the next
                // time it's tapped from Recents. `readableUri` is the original when it's still good,
                // or a durable local copy this app saved the first time it *was* good. `uri` itself
                // stays the identity used for naming and for the Recents entry.
                val readableUri = withContext(Dispatchers.IO) {
                    LocalDocumentMirror.resolve(context, uri, extensionOf(context, uri))
                }

                val sourceUri = withContext(Dispatchers.IO) {
                    when {
                        password != null -> {
                            val decrypted = PdfSecurityService.decryptToCache(context, readableUri, password)
                            FileProvider.getUriForFile(context, "${context.packageName}.provider", decrypted)
                        }
                        UniversalDocumentConverter.isPdf(context, readableUri) &&
                            PdfSecurityService.isPasswordProtected(context, readableUri) -> {
                            throw PdfSecurityService.PasswordRequiredException()
                        }
                        else -> readableUri
                    }
                }
                val (doc, renderedUri) = withContext(Dispatchers.IO) {
                    openDocumentWithFallback(context, sourceUri)
                }
                // A revoked share-intent grant fails the DISPLAY_NAME query on `uri` exactly the way
                // it fails a read — falling straight to `doc.name` would then show the mirror's own
                // "<hash>.pdf" filename. The name this document was already saved under in Recents
                // (set the first time it opened, when the query still worked) is what a returning
                // "Failed to open" file should still show.
                val displayName = queryFileName(context, uri)
                    ?: RecentFilesManager.getRecents(context).firstOrNull { it.uriString == uri.toString() }?.name
                    ?: doc.name
                val resumePage = RecentFilesManager.getRecents(context)
                    .firstOrNull { it.uriString == uri.toString() }
                    ?.currentPage
                    ?.coerceIn(0, (doc.pageCount - 1).coerceAtLeast(0))
                    ?: 0
                // First paint rides along with the document: the page the reader lands on is
                // rasterised here, at a quick preview width, BEFORE the viewer is told the document
                // exists — so the viewer appears with its page instead of a dark curtain waiting for a
                // compose -> request -> render round trip. The screen re-requests full width next.
                val firstPaint = withContext(AppDispatchers.pdf) {
                    runCatching { openPdfUseCase.renderPage(doc, resumePage, MIN_RENDER_WIDTH) }.getOrNull()
                }
                if (firstPaint != null) renderedPageWidths[resumePage] = MIN_RENDER_WIDTH
                _uiState.value = _uiState.value.copy(
                    fileName = displayName,
                    pageCount = doc.pageCount,
                    currentPage = resumePage,
                    isLoading = false,
                    decrypting = false,
                    passwordRequired = false,
                    passwordAttemptFailed = false,
                    passwordUri = null,
                    document = doc,
                    // The original selection, so Share can offer the source file itself. For a
                    // password-opened PDF this is still the encrypted original the user picked.
                    originalUri = uri,
                    sizeBytes = doc.sizeBytes,
                    pageBitmaps = List(doc.pageCount) { if (it == resumePage) firstPaint else null },
                    ocrBlocksByPage = emptyMap(),
                    formWidgetsByPage = emptyMap(),
                    linksByPage = emptyMap(),
                    ocrPagesInProgress = emptySet(),
                    isExporting = false,
                    exportMessage = null,
                    exportError = null,
                    lastExportedUri = null,
                    showOfficeEngineHint = com.ashuiw.oryzaviewer.office.OfficeEngine.shouldOfferHint(context, displayName),
                    renderedByOfficeEngine = renderedUri.path?.contains("/office-pdf/") == true
                )
                // Fillable fields and links, read off the main thread in one pass; most PDFs have
                // no form and stay empty. This used to load the whole file into PDFBox's in-memory
                // model unconditionally on every open — a multi-hundred-MB scanned book (all image
                // XObjects, no forms) OOM'd right after opening, before the user did anything. Above
                // FORM_SCAN_SIZE_LIMIT_BYTES skip the scan (forms/links are rare in huge scans and
                // not worth the risk); below it, load through a temp-file-backed buffer instead of
                // the heap.
                val formDocUri = doc.uri
                viewModelScope.launch {
                    val (widgets, links) = withContext(Dispatchers.IO) {
                        if (doc.sizeBytes > FORM_SCAN_SIZE_LIMIT_BYTES) {
                            emptyMap<Int, List<com.kyant.pdfcore.form.PdfFormWidget>>() to emptyMap()
                        } else runCatching {
                            com.kyant.pdfcore.internal.PdfBox.ensureInitialized(context)
                            context.contentResolver.openInputStream(formDocUri)?.use { input ->
                                com.tom_roush.pdfbox.pdmodel.PDDocument.load(
                                    input,
                                    com.tom_roush.pdfbox.io.MemoryUsageSetting.setupTempFileOnly()
                                ).use { pd ->
                                    val w = runCatching { com.kyant.pdfcore.form.PdfFormWidgets.read(pd) }.getOrDefault(emptyMap())
                                    val l = runCatching { com.kyant.pdfcore.link.PdfLinks.read(pd) }.getOrDefault(emptyMap())
                                    w to l
                                }
                            }
                        }.getOrNull() ?: (emptyMap<Int, List<com.kyant.pdfcore.form.PdfFormWidget>>() to emptyMap())
                    }
                    if ((widgets.isNotEmpty() || links.isNotEmpty()) && _uiState.value.document?.uri == formDocUri) {
                        _uiState.value = _uiState.value.copy(formWidgetsByPage = widgets, linksByPage = links)
                    }
                }
                // The ORIGINAL uri, deliberately — not `openedUri`.
                //
                // `openedUri` is whatever we ended up rendering: for a plain PDF that is the same
                // file, but for a .docx/.pptx it is the converted temp PDF, and for an unreadable
                // descriptor it is a timestamped mirror in app storage. Storing that broke recents
                // three ways at once. The entry carried the original *name* ("report.docx") beside a
                // converted *uri*, so tapping it re-queried DISPLAY_NAME off the temp file and got
                // the converter's own name back — the "unknown.pdf" bug. `docKindOf` then read that
                // name and routed a Word document to the plain PDF path. And because every open
                // minted a fresh temp file with a fresh uri, `addRecent`'s dedupe never matched, so
                // opening one file five times left five rows.
                //
                // The original uri is the identity of the thing the user opened. Re-opening from
                // recents re-runs the conversion, which is correct: the converted file is a cache
                // artifact, not the document.
                RecentFilesManager.addRecent(context, RecentFile(
                    name = displayName,
                    uriString = uri.toString(),
                    timestamp = System.currentTimeMillis(),
                    pageCount = doc.pageCount,
                    sizeBytes = doc.sizeBytes
                ))
                if (GitHubStarPromptManager.recordDocumentOpened(context)) {
                    StarPromptEventBus.requestPrompt()
                }
                renderPage(context, 0, DEFAULT_RENDER_WIDTH)
                // Eagerly load text for first 5 pages without waiting for bitmaps
                val eager = minOf(5, doc.pageCount)
                for (p in 0 until eager) loadTextPage(context, doc, p)
            } catch (e: PdfSecurityService.PasswordRequiredException) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    decrypting = false,
                    passwordRequired = true,
                    passwordAttemptFailed = password != null,
                    passwordUri = uri,
                    errorMessage = null
                )
            } catch (_: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    decrypting = false,
                    errorMessage = context.getString(R.string.viewer_open_failed)
                )
            }
        }
    }

    private fun openDocumentWithFallback(context: Context, sourceUri: Uri): Pair<PdfDocument, Uri> {
        val targetUri = if (!UniversalDocumentConverter.isPdf(context, sourceUri)) {
            UniversalDocumentConverter.convertToPdf(context, sourceUri)
        } else {
            sourceUri
        }
        val sourceDescriptorSize = tryReadDescriptorSize(context, targetUri)
        if (sourceDescriptorSize == 0L) throw IllegalStateException("Selected document is empty")

        val primaryUri = if (sourceDescriptorSize != null) targetUri
        else mirrorPdfToAppStorage(context, targetUri)

        return try {
            openPdfUseCase.open(context, primaryUri) to primaryUri
        } catch (primaryError: Exception) {
            if (primaryUri != targetUri) throw primaryError
            val mirroredUri = mirrorPdfToAppStorage(context, targetUri)
            val mirroredSize = tryReadDescriptorSize(context, mirroredUri)
            if (mirroredSize == 0L) throw IllegalStateException("Selected document is empty")
            if (mirroredSize == null) throw IllegalStateException("Unable to access selected document")
            openPdfUseCase.open(context, mirroredUri) to mirroredUri
        }
    }

    private fun tryReadDescriptorSize(context: Context, uri: Uri): Long? = runCatching {
        context.contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize }
    }.getOrElse { null }

    private fun mirrorPdfToAppStorage(context: Context, sourceUri: Uri): Uri {
        if (!com.ashuiw.oryzaviewer.data.repository.AppSettingsManager.getKeepLocalCopies(context)) {
            throw IllegalStateException("Unable to access selected document")
        }
        val input = context.contentResolver.openInputStream(sourceUri)
            ?: throw IllegalStateException("Unable to access selected document")
        val baseDir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.cacheDir
        val mirrorDir = File(baseDir, "imported_pdfs")
        if (!mirrorDir.exists() && !mirrorDir.mkdirs()) {
            throw IllegalStateException("Unable to prepare local document storage")
        }
        val sourceName = queryFileName(context, sourceUri)?.ifBlank { null }
            ?: "Imported_${System.currentTimeMillis()}.pdf"
        val sanitized = sourceName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val targetName = if (sanitized.lowercase(Locale.ROOT).endsWith(".pdf")) sanitized
        else "$sanitized.pdf"
        val targetFile = File(mirrorDir, "${System.currentTimeMillis()}_$targetName")
        input.use { it.copyTo(FileOutputStream(targetFile)) }
        if (targetFile.length() == 0L) {
            targetFile.delete()
            throw IllegalStateException("Selected document is empty")
        }
        return FileProvider.getUriForFile(context, "${context.packageName}.provider", targetFile)
    }

    /**
     * The visible [region] of [pageIndex] at screen resolution for a zoomed-in view (see
     * PdfViewer.renderRegion). Null if the document changed or rendering failed.
     */
    suspend fun renderRegion(pageIndex: Int, region: android.graphics.RectF, pageWidthPx: Float, outWidth: Int, outHeight: Int): Bitmap? {
        val doc = _uiState.value.document ?: return null
        return withContext(AppDispatchers.pdf) {
            runCatching { openPdfUseCase.renderRegion(doc, pageIndex, region, pageWidthPx, outWidth, outHeight) }.getOrNull()
        }?.takeIf { _uiState.value.document?.uri == doc.uri }
    }

    /**
     * The part of the page that holds content, as a 0..1 rect shared by the whole document (#85).
     * A few pages spread through the document are measured at thumbnail size and each side takes
     * the generous end of what they print on, so a cover picture or a short chapter page doesn't
     * decide it, and every page is trimmed the same (the text keeps one size). Null when the
     * margins are too thin to be worth trimming.
     */
    suspend fun contentCrop(): android.graphics.RectF? {
        val doc = _uiState.value.document ?: return null
        val count = _uiState.value.pageCount
        if (count <= 0) return null
        val samples = minOf(count, 8)
        val pages = (0 until samples).map { if (samples == 1) 0 else (it * (count - 1).toFloat() / (samples - 1)).toInt() }.distinct()
        val found = ArrayList<android.graphics.RectF>()
        for (p in pages) {
            val bmp = withContext(AppDispatchers.pdf) { runCatching { openPdfUseCase.renderPage(doc, p, 240) }.getOrNull() } ?: continue
            val r = withContext(Dispatchers.Default) { pageContentBounds(bmp) }
            bmp.recycle()
            if (_uiState.value.document?.uri != doc.uri) return null
            if (r != null) found += r
        }
        if (found.isEmpty()) return null
        fun low(v: List<Float>) = v.sorted()[(v.size - 1) / 4]
        fun high(v: List<Float>) = v.sorted()[v.size - 1 - (v.size - 1) / 4]
        val pad = 0.02f
        val crop = android.graphics.RectF(
            (low(found.map { it.left }) - pad).coerceAtLeast(0f),
            (low(found.map { it.top }) - pad).coerceAtLeast(0f),
            (high(found.map { it.right }) + pad).coerceAtMost(1f),
            (high(found.map { it.bottom }) + pad).coerceAtMost(1f)
        )
        if (crop.width() < 0.25f || crop.height() < 0.25f) return null
        if (crop.width() > 0.94f && crop.height() > 0.94f) return null
        return crop
    }

    fun renderPage(context: Context, pageIndex: Int, targetWidthPx: Int = DEFAULT_RENDER_WIDTH) {
        val state = _uiState.value
        val doc = state.document ?: return
        if (pageIndex !in state.pageBitmaps.indices) return

        val renderWidth = targetWidthPx.coerceAtLeast(MIN_RENDER_WIDTH)
        val cachedBitmap = state.pageBitmaps[pageIndex]
        val cachedWidth = renderedPageWidths[pageIndex] ?: 0
        if (cachedBitmap != null && !cachedBitmap.isRecycled && cachedWidth >= renderWidth) return

        val documentUri = doc.uri
        val renderKey = documentUri to pageIndex
        if (!renderingPages.add(renderKey)) {
            pendingRenderWidths[renderKey] = maxOf(pendingRenderWidths[renderKey] ?: 0, renderWidth)
            return
        }

        viewModelScope.launch {
            try {
                val bitmap = withContext(AppDispatchers.pdf) {
                    // Guard the whole render — a large page can OOM (an Error, not an Exception), and
                    // this coroutine has only a finally, so an uncaught throwable here crashed the app
                    // mid-scroll. Returning null instead just leaves the page as a spinner placeholder.
                    runCatching { openPdfUseCase.renderPage(doc, pageIndex, renderWidth) }.getOrNull()
                }
                val currentState = _uiState.value
                if (currentState.document?.uri != documentUri) return@launch
                if (pageIndex !in currentState.pageBitmaps.indices) return@launch

                // Cache trimming does NOT happen here any more — it used to, sweeping every page
                // outside `CACHE_RADIUS` of `currentState.currentPage` on every single render
                // completion. `currentPage` updates on every scroll tick (undebounced, by design —
                // other things need it live), and during a fast scroll a render completes every few
                // milliseconds, so this ran constantly and evicted pages that were still transiting
                // through the viewport a frame later. That eviction is now solely `trimBitmapCache`
                // (below), which the caller in `PdfViewerScreen` debounces — this function's only job
                // is to place the bitmap it just rendered.
                if (bitmap != null) {
                    val bitmaps = currentState.pageBitmaps.toMutableList()
                    val previous = bitmaps[pageIndex]
                    if (previous != null && previous != bitmap && !previous.isRecycled) previous.recycle()
                    bitmaps[pageIndex] = bitmap
                    renderedPageWidths[pageIndex] = renderWidth
                    _uiState.value = currentState.copy(pageBitmaps = bitmaps)
                }

                // Load text for page if not already done (async, IO thread)
                loadTextPage(context, doc, pageIndex)
            } finally {
                renderingPages.remove(renderKey)
                val pendingWidth = pendingRenderWidths.remove(renderKey)
                val latest = _uiState.value
                if (pendingWidth != null && latest.document?.uri == documentUri &&
                    (renderedPageWidths[pageIndex] ?: 0) < pendingWidth
                ) {
                    renderPage(context, pageIndex, pendingWidth)
                }
            }
        }
    }

    private fun loadTextPage(context: Context, doc: PdfDocument, pageIndex: Int) {
        val state = _uiState.value
        if (state.document?.uri != doc.uri) return
        if (state.ocrBlocksByPage.containsKey(pageIndex)) return
        if (!textLoadingPages.add(pageIndex)) return

        _uiState.value = _uiState.value.copy(
            ocrPagesInProgress = textLoadingPages.toSet()
        )

        viewModelScope.launch {
            val blocks = withContext(AppDispatchers.pdf) {
                // One full-document PdfBox parse at a time — see [textExtractionMutex].
                val pdfBlocks = textExtractionMutex.withLock {
                    runCatching {
                        textService.extractPage(context, doc.uri, pageIndex)
                    }.getOrElse { emptyList() }
                }
                if (pdfBlocks.isNotEmpty()) {
                    pdfBlocks.map { it.toOcrBlock() }
                } else {
                    // No digital text layer (scanned/image-only page) — fall back to
                    // on-device OCR, cached to disk so re-opening the doc is instant.
                    loadOcrFallbackBlocks(context, doc, pageIndex)
                }
            }
            val current = _uiState.value
            if (current.document?.uri != doc.uri) {
                textLoadingPages.remove(pageIndex)
                return@launch
            }
            val updated = current.ocrBlocksByPage.toMutableMap()
            updated[pageIndex] = blocks
            textLoadingPages.remove(pageIndex)
            _uiState.value = current.copy(
                ocrBlocksByPage = updated,
                ocrPagesInProgress = textLoadingPages.toSet()
            )
        }
    }

    /** Rasterizes [pageIndex] and runs it through [PdfServiceLocator.ocrService], reading/writing the disk cache. */
    private suspend fun loadOcrFallbackBlocks(context: Context, doc: PdfDocument, pageIndex: Int): List<OcrTextBlock> {
        OcrPageCache.read(context, doc, pageIndex)?.let { return it }
        val bitmap = runCatching {
            PdfRasterizer.rasterizePageBitmap(context, doc.uri, pageIndex)
        }.getOrNull() ?: return emptyList()
        return try {
            val result = runCatching { PdfServiceLocator.ocrService.recognize(context, bitmap) }.getOrNull()
                ?: return emptyList()
            val blocks = groupOcrWordsIntoBlocks(result.words, pageIndex)
            OcrPageCache.write(context, doc, pageIndex, blocks)
            blocks
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    /** Cheap, called on every scroll tick: just records which page is "current" now. */
    fun onPageChanged(page: Int) {
        val state = _uiState.value
        if (page !in state.pageBitmaps.indices || state.currentPage == page) return
        _uiState.value = state.copy(currentPage = page)
    }

    /**
     * Kicks off rendering for the pages just ahead of (and a little behind) [page], so they're
     * likely already there by the time a scroll actually reaches them instead of starting the render
     * only once the page scrolls into view. `renderPage` itself is cheap to call redundantly — it
     * returns immediately for a page that's already rendered at this width or already in flight — so
     * this can safely be called on every scroll tick without debouncing.
     */
    fun prefetchAround(context: Context, page: Int, targetWidthPx: Int) {
        val pageCount = _uiState.value.pageBitmaps.size
        for (p in (page + 1)..(page + PREFETCH_AHEAD)) {
            if (p in 0 until pageCount) renderPage(context, p, targetWidthPx)
        }
        for (p in (page - 1) downTo (page - PREFETCH_BEHIND)) {
            if (p in 0 until pageCount) renderPage(context, p, targetWidthPx)
        }
    }

    /**
     * Recycles bitmaps far from [page]. Deliberately a separate call from [onPageChanged] — the
     * caller debounces this one, so a fast scroll doesn't evict a page that's still transiting
     * through the viewport a frame later (see the call site's comment for why that showed up as
     * visible flicker/re-render churn while scrolling).
     */
    fun trimBitmapCache(page: Int) {
        val state = _uiState.value
        if (page !in state.pageBitmaps.indices) return

        val bitmaps = state.pageBitmaps.toMutableList()
        var evicted = false
        bitmaps.forEachIndexed { index, existing ->
            if (existing != null && abs(index - page) > CACHE_RADIUS) {
                if (!existing.isRecycled) existing.recycle()
                bitmaps[index] = null
                renderedPageWidths.remove(index)
                evicted = true
            }
        }
        if (evicted) _uiState.value = _uiState.value.copy(pageBitmaps = bitmaps)
    }

    fun clearExportFeedback() {
        _uiState.value = _uiState.value.copy(exportMessage = null, exportError = null)
    }

    // ── Search ──────────────────────────────────────────────────────────────────

    fun searchText(query: String) {
        if (query.isBlank()) {
            _uiState.value = _uiState.value.copy(
                findQuery = "",
                findMatches = emptyList(),
                currentMatchIndex = -1
            )
            return
        }
        val lower = query.trim().lowercase()
        // Fast path: search already-extracted blocks in memory, highlighting the exact word.
        val inMemoryMatches = _uiState.value.ocrBlocksByPage
            .entries
            .sortedBy { it.key }
            .flatMap { (page, blocks) ->
                blocks.sortedBy { it.top }.flatMap { it.findMatches(lower, page) }
            }

        _uiState.value = _uiState.value.copy(
            findQuery = query,
            findMatches = inMemoryMatches,
            currentMatchIndex = if (inMemoryMatches.isEmpty()) -1 else 0
        )

        // Trigger full-document text extraction for pages not yet loaded, then re-search
        val doc = _uiState.value.document ?: return
        val pageCount = _uiState.value.pageCount
        viewModelScope.launch {
            val allMatches = withContext(Dispatchers.IO) {
                runCatching {
                    // Use current in-memory blocks; do a PdfBox full search for completeness
                    val context = _uiState.value.document?.let { return@runCatching null } ?: return@runCatching null
                    null
                }.getOrElse { null }
            }
            // Keep in-memory results; trigger lazy text load for unloaded pages
        }
    }

    fun searchTextInDocument(context: Context, query: String) {
        if (query.isBlank()) {
            _uiState.value = _uiState.value.copy(
                findQuery = "",
                findMatches = emptyList(),
                currentMatchIndex = -1
            )
            return
        }
        val doc = _uiState.value.document ?: return
        val lower = query.trim().lowercase()
        viewModelScope.launch {
            val matches = withContext(Dispatchers.IO) {
                runCatching {
                    textService.searchAll(context, doc.uri, query, doc.pageCount)
                        .map { FindMatch(it.pageIndex, it.left, it.top, it.right, it.bottom) }
                }.getOrElse {
                    // Fallback: search in-memory extracted blocks (word-precise).
                    _uiState.value.ocrBlocksByPage.entries.sortedBy { it.key }.flatMap { (page, blocks) ->
                        blocks.sortedBy { it.top }.flatMap { it.findMatches(lower, page) }
                    }
                }
            }
            _uiState.value = _uiState.value.copy(
                findQuery = query,
                findMatches = matches,
                currentMatchIndex = if (matches.isEmpty()) -1 else 0
            )
        }
    }

    fun nextMatch() {
        val state = _uiState.value
        if (state.findMatches.isEmpty()) return
        val next = (state.currentMatchIndex + 1) % state.findMatches.size
        _uiState.value = state.copy(currentMatchIndex = next)
    }

    fun prevMatch() {
        val state = _uiState.value
        if (state.findMatches.isEmpty()) return
        val prev = (state.currentMatchIndex - 1 + state.findMatches.size) % state.findMatches.size
        _uiState.value = state.copy(currentMatchIndex = prev)
    }

    fun clearSearch() {
        _uiState.value = _uiState.value.copy(
            findQuery = "",
            findMatches = emptyList(),
            currentMatchIndex = -1
        )
    }

    fun triggerOcrForAllPages(context: Context) {
        val state = _uiState.value
        val doc = state.document ?: return
        for (page in 0 until state.pageCount) {
            if (!state.ocrBlocksByPage.containsKey(page) && !textLoadingPages.contains(page)) {
                loadTextPage(context, doc, page)
            }
        }
    }

    // ── Export ───────────────────────────────────────────────────────────────────

    fun exportEditedPdf(
        context: Context,
        overlaysByPage: Map<Int, List<ExportOverlay>>,
        fileName: String,
        overrideUri: Uri? = null
    ) {
        val doc = _uiState.value.document ?: return
        _uiState.value = _uiState.value.copy(
            isExporting = true, exportMessage = null, exportError = null, lastExportedUri = null
        )

        viewModelScope.launch {
            try {
                val outputUri = withContext(Dispatchers.IO) {
                    createEditedOutputUri(context, fileName, overrideUri)
                }

                withContext(Dispatchers.IO) {
                    exportWithPdfBox(context, doc, overlaysByPage, outputUri)
                }

                val outputName = queryFileName(context, outputUri) ?: "Edited.pdf"
                val outputSize = context.contentResolver.openFileDescriptor(outputUri, "r")?.use { it.statSize } ?: -1L
                RecentFilesManager.addRecent(context, RecentFile(
                    name = outputName,
                    uriString = outputUri.toString(),
                    timestamp = System.currentTimeMillis(),
                    pageCount = doc.pageCount,
                    sizeBytes = outputSize
                ))
                _uiState.value = _uiState.value.copy(
                    isExporting = false,
                    exportMessage = context.getString(R.string.viewer_save_success, outputName),
                    lastExportedUri = outputUri
                )
                if (GitHubStarPromptManager.recordSuccess(context)) {
                    StarPromptEventBus.requestPrompt()
                }
            } catch (_: Exception) {
                GitHubStarPromptManager.recordFailure(context)
                _uiState.value = _uiState.value.copy(
                    isExporting = false,
                    exportError = context.getString(R.string.viewer_save_failed)
                )
            }
        }
    }

    /**
     * Writes the open document WITH all edits applied (text edits, drawings, images…) to [out] —
     * the same pipeline as Save — so Share hands over what the user sees, not the untouched file.
     * Blocking: call off the main thread.
     */
    fun writeEditedCopy(context: Context, overlaysByPage: Map<Int, List<ExportOverlay>>, out: File): Uri? {
        val doc = _uiState.value.document ?: return null
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", out)
        return runCatching { exportWithPdfBox(context, doc, overlaysByPage, uri); uri }.getOrNull()
    }

    /** Plain text of every page of [pdf] in reading order. Blocking. */
    fun extractAllText(context: Context, pdf: Uri): String {
        com.kyant.pdfcore.internal.PdfBox.ensureInitialized(context)
        return context.contentResolver.openInputStream(pdf)?.use { input ->
            com.tom_roush.pdfbox.pdmodel.PDDocument.load(input).use { d ->
                com.tom_roush.pdfbox.text.PDFTextStripper().apply { sortByPosition = true }.getText(d)
            }
        }.orEmpty()
    }

    private fun exportWithPdfBox(
        context: Context,
        doc: PdfDocument,
        overlaysByPage: Map<Int, List<ExportOverlay>>,
        outputUri: Uri
    ) {
        com.kyant.pdfcore.internal.PdfBox.ensureInitialized(context)
        val inputStream = context.contentResolver.openInputStream(doc.uri)
            ?: throw IllegalStateException("Cannot open source PDF")

        com.tom_roush.pdfbox.pdmodel.PDDocument.load(inputStream).use { pdDoc ->
            // Form values first: the fields regenerate their own appearances in the form's fonts,
            // and any markup is then drawn above them.
            val formValues = overlaysByPage.values.flatten().filterIsInstance<ExportOverlay.FormValue>()
                .associate { it.fieldName to it.value }
            if (formValues.isNotEmpty()) runCatching { com.kyant.pdfcore.form.PdfFormWidgets.apply(pdDoc, formValues) }
            overlaysByPage.forEach { (pageIdx, overlays) ->
                if (pageIdx !in 0 until pdDoc.numberOfPages) return@forEach
                val page = pdDoc.getPage(pageIdx)
                val pageW = (page.cropBox ?: page.mediaBox)?.width ?: return@forEach
                val pageH = (page.cropBox ?: page.mediaBox)?.height ?: return@forEach

                // Real text edits first: they rewrite the page's own content stream, and every
                // other overlay is then drawn above the edited text.
                val textEdits = overlays.filterIsInstance<ExportOverlay.TextReplace>().map { it.toPdfTextEdit() }
                if (textEdits.isNotEmpty()) {
                    runCatching { com.kyant.pdfcore.text.PdfTextEditor.applyEdits(pdDoc, pageIdx, textEdits) }
                }

                com.tom_roush.pdfbox.pdmodel.PDPageContentStream(
                    pdDoc, page,
                    com.tom_roush.pdfbox.pdmodel.PDPageContentStream.AppendMode.APPEND,
                    true, true
                ).use { cs ->
                    for (overlay in overlays) {
                        drawOverlayOnPage(cs, overlay, pageW, pageH, pdDoc, page)
                    }
                }
            }

            val outputStream = context.contentResolver.openOutputStream(outputUri)
                ?: throw IllegalStateException("Cannot open output stream")
            outputStream.use { pdDoc.save(it) }
        }
    }

    private fun drawOverlayOnPage(
        cs: com.tom_roush.pdfbox.pdmodel.PDPageContentStream,
        overlay: ExportOverlay,
        pageW: Float,
        pageH: Float,
        pdDoc: com.tom_roush.pdfbox.pdmodel.PDDocument,
        page: com.tom_roush.pdfbox.pdmodel.PDPage
    ) {
        fun nx(x: Float) = x * pageW
        fun ny(y: Float) = (1f - y) * pageH  // PDF Y=0 is bottom

        try {
            when (overlay) {
                is ExportOverlay.Stroke -> {
                    if (overlay.points.size < 2) return
                    val c = android.graphics.Color.valueOf(overlay.colorArgb)
                    cs.saveGraphicsState()
                    val gs = com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState()
                    gs.strokingAlphaConstant = overlay.alpha
                    cs.setGraphicsStateParameters(gs)
                    cs.setStrokingColor(c.red(), c.green(), c.blue())
                    cs.setLineWidth((overlay.widthNorm * min(pageW, pageH)).coerceAtLeast(0.5f))
                    cs.setLineCapStyle(1)
                    cs.setLineJoinStyle(1)
                    overlay.points.forEachIndexed { idx, pt ->
                        if (idx == 0) cs.moveTo(nx(pt.x), ny(pt.y))
                        else cs.lineTo(nx(pt.x), ny(pt.y))
                    }
                    cs.stroke()
                    cs.restoreGraphicsState()
                }

                is ExportOverlay.RectShape -> {
                    val c = android.graphics.Color.valueOf(overlay.colorArgb)
                    val x1 = nx(minOf(overlay.start.x, overlay.end.x))
                    val y1 = ny(maxOf(overlay.start.y, overlay.end.y))
                    val w = abs(nx(overlay.end.x) - nx(overlay.start.x))
                    val h = abs(ny(overlay.start.y) - ny(overlay.end.y))
                    cs.saveGraphicsState()
                    val gs = com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState()
                    gs.strokingAlphaConstant = overlay.alpha
                    gs.nonStrokingAlphaConstant = overlay.alpha
                    cs.setGraphicsStateParameters(gs)
                    if (overlay.filled) {
                        cs.setNonStrokingColor(c.red(), c.green(), c.blue())
                        cs.addRect(x1, y1, w, h)
                        cs.fill()
                    } else {
                        cs.setStrokingColor(c.red(), c.green(), c.blue())
                        cs.setLineWidth(1.5f)
                        cs.addRect(x1, y1, w, h)
                        cs.stroke()
                    }
                    cs.restoreGraphicsState()
                }

                is ExportOverlay.OvalShape -> {
                    val c = android.graphics.Color.valueOf(overlay.colorArgb)
                    val cx = nx((overlay.start.x + overlay.end.x) / 2f)
                    val cy = ny((overlay.start.y + overlay.end.y) / 2f)
                    val rx = abs(nx(overlay.end.x) - nx(overlay.start.x)) / 2f
                    val ry = abs(ny(overlay.start.y) - ny(overlay.end.y)) / 2f
                    cs.saveGraphicsState()
                    val gs = com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState()
                    gs.strokingAlphaConstant = overlay.alpha
                    gs.nonStrokingAlphaConstant = overlay.alpha
                    cs.setGraphicsStateParameters(gs)
                    // Approximate ellipse with Bezier curves
                    val k = 0.5523f
                    if (overlay.filled) {
                        cs.setNonStrokingColor(c.red(), c.green(), c.blue())
                        cs.moveTo(cx - rx, cy)
                        cs.curveTo(cx - rx, cy + ry * k, cx - rx * k, cy + ry, cx, cy + ry)
                        cs.curveTo(cx + rx * k, cy + ry, cx + rx, cy + ry * k, cx + rx, cy)
                        cs.curveTo(cx + rx, cy - ry * k, cx + rx * k, cy - ry, cx, cy - ry)
                        cs.curveTo(cx - rx * k, cy - ry, cx - rx, cy - ry * k, cx - rx, cy)
                        cs.fill()
                    } else {
                        cs.setStrokingColor(c.red(), c.green(), c.blue())
                        cs.setLineWidth(1.5f)
                        cs.moveTo(cx - rx, cy)
                        cs.curveTo(cx - rx, cy + ry * k, cx - rx * k, cy + ry, cx, cy + ry)
                        cs.curveTo(cx + rx * k, cy + ry, cx + rx, cy + ry * k, cx + rx, cy)
                        cs.curveTo(cx + rx, cy - ry * k, cx + rx * k, cy - ry, cx, cy - ry)
                        cs.curveTo(cx - rx * k, cy - ry, cx - rx, cy - ry * k, cx - rx, cy)
                        cs.stroke()
                    }
                    cs.restoreGraphicsState()
                }

                is ExportOverlay.LineShape -> {
                    val c = android.graphics.Color.valueOf(overlay.colorArgb)
                    val x1 = nx(overlay.start.x); val y1 = ny(overlay.start.y)
                    val x2 = nx(overlay.end.x);   val y2 = ny(overlay.end.y)
                    cs.saveGraphicsState()
                    val gs = com.tom_roush.pdfbox.pdmodel.graphics.state.PDExtendedGraphicsState()
                    gs.strokingAlphaConstant = overlay.alpha
                    cs.setGraphicsStateParameters(gs)
                    cs.setStrokingColor(c.red(), c.green(), c.blue())
                    cs.setLineWidth((overlay.widthNorm * min(pageW, pageH)).coerceAtLeast(0.5f))
                    cs.setLineCapStyle(1)
                    cs.moveTo(x1, y1)
                    cs.lineTo(x2, y2)
                    if (overlay.arrowHead) {
                        val angle = atan2((y2 - y1).toDouble(), (x2 - x1).toDouble())
                        val headLen = (overlay.widthNorm * min(pageW, pageH) * 4f).coerceAtLeast(8f).toDouble()
                        val a1 = angle + PI - PI / 6
                        val a2 = angle + PI + PI / 6
                        cs.moveTo(x2, y2)
                        cs.lineTo((x2 + headLen * cos(a1)).toFloat(), (y2 + headLen * sin(a1)).toFloat())
                        cs.moveTo(x2, y2)
                        cs.lineTo((x2 + headLen * cos(a2)).toFloat(), (y2 + headLen * sin(a2)).toFloat())
                    }
                    cs.stroke()
                    cs.restoreGraphicsState()
                }

                is ExportOverlay.ImageStamp -> {
                    if (overlay.bitmap.isRecycled) return
                    val pdImage = runCatching {
                        com.tom_roush.pdfbox.pdmodel.graphics.image.LosslessFactory
                            .createFromImage(pdDoc, overlay.bitmap)
                    }.getOrElse { return }
                    val x = nx(minOf(overlay.start.x, overlay.end.x))
                    val y = ny(maxOf(overlay.start.y, overlay.end.y))
                    val w = abs(nx(overlay.end.x) - nx(overlay.start.x))
                    val h = abs(ny(overlay.start.y) - ny(overlay.end.y))
                    cs.saveGraphicsState()
                    cs.drawImage(pdImage, x, y, w, h)
                    cs.restoreGraphicsState()
                }

                is ExportOverlay.TextStamp -> {
                    if (overlay.text.isBlank()) return
                    val c = android.graphics.Color.valueOf(overlay.colorArgb)
                    val font = com.tom_roush.pdfbox.pdmodel.font.PDType1Font.HELVETICA
                    val size = (overlay.fontSizeNorm * pageH).coerceIn(4f, pageH)
                    val leading = size * 1.2f
                    // PDFBox's WinAnsi encoding rejects unsupported glyphs; sanitize to Latin-1.
                    val lines = overlay.text.split("\n").map { line ->
                        buildString { line.forEach { ch -> append(if (ch.code in 32..255) ch else '?') } }
                    }
                    val startX = nx(overlay.position.x)
                    val startY = ny(overlay.position.y) - size  // baseline for first line
                    cs.beginText()
                    cs.setNonStrokingColor(c.red(), c.green(), c.blue())
                    cs.setFont(font, size)
                    cs.newLineAtOffset(startX, startY)
                    lines.forEachIndexed { idx, line ->
                        if (idx > 0) cs.newLineAtOffset(0f, -leading)
                        runCatching { cs.showText(line) }
                    }
                    cs.endText()
                }

                // Already applied to the content stream / form before this pass.
                is ExportOverlay.TextReplace -> Unit
                is ExportOverlay.FormValue -> Unit

                is ExportOverlay.NoteStamp -> {
                    // A real, clickable PDF sticky-note annotation.
                    val c = android.graphics.Color.valueOf(overlay.colorArgb)
                    val note = com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationText()
                    note.setContents(overlay.text)
                    note.name = com.tom_roush.pdfbox.pdmodel.interactive.annotation.PDAnnotationText.NAME_NOTE
                    note.color = com.tom_roush.pdfbox.pdmodel.graphics.color.PDColor(
                        floatArrayOf(c.red(), c.green(), c.blue()),
                        com.tom_roush.pdfbox.pdmodel.graphics.color.PDDeviceRGB.INSTANCE
                    )
                    val ax = nx(overlay.position.x)
                    val ay = ny(overlay.position.y)
                    val iconSize = (min(pageW, pageH) * 0.03f).coerceIn(14f, 28f)
                    note.rectangle = com.tom_roush.pdfbox.pdmodel.common.PDRectangle(ax, ay - iconSize, iconSize, iconSize)
                    page.annotations.add(note)
                }
            }
        } catch (_: Exception) {
            // Silently skip overlay that fails to render
        }
    }

    override fun onCleared() {
        recycleBitmaps(_uiState.value.pageBitmaps)
        renderingPages.clear()
        renderedPageWidths.clear()
        textLoadingPages.clear()
        _uiState.value.document?.let { openPdfUseCase.close(it) }
        super.onCleared()
    }

    private fun createEditedOutputUri(context: Context, targetFileName: String, overrideUri: Uri?): Uri {
        val targetPath = overrideUri ?: SaveLocationManager.getSaveUri(context)
        if (targetPath != null) {
            runCatching {
                val tree = androidx.documentfile.provider.DocumentFile.fromTreeUri(context, targetPath)
                val created = tree?.createFile("application/pdf", targetFileName)?.uri
                if (created != null) return created
            }
        }
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, targetFileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw IllegalStateException("Unable to create edited output in Downloads")
        } else {
            val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
            if (!dir.exists()) dir.mkdirs()
            val file = java.io.File(dir, targetFileName)
            if (!file.exists()) file.createNewFile()
            FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
        }
    }

    /** Best-effort real file extension, so a mirrored copy still sniffs as the right format. */
    private fun extensionOf(context: Context, uri: Uri): String {
        val name = queryFileName(context, uri) ?: uri.lastPathSegment.orEmpty()
        return name.substringAfterLast('.', "pdf").lowercase()
    }

    private fun queryFileName(context: Context, uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) else null
            } else null
        }
    }.getOrElse { null }

    private fun recycleBitmaps(bitmaps: List<Bitmap?>) {
        bitmaps.forEach { if (it != null && !it.isRecycled) it.recycle() }
    }
}

private fun PdfTextBlock.toOcrBlock() = OcrTextBlock(
    id = id, text = text, left = left, top = top, right = right, bottom = bottom,
    charLefts = charLefts, charRights = charRights, style = style
)

/** All occurrences of [lower] in this block as tight normalized word rects (fallback: block rect). */
private fun OcrTextBlock.findMatches(lower: String, page: Int): List<FindMatch> {
    if (lower.isEmpty()) return emptyList()
    val bt = text.lowercase()
    val out = ArrayList<FindMatch>()
    // Right-to-left text is stored in visual order: look for the query's visual form too (#72).
    for (q in com.kyant.pdfcore.text.PdfBidi.searchForms(lower)) {
    var from = 0
    while (true) {
        val idx = bt.indexOf(q, from)
        if (idx < 0) break
        val endC = idx + q.length - 1
        if (charLefts.isNotEmpty() && idx < charLefts.size && endC < charRights.size) {
            out.add(FindMatch(page, charLefts[idx], top, charRights[endC], bottom))
        } else {
            out.add(FindMatch(page, left, top, right, bottom))
        }
        from = idx + q.length
    }
    }
    return out
}

/**
 * Where a rendered page prints anything, as a 0..1 rect, or null for a blank page: every pixel that
 * differs clearly from the paper (the commonest corner colour), ignoring rows and columns with a
 * single stray speck.
 */
internal fun pageContentBounds(page: Bitmap): android.graphics.RectF? = runCatching {
    if (page.isRecycled || page.width < 8 || page.height < 8) return null
    val w = minOf(page.width, 200)
    val h = (page.height * w / page.width.toFloat()).toInt().coerceAtLeast(8)
    val small = if (w == page.width) page else Bitmap.createScaledBitmap(page, w, h, true)
    val px = IntArray(small.width * small.height)
    small.getPixels(px, 0, small.width, 0, 0, small.width, small.height)
    val sw = small.width
    val sh = small.height
    if (small !== page) small.recycle()
    val corners = listOf(px[0], px[sw - 1], px[(sh - 1) * sw], px[sh * sw - 1])
    val paper = corners.groupingBy { it }.eachCount().maxByOrNull { it.value }!!.key
    val pr = (paper shr 16) and 0xFF; val pg = (paper shr 8) and 0xFF; val pb = paper and 0xFF
    val rowHits = IntArray(sh)
    val colHits = IntArray(sw)
    for (y in 0 until sh) for (x in 0 until sw) {
        val c = px[y * sw + x]
        val d = kotlin.math.abs(((c shr 16) and 0xFF) - pr) + kotlin.math.abs(((c shr 8) and 0xFF) - pg) + kotlin.math.abs((c and 0xFF) - pb)
        if (d > 60) { rowHits[y]++; colHits[x]++ }
    }
    val top = rowHits.indexOfFirst { it >= 2 }
    val bottom = rowHits.indexOfLast { it >= 2 }
    val left = colHits.indexOfFirst { it >= 2 }
    val right = colHits.indexOfLast { it >= 2 }
    if (top < 0 || left < 0 || bottom <= top || right <= left) return null
    android.graphics.RectF(left / sw.toFloat(), top / sh.toFloat(), (right + 1) / sw.toFloat(), (bottom + 1) / sh.toFloat())
}.getOrNull()
