/*
 * ImageToolbox is an image editor for android
 * Copyright (c) 2026 T8RIN (Malik Mukhametzyanov)
 * Modified by ClearPDF (2026): repackaged and adapted for the ClearPDF image editor.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * You should have received a copy of the Apache License
 * along with this program.  If not, see <http://www.apache.org/licenses/LICENSE-2.0>.
 */

package com.chethan616.clearpdf.imageeditor.thirdparty.cropper

/**
 * Enum for detecting which section of Composable user has initially touched
 */
enum class TouchRegion {
    TopLeft, TopRight, BottomLeft, BottomRight,
    TopCenter, CenterRight, BottomCenter, CenterLeft,
    Inside, None
}

fun handlesTouched(touchRegion: TouchRegion) =
    touchRegion != TouchRegion.None && touchRegion != TouchRegion.Inside
