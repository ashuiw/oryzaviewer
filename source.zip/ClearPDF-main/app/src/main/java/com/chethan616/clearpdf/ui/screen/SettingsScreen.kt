package com.chethan616.clearpdf.ui.screen

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.Transition
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.updateTransition
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.relocation.BringIntoViewRequester
import androidx.compose.foundation.relocation.bringIntoViewRequester
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Compress
import androidx.compose.material.icons.rounded.DarkMode
import androidx.compose.material.icons.rounded.Crop
import androidx.compose.material.icons.rounded.AutoStories
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FileCopy
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.HighQuality
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.LightMode
import androidx.compose.material.icons.rounded.PhoneAndroid
import androidx.compose.material.icons.rounded.PhotoLibrary
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.SwapVert
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.Wallpaper
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.spring
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import com.chethan616.clearpdf.ui.utils.liquidPressGlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chethan616.clearpdf.R
import com.chethan616.clearpdf.data.repository.AppSettingsManager
import com.chethan616.clearpdf.data.repository.GitHubStarPromptManager
import com.chethan616.clearpdf.data.repository.SaveLocationManager
import com.chethan616.clearpdf.office.OfficeEngine
import com.chethan616.clearpdf.ui.components.AccentIconTile
import com.chethan616.clearpdf.ui.components.GlassChoiceChip
import com.chethan616.clearpdf.ui.components.GlassDialog
import com.chethan616.clearpdf.ui.components.GlassDialogAction
import com.chethan616.clearpdf.ui.components.GlassScreenHeaderRow
import com.chethan616.clearpdf.ui.components.GlassScreenScaffold
import com.chethan616.clearpdf.ui.components.LiquidButton
import com.chethan616.clearpdf.ui.components.LiquidGlassDropdown
import com.chethan616.clearpdf.ui.components.LiquidIconButton
import com.chethan616.clearpdf.ui.components.rememberLanguageOptions
import com.chethan616.clearpdf.ui.components.LiquidSlider
import com.chethan616.clearpdf.ui.components.LiquidToggle
import com.chethan616.clearpdf.ui.components.ToolInk
import com.chethan616.clearpdf.ui.components.ToolPrimaryButton
import com.chethan616.clearpdf.ui.components.liquidGlassPanel
import com.chethan616.clearpdf.ui.components.rememberScreenBackdrop
import com.chethan616.clearpdf.ui.theme.LiquidGlassColors
import com.chethan616.clearpdf.ui.theme.ToolAccents
import com.chethan616.clearpdf.ui.utils.rememberUISensor
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import androidx.compose.material.icons.rounded.Layers
import com.kyant.backdrop.backdrops.LayerBackdrop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Settings, rebuilt on the same kit the tool screens and Home use: [liquidGlassPanel] sections
 * (sampling the *sensor*, so their own highlight follows device tilt like every other panel
 * instead of the old bespoke [legacySectionBorder]-style flat card), [GlassChoiceChip] for every
 * picker instead of three hand-rolled [LiquidButton]s per picker, and ONE staggered [updateTransition]
 * entrance instead of twelve independent `animateFloatAsState` pairs. Every setting the old screen
 * had is still here and still does the same thing — this only changes how it looks and how many
 * animation clocks it costs to show it.
 */
@Composable
fun SettingsScreen(
    backdrop: LayerBackdrop,
    isDarkMode: Boolean = false,
    onDarkModeChanged: (Boolean) -> Unit = {},
    themeMode: Int = 0,
    onThemeModeChanged: (Int) -> Unit = {},
    showWallpaper: Boolean = true,
    onShowWallpaperChanged: (Boolean) -> Unit = {},
    reduceGlassMotion: Boolean = false,
    onReduceGlassMotionChanged: (Boolean) -> Unit = {},
    hasCustomWallpaper: Boolean = false,
    onCustomWallpaperChanged: (String?) -> Unit = {},
    selectedLocale: String = "en",
    onLocaleChanged: (String) -> Unit = {},
    onReplayOnboarding: () -> Unit = {}
) {
    val isLight = !isDarkMode
    val ink = LiquidGlassColors.text(isDarkMode)
    val sub = LiquidGlassColors.secondary(isDarkMode)
    val context = LocalContext.current
    val uiSensor = rememberUISensor()
    val settingsScope = rememberCoroutineScope()
    val openRepo = remember(context) { { openExternalLink(context, GitHubStarPromptManager.REPO_URL) } }

    var autoCompress by remember { mutableStateOf(AppSettingsManager.getAutoCompress(context)) }
    var keepOriginal by remember { mutableStateOf(AppSettingsManager.getKeepOriginal(context)) }
    var rememberRecentFiles by remember { mutableStateOf(AppSettingsManager.getRememberRecentFiles(context)) }
    var keepLocalCopies by remember { mutableStateOf(AppSettingsManager.getKeepLocalCopies(context)) }
    var defaultQuality by remember { mutableFloatStateOf(AppSettingsManager.getDefaultQuality(context)) }
    LaunchedEffect(defaultQuality) {
        delay(300L)
        AppSettingsManager.setDefaultQuality(context, defaultQuality)
    }

    var saveUri by remember { mutableStateOf(SaveLocationManager.getSaveUri(context)) }
    // Non-null while the "Delete Office engine?" dialog is up; holds the size it will free.
    var officeEngineDeleteSize by remember { mutableStateOf<Long?>(null) }

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching { context.contentResolver.takePersistableUriPermission(uri, flags) }
            val displayPath = uri.lastPathSegment?.replace("primary:", "") ?: uri.toString()
            SaveLocationManager.setSaveLocation(context, uri, displayPath)
            saveUri = uri
        }
    }
    val wallpaperPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            AppSettingsManager.setCustomWallpaper(context, uri.toString())
            onCustomWallpaperChanged(uri.toString())
        }
    }

    var isVisible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { isVisible = true }
    // One transition for every section's entrance, staggered by index — the same device ToolsScreen
    // uses, in place of the old screen's twelve separate `animateFloatAsState` pairs (six panels,
    // each with its own alpha *and* offsetY Animatable, all running concurrently from first frame).
    val entrance = updateTransition(isVisible, label = "settingsEntrance")

    val screenBackdrop = rememberScreenBackdrop(backdrop)
    // iOS-style: the root is a short index of rows; each topic opens on its own page. The root only
    // ever composes three small glass panels, which is what keeps this tab switch light.
    var page by rememberSaveable { mutableIntStateOf(PageIndex) }
    // First-use tutorial (new in 2.1): point at the Liquid Glass page once.
    var showGlassTour by remember { mutableStateOf(!com.chethan616.clearpdf.data.repository.OnboardingManager.hasSeenGlassSettingsTour(context)) }
    fun finishGlassTour() {
        showGlassTour = false
        com.chethan616.clearpdf.data.repository.OnboardingManager.markGlassSettingsTourSeen(context)
    }
    // The real installed version (the old hard-coded string still said 1.1.0).
    val versionName = remember(context) {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull().orEmpty()
    }
    val versionLabel = stringResource(R.string.settings_version_label) + " " + versionName
    // A sub-page is a focused task: the app's tab bar steps away while it is open.
    androidx.compose.runtime.SideEffect { SettingsSubPage.open = page != PageIndex }
    androidx.compose.runtime.DisposableEffect(Unit) { onDispose { SettingsSubPage.open = false } }
    LaunchedEffect(Unit) {
        if (OfficeEngine.focusSettingsSection.value) {
            OfficeEngine.focusSettingsSection.value = false
            page = PageOffice
        }
    }
    BackHandler(enabled = page != PageIndex) { page = PageIndex }
    val pageTitle = when (page) {
        PageAppearance -> stringResource(R.string.settings_appearance)
        PageLanguage -> stringResource(R.string.settings_language)
        PageFiles -> stringResource(R.string.settings_file_handling)
        PagePersonal -> stringResource(R.string.settings_personalization)
        PageAbout -> stringResource(R.string.settings_about)
        PageLicenses -> stringResource(R.string.settings_licenses)
        PageOffice -> stringResource(R.string.office_engine_title)
        PageGlass -> stringResource(R.string.settings_glass)
        else -> stringResource(R.string.settings_title)
    }
    Box(Modifier.fillMaxSize()) {
        GlassScreenScaffold(
            backdrop = backdrop,
            screenBackdrop = screenBackdrop,
            contentBottomPadding = 84.dp,
            header = { headerBackdrop ->
                GlassScreenHeaderRow(
                    title = pageTitle,
                    backdrop = headerBackdrop,
                    onBack = if (page != PageIndex) ({ page = PageIndex }) else null,
                    // Holding Back on a Settings page returns to Settings itself. The app-wide
                    // default (back to the library) popped all the way Home from in here.
                    onBackLongPress = if (page != PageIndex) ({ page = PageIndex }) else null,
                    backLongPressLabel = stringResource(R.string.settings_title),
                    modifier = entrance.sectionFade(0)
                )
            }
        ) { contentPadding ->
          AnimatedContent(
            targetState = page,
            transitionSpec = {
                // Push / pop: the new page slides in from the side it lives on, on a soft spring.
                val forward = targetState != PageIndex
                val dir = if (forward) 1 else -1
                (fadeIn(tween(200)) + slideInHorizontally(spring(dampingRatio = 0.74f, stiffness = 380f)) { dir * it / 4 }) togetherWith
                    (fadeOut(tween(140)) + slideOutHorizontally(spring(dampingRatio = 1f, stiffness = 520f)) { -dir * it / 6 })
            },
            label = "settingsPage"
          ) { p ->
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(contentPadding),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (p == PageIndex) {
                    val themeLabel = when (themeMode) {
                        1 -> stringResource(R.string.settings_theme_light)
                        2 -> stringResource(R.string.settings_theme_dark)
                        else -> stringResource(R.string.settings_theme_auto)
                    }
                    val langLabel = rememberLanguageOptions().firstOrNull { it.value == selectedLocale }?.label.orEmpty()
                    SettingsSection(backdrop, uiSensor, entrance.sectionFade(1), padding = 8.dp, gap = 0.dp) {
                        SettingsNavRow(Icons.Rounded.Tune, LiquidGlassColors.Orange, stringResource(R.string.settings_appearance), themeLabel, ink, sub) { page = PageAppearance }
                        SettingsDivider(isLight)
                        SettingsNavRow(Icons.Rounded.AutoAwesome, LiquidGlassColors.Teal, stringResource(R.string.settings_glass), null, ink, sub) { if (showGlassTour) finishGlassTour(); page = PageGlass }
                        SettingsDivider(isLight)
                        SettingsNavRow(Icons.Rounded.Language, LiquidGlassColors.Blue, stringResource(R.string.settings_language), langLabel, ink, sub) { page = PageLanguage }
                        SettingsDivider(isLight)
                        SettingsNavRow(Icons.Rounded.Wallpaper, LiquidGlassColors.Indigo, stringResource(R.string.settings_personalization), null, ink, sub) { page = PagePersonal }
                    }
                    com.chethan616.clearpdf.ui.components.GlassGuideCallout(
                        visible = showGlassTour,
                        title = stringResource(R.string.tour_glass_title),
                        message = stringResource(R.string.tour_glass_message),
                        backdrop = backdrop,
                        isLastStep = true,
                        pointsUp = true,
                        onNext = ::finishGlassTour,
                        onSkip = ::finishGlassTour,
                        modifier = Modifier.fillMaxWidth()
                    )
                    SettingsSection(backdrop, uiSensor, entrance.sectionFade(2), padding = 8.dp, gap = 0.dp) {
                        SettingsNavRow(Icons.Rounded.FolderOpen, LiquidGlassColors.Teal, stringResource(R.string.settings_file_handling), null, ink, sub) { page = PageFiles }
                        SettingsDivider(isLight)
                        SettingsNavRow(Icons.Rounded.Description, LiquidGlassColors.Green, stringResource(R.string.office_engine_title), null, ink, sub) { page = PageOffice }
                    }
                    SettingsSection(backdrop, uiSensor, entrance.sectionFade(3), padding = 8.dp, gap = 0.dp) {
                        SettingsNavRow(Icons.Rounded.Info, LiquidGlassColors.Blue, stringResource(R.string.settings_about), versionLabel, ink, sub) { page = PageAbout }
                        SettingsDivider(isLight)
                        SettingsNavRow(Icons.Rounded.Code, LiquidGlassColors.Purple, stringResource(R.string.settings_licenses), null, ink, sub) { page = PageLicenses }
                    }
                }
                // ── Appearance ──
                if (p == PageAppearance) SettingsSection(backdrop, uiSensor, Modifier) {
                    SettingsSectionHeader(Icons.Rounded.Tune, stringResource(R.string.settings_appearance), ink)
                    data class ThemeOption(val idx: Int, val label: String, val icon: ImageVector, val accent: Color)
                    val options = listOf(
                        ThemeOption(0, stringResource(R.string.settings_theme_auto), Icons.Rounded.PhoneAndroid, LiquidGlassColors.Blue),
                        ThemeOption(1, stringResource(R.string.settings_theme_light), Icons.Rounded.LightMode, LiquidGlassColors.Orange),
                        ThemeOption(2, stringResource(R.string.settings_theme_dark), Icons.Rounded.DarkMode, LiquidGlassColors.Purple)
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        options.forEach { option ->
                            GlassChoiceChip(
                                label = option.label,
                                selected = themeMode == option.idx,
                                onClick = { onThemeModeChanged(option.idx) },
                                backdrop = backdrop,
                                accent = option.accent,
                                icon = option.icon,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    BasicText(
                        when (themeMode) {
                            1 -> stringResource(R.string.settings_theme_light_desc)
                            2 -> stringResource(R.string.settings_theme_dark_desc)
                            else -> stringResource(R.string.settings_theme_auto_desc)
                        },
                        style = TextStyle(sub, 12.sp)
                    )
                    SettingsDivider(isLight)
                    // #74: dark pages follow the app's dark mode, so night reading needs no tap.
                    var autoDarkPages by remember { mutableStateOf(com.chethan616.clearpdf.data.repository.AppSettingsManager.getAutoDarkPages(context)) }
                    SettingsToggleRow(
                        icon = Icons.Rounded.DarkMode,
                        title = stringResource(R.string.settings_auto_dark_pages),
                        desc = stringResource(R.string.settings_auto_dark_pages_desc),
                        checked = autoDarkPages,
                        onCheckedChange = {
                            autoDarkPages = it
                            com.chethan616.clearpdf.data.repository.AppSettingsManager.setAutoDarkPages(context, it)
                        },
                        backdrop = backdrop
                    )
                    SettingsDivider(isLight)
                    // #85: page margins trimmed in the viewer, so the text fills the screen.
                    var trimMargins by remember { mutableStateOf(com.chethan616.clearpdf.data.repository.AppSettingsManager.getTrimMargins(context)) }
                    SettingsToggleRow(
                        icon = Icons.Rounded.Crop,
                        title = stringResource(R.string.settings_trim_margins),
                        desc = stringResource(R.string.settings_trim_margins_desc),
                        checked = trimMargins,
                        onCheckedChange = {
                            trimMargins = it
                            com.chethan616.clearpdf.data.repository.AppSettingsManager.setTrimMargins(context, it)
                        },
                        backdrop = backdrop
                    )
                    SettingsDivider(isLight)
                    // #84: one page per screen, turned with a sideways swipe.
                    var bookMode by remember { mutableStateOf(com.chethan616.clearpdf.data.repository.AppSettingsManager.getBookMode(context)) }
                    SettingsToggleRow(
                        icon = Icons.Rounded.AutoStories,
                        title = stringResource(R.string.settings_book_mode),
                        desc = stringResource(R.string.settings_book_mode_desc),
                        checked = bookMode,
                        onCheckedChange = {
                            bookMode = it
                            com.chethan616.clearpdf.data.repository.AppSettingsManager.setBookMode(context, it)
                        },
                        backdrop = backdrop
                    )
                    SettingsDivider(isLight)
                    SettingsToggleRow(
                        icon = Icons.Rounded.Vibration,
                        title = stringResource(R.string.settings_reduce_glass_motion),
                        desc = stringResource(R.string.settings_reduce_glass_motion_desc),
                        checked = reduceGlassMotion,
                        onCheckedChange = onReduceGlassMotionChanged,
                        backdrop = backdrop
                    )
                }

                if (p == PageGlass) GlassTuningPage(backdrop, uiSensor, ink, sub)
                // ── Language ──
                if (p == PageLanguage) SettingsSection(backdrop, uiSensor, Modifier) {
                    SettingsSectionHeader(Icons.Rounded.Language, stringResource(R.string.settings_language), ink)
                    LiquidGlassDropdown(
                        options = rememberLanguageOptions(),
                        selected = selectedLocale,
                        onSelect = onLocaleChanged,
                        backdrop = backdrop,
                        leadingIcon = Icons.Rounded.Language,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // ── Save Location + File Handling + Default Quality ── one panel: three related
                // "how documents are handled" topics, each keeping its own sub-header, so scrolling
                // past this part of the screen pays for one glass surface instead of three.
                if (p == PageFiles) SettingsSection(backdrop, uiSensor, Modifier, gap = 4.dp) {
                    SettingsSectionHeader(Icons.Rounded.FolderOpen, stringResource(R.string.settings_save_location), LiquidGlassColors.Blue, bottomPad = 8.dp)
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(LiquidGlassColors.neutralSurface(isDarkMode))
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AccentIconTile(Icons.Rounded.FolderOpen, LiquidGlassColors.Blue, size = 40, iconSize = 20)
                        Column(Modifier.weight(1f)) {
                            BasicText(
                                if (saveUri != null) stringResource(R.string.settings_custom_directory) else stringResource(R.string.settings_default_directory),
                                style = TextStyle(ink, 14.sp, FontWeight.SemiBold)
                            )
                            val path = saveUri?.let { it.lastPathSegment?.replace("primary:", "") ?: it.toString() }
                                ?: stringResource(R.string.settings_default_path)
                            BasicText(path, style = TextStyle(sub, 12.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        ToolPrimaryButton(
                            text = stringResource(R.string.settings_change_folder),
                            onClick = { folderPicker.launch(null) },
                            backdrop = backdrop,
                            accent = LiquidGlassColors.Teal,
                            modifier = Modifier.weight(1f)
                        )
                        if (saveUri != null) {
                            ToolPrimaryButton(
                                text = stringResource(R.string.settings_reset),
                                onClick = { SaveLocationManager.clearSaveLocation(context); saveUri = null },
                                backdrop = backdrop,
                                accent = LiquidGlassColors.Orange
                            )
                        }
                    }

                    SettingsDivider(isLight)
                    SettingsSectionHeader(Icons.Rounded.Description, stringResource(R.string.settings_file_handling), ink, bottomPad = 8.dp)
                    SettingsToggleRow(
                        icon = Icons.Rounded.Compress,
                        title = stringResource(R.string.settings_auto_compress),
                        desc = stringResource(R.string.settings_auto_compress_desc),
                        checked = autoCompress,
                        onCheckedChange = { autoCompress = it; AppSettingsManager.setAutoCompress(context, it) },
                        backdrop = backdrop
                    )
                    SettingsDivider(isLight)
                    SettingsToggleRow(
                        icon = Icons.Rounded.FileCopy,
                        title = stringResource(R.string.settings_keep_original),
                        desc = stringResource(R.string.settings_keep_original_desc),
                        checked = keepOriginal,
                        onCheckedChange = { keepOriginal = it; AppSettingsManager.setKeepOriginal(context, it) },
                        backdrop = backdrop
                    )
                    SettingsDivider(isLight)
                    SettingsToggleRow(
                        icon = Icons.Rounded.Description,
                        title = stringResource(R.string.settings_remember_recent_files),
                        desc = stringResource(R.string.settings_remember_recent_files_desc),
                        checked = rememberRecentFiles,
                        onCheckedChange = { rememberRecentFiles = it; AppSettingsManager.setRememberRecentFiles(context, it) },
                        backdrop = backdrop
                    )
                    SettingsDivider(isLight)
                    SettingsToggleRow(
                        icon = Icons.Rounded.FolderOpen,
                        title = stringResource(R.string.settings_keep_local_copies),
                        desc = stringResource(R.string.settings_keep_local_copies_desc),
                        checked = keepLocalCopies,
                        onCheckedChange = {
                            keepLocalCopies = it
                            settingsScope.launch(Dispatchers.IO) { AppSettingsManager.setKeepLocalCopies(context, it) }
                        },
                        backdrop = backdrop
                    )

                    SettingsDivider(isLight)
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        SettingsSectionHeader(Icons.Rounded.HighQuality, stringResource(R.string.settings_compression_quality), LiquidGlassColors.Blue, bottomPad = 0.dp)
                        Box(
                            Modifier.clip(RoundedCornerShape(8.dp)).background(LiquidGlassColors.Blue.copy(0.14f)).padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            BasicText("${(defaultQuality * 100).toInt()}%", style = TextStyle(LiquidGlassColors.Blue, 13.sp, FontWeight.Bold))
                        }
                    }
                    LiquidSlider(
                        value = { defaultQuality },
                        onValueChange = { defaultQuality = ((it * 100f).toInt() / 100f).coerceIn(0f, 1f) },
                        valueRange = 0f..1f,
                        visibilityThreshold = 0.005f,
                        backdrop = backdrop,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        BasicText(stringResource(R.string.settings_smaller_size), style = TextStyle(sub.copy(0.7f), 11.sp))
                        BasicText(stringResource(R.string.settings_higher_quality), style = TextStyle(sub.copy(0.7f), 11.sp))
                    }
                }

                // ── Personalization ──
                if (p == PagePersonal) SettingsSection(backdrop, uiSensor, Modifier, gap = 4.dp) {
                    SettingsSectionHeader(Icons.Rounded.Wallpaper, stringResource(R.string.settings_personalization), ink, bottomPad = 8.dp)
                    SettingsToggleRow(
                        icon = Icons.Rounded.Vibration,
                        title = stringResource(R.string.settings_haptics),
                        desc = stringResource(R.string.settings_haptics_desc),
                        checked = com.chethan616.clearpdf.ui.components.GlassSettings.hapticsEnabled,
                        onCheckedChange = { com.chethan616.clearpdf.ui.components.GlassSettings.setHaptics(context, it) },
                        backdrop = backdrop
                    )
                    SettingsDivider(isLight)
                    // The viewer's open/share morph: swap what the tap and the hold-and-swipe do.
                    var invertShareMorph by remember { mutableStateOf(AppSettingsManager.getInvertShareMorph(context)) }
                    SettingsToggleRow(
                        icon = Icons.Rounded.SwapVert,
                        title = stringResource(R.string.settings_invert_share_morph),
                        desc = stringResource(R.string.settings_invert_share_morph_desc),
                        checked = invertShareMorph,
                        onCheckedChange = { invertShareMorph = it; AppSettingsManager.setInvertShareMorph(context, it) },
                        backdrop = backdrop
                    )
                    SettingsDivider(isLight)
                    SettingsToggleRow(
                        icon = Icons.Rounded.Wallpaper,
                        title = stringResource(R.string.settings_background),
                        desc = stringResource(R.string.settings_background_desc),
                        checked = showWallpaper,
                        onCheckedChange = onShowWallpaperChanged,
                        backdrop = backdrop
                    )
                    if (showWallpaper) {
                        Row(
                            Modifier.fillMaxWidth().padding(top = 8.dp, start = 46.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ToolPrimaryButton(
                                text = stringResource(R.string.settings_bg_gallery),
                                onClick = { wallpaperPicker.launch(arrayOf("image/*")) },
                                backdrop = backdrop,
                                accent = LiquidGlassColors.Indigo,
                                icon = Icons.Rounded.PhotoLibrary,
                                modifier = Modifier.weight(1f)
                            )
                            LiquidIconButton(
                                onClick = { AppSettingsManager.clearCustomWallpaper(context); onCustomWallpaperChanged(null) },
                                backdrop = backdrop,
                                modifier = Modifier.size(44.dp)
                            ) {
                                Icon(Icons.Rounded.Refresh, stringResource(R.string.settings_reset), Modifier.size(18.dp), if (hasCustomWallpaper) ink else ink.copy(0.4f))
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    ToolPrimaryButton(
                        text = stringResource(R.string.settings_replay_onboarding),
                        onClick = onReplayOnboarding,
                        backdrop = backdrop,
                        accent = LiquidGlassColors.Purple,
                        icon = Icons.Rounded.AutoAwesome,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                // ── About & Open Source + Licenses ── one panel: the credits list is part of "about
                // the app", not a topic of its own, and folding it in here removes the single
                // heaviest remaining glass surface (the longest scroll content on the screen).
                if (p == PageAbout) SettingsSection(backdrop, uiSensor, Modifier, padding = 24.dp, horizontalAlignment = Alignment.CenterHorizontally) {
                    AccentIconTile(Icons.Rounded.Info, LiquidGlassColors.Blue, size = 56, iconSize = 28)
                    BasicText("ClearPDF", style = TextStyle(ink, 20.sp, FontWeight.Bold))
                    BasicText(versionLabel, style = TextStyle(sub, 13.sp))
                    BasicText(stringResource(R.string.settings_made_by), style = TextStyle(sub, 13.sp, textAlign = TextAlign.Center))
                    Spacer(Modifier.height(4.dp))
                    ToolPrimaryButton(
                        text = stringResource(R.string.settings_star_github),
                        onClick = openRepo,
                        backdrop = backdrop,
                        accent = ToolAccents.Star,
                        icon = Icons.Rounded.Star,
                        modifier = Modifier.fillMaxWidth()
                    )
                    BasicText(stringResource(R.string.settings_open_source), style = TextStyle(sub.copy(0.7f), 11.sp, textAlign = TextAlign.Center))
                }

                if (p == PageLicenses) SettingsSection(backdrop, uiSensor, Modifier) {
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        OpenSourceCredits.forEachIndexed { index, credit ->
                            if (index > 0) SettingsDivider(isLight)
                            LicenseItem(credit.name, credit.author, credit.license, credit.url, ink, sub)
                        }
                        SettingsDivider(isLight)
                        BasicText(stringResource(R.string.settings_license_notice), style = TextStyle(sub.copy(0.7f), 11.sp, lineHeight = 16.sp))
                    }
                }

                // ── Office engine (optional, powered by LibreOffice) ──
                if (p == PageOffice) OfficeEngineSettingsSection(
                    backdrop = backdrop,
                    isLight = isLight,
                    textColor = ink,
                    labelColor = ink,
                    subColor = sub,
                    onRequestDelete = { officeEngineDeleteSize = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .liquidGlassPanel(backdrop, uiSensor, withShadow = false)
                        .padding(20.dp)
                )
            }
          }
        }
    }
    // Outside the scaffold's captured layer so it refracts the live screen (wallpaper + content).
    GlassDialog(
        visible = officeEngineDeleteSize != null,
        onDismiss = { officeEngineDeleteSize = null },
        backdrop = screenBackdrop.glass,
        title = stringResource(R.string.office_engine_delete_title),
        actions = {
            GlassDialogAction(text = stringResource(R.string.office_engine_cancel), onClick = { officeEngineDeleteSize = null })
            GlassDialogAction(
                text = stringResource(R.string.office_engine_delete),
                onClick = { officeEngineDeleteSize = null; OfficeEngine.installer(context).uninstall() },
                primary = true,
                destructive = true
            )
        }
    ) {
        BasicText(
            stringResource(R.string.office_engine_delete_message, android.text.format.Formatter.formatShortFileSize(context, officeEngineDeleteSize ?: 0L)),
            style = TextStyle(ink, 14.sp, lineHeight = 20.sp)
        )
    }
}

// With panels now merged down to 7 sections (was 9), the cascade is shorter on its own, but the
// per-step/duration values were still the original, slower ones -- the last section didn't finish
// appearing until ~725ms after landing on the screen, which on top of the nav transition itself
// read as "the screen is still loading" rather than a snappy tab switch.
private const val SettingsStaggerStepMs = 20

private const val PageIndex = 0

/** Whether a Settings sub-page (Appearance, Language…) is open — the app hides its tab bar then. */
object SettingsSubPage {
    var open by androidx.compose.runtime.mutableStateOf(false)
}
private const val PageAppearance = 1
private const val PageLanguage = 2
private const val PageFiles = 3
private const val PagePersonal = 4
private const val PageAbout = 5
private const val PageLicenses = 6
private const val PageOffice = 7
private const val PageGlass = 8

/**
 * Settings -> Liquid Glass: kyant's Glass Playground knobs, app-wide. A live preview chip sits over a
 * busy swatch (the wallpaper is usually flat, which would hide blur and refraction), presets on top,
 * then every parameter. Changes apply to every glass surface instantly and persist.
 */
@Composable
private fun GlassTuningPage(
    backdrop: Backdrop,
    uiSensor: com.chethan616.clearpdf.ui.utils.UISensor,
    ink: Color,
    sub: Color
) {
    val context = LocalContext.current
    val style = com.chethan616.clearpdf.ui.components.GlassSettings.style
    fun set(s: com.chethan616.clearpdf.ui.components.GlassStyle) =
        com.chethan616.clearpdf.ui.components.GlassSettings.update(context, s)
    val isLight = !com.chethan616.clearpdf.ui.theme.LocalIsDarkMode.current

    // Preview: a glass chip over a vivid, detailed strip so every knob is visible.
    val previewBackdrop = com.kyant.backdrop.backdrops.rememberLayerBackdrop()
    Box(
        Modifier
            .fillMaxWidth()
            .height(150.dp)
            .clip(RoundedCornerShape(28.dp)),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .matchParentSize()
                .layerBackdrop(previewBackdrop)
                .background(
                    androidx.compose.ui.graphics.Brush.linearGradient(
                        listOf(Color(0xFF0A84FF), Color(0xFFBF5AF2), Color(0xFFFF375F), Color(0xFFFF9F0A), Color(0xFF30D158))
                    )
                )
        ) {
            Column(Modifier.matchParentSize().padding(14.dp), verticalArrangement = Arrangement.SpaceBetween) {
                repeat(4) {
                    BasicText("ClearPDF  •  Aa Bb Cc  •  0123456789", style = TextStyle(Color.White.copy(0.9f), 13.sp, FontWeight.Bold), maxLines = 1)
                }
            }
        }
        LiquidButton(onClick = {}, backdrop = previewBackdrop, surfaceColor = if (isLight) Color(0xFFFAFAFA).copy(0.35f) else Color(0xFF1E1E1E).copy(0.35f)) {
            BasicText(stringResource(R.string.glass_preview), style = TextStyle(ink, 16.sp, FontWeight.SemiBold))
        }
    }

    SettingsSection(backdrop, uiSensor, Modifier, gap = 12.dp) {
        val presets = listOf(
            com.chethan616.clearpdf.ui.components.GlassStyle.Default to stringResource(R.string.glass_preset_default),
            com.chethan616.clearpdf.ui.components.GlassStyle.Readable to stringResource(R.string.glass_preset_readable),
            com.chethan616.clearpdf.ui.components.GlassStyle.Crystal to stringResource(R.string.glass_preset_crystal),
            com.chethan616.clearpdf.ui.components.GlassStyle.Performance to stringResource(R.string.glass_preset_performance)
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            presets.forEach { (p, label) ->
                GlassChoiceChip(label = label, selected = style == p, onClick = { set(p) }, backdrop = backdrop, accent = LiquidGlassColors.Blue)
            }
        }
    }

    SettingsSection(backdrop, uiSensor, Modifier, gap = 6.dp) {
        @Composable
        fun knob(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                BasicText(label, style = TextStyle(ink, 14.sp, FontWeight.Medium))
                BasicText("%.2f".format(value), style = TextStyle(sub, 13.sp))
            }
            LiquidSlider(
                value = { value },
                onValueChange = onChange,
                valueRange = range,
                visibilityThreshold = 0.005f,
                backdrop = backdrop,
                modifier = Modifier.fillMaxWidth()
            )
        }
        knob(stringResource(R.string.glass_blur), style.blur, 0f..3f) { set(style.copy(blur = it)) }
        knob(stringResource(R.string.glass_refraction_height), style.refractionHeight, 0f..2f) { set(style.copy(refractionHeight = it)) }
        knob(stringResource(R.string.glass_refraction_amount), style.refractionAmount, 0f..2f) { set(style.copy(refractionAmount = it)) }
        knob(stringResource(R.string.glass_tint), style.tint, 0f..2.5f) { set(style.copy(tint = it)) }
        knob(stringResource(R.string.glass_vibrancy), style.saturation, 0.5f..2.5f) { set(style.copy(saturation = it)) }
        knob(stringResource(R.string.glass_brightness), style.brightness, -0.3f..0.3f) { set(style.copy(brightness = it)) }
        knob(stringResource(R.string.glass_highlight), style.highlight, 0f..1f) { set(style.copy(highlight = it)) }
        knob(stringResource(R.string.glass_corners), style.corners, 0.4f..1.4f) { set(style.copy(corners = it)) }
        SettingsDivider(isLight)
        SettingsToggleRow(
            icon = Icons.Rounded.Layers,
            title = stringResource(R.string.glass_depth),
            desc = stringResource(R.string.glass_depth_desc),
            checked = style.depthEffect,
            onCheckedChange = { set(style.copy(depthEffect = it)) },
            backdrop = backdrop
        )
        SettingsDivider(isLight)
        SettingsToggleRow(
            icon = Icons.Rounded.AutoAwesome,
            title = stringResource(R.string.glass_chromatic),
            desc = stringResource(R.string.glass_chromatic_desc),
            checked = style.chromaticAberration,
            onCheckedChange = { set(style.copy(chromaticAberration = it)) },
            backdrop = backdrop
        )
        Spacer(Modifier.height(8.dp))
        ToolPrimaryButton(
            text = stringResource(R.string.glass_reset),
            onClick = { set(com.chethan616.clearpdf.ui.components.GlassStyle.Default) },
            backdrop = backdrop,
            accent = LiquidGlassColors.Blue,
            icon = Icons.Rounded.Refresh,
            modifier = Modifier.fillMaxWidth()
        )
    }

    MotionTuningSection(backdrop, uiSensor, ink, sub)
}

/**
 * Settings -> Liquid Glass -> Motion: the spring physics every glass control shares (press swell,
 * release jiggle, drag stretch, long-press bloom, bounce and speed), with profiles and a button to
 * feel the result. Values are multipliers on the designed motion; Normal is the design.
 */
@Composable
private fun MotionTuningSection(
    backdrop: Backdrop,
    uiSensor: com.chethan616.clearpdf.ui.utils.UISensor,
    ink: Color,
    sub: Color
) {
    val context = LocalContext.current
    val motion = com.chethan616.clearpdf.ui.components.MotionSettings.style
    fun set(m: com.chethan616.clearpdf.ui.components.MotionStyle) =
        com.chethan616.clearpdf.ui.components.MotionSettings.update(context, m)
    val presets = listOf(
        com.chethan616.clearpdf.ui.components.MotionStyle.Normal to stringResource(R.string.motion_preset_normal),
        com.chethan616.clearpdf.ui.components.MotionStyle.Performance to stringResource(R.string.motion_preset_performance),
        com.chethan616.clearpdf.ui.components.MotionStyle.Bouncy to stringResource(R.string.motion_preset_bouncy),
        com.chethan616.clearpdf.ui.components.MotionStyle.SuperSpringy to stringResource(R.string.motion_preset_super)
    )
    SettingsSection(backdrop, uiSensor, Modifier, gap = 10.dp) {
        BasicText(stringResource(R.string.glass_motion), style = TextStyle(ink, 17.sp, FontWeight.SemiBold))
        BasicText(stringResource(R.string.glass_motion_desc), style = TextStyle(sub, 13.sp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            presets.forEach { (m, label) ->
                GlassChoiceChip(label = label, selected = motion == m, onClick = { set(m) }, backdrop = backdrop, accent = LiquidGlassColors.Purple)
            }
            if (presets.none { it.first == motion }) {
                GlassChoiceChip(label = stringResource(R.string.glass_preset_custom), selected = true, onClick = {}, backdrop = backdrop, accent = LiquidGlassColors.Purple)
            }
        }
        // Press it to feel the current physics.
        Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
            LiquidButton(onClick = {}, backdrop = backdrop, tint = LiquidGlassColors.Purple) {
                BasicText(
                    stringResource(R.string.motion_try),
                    style = TextStyle(Color.White, 15.sp, FontWeight.SemiBold),
                    modifier = Modifier.padding(horizontal = 18.dp)
                )
            }
        }
    }
    SettingsSection(backdrop, uiSensor, Modifier, gap = 6.dp) {
        @Composable
        fun knob(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                BasicText(label, style = TextStyle(ink, 14.sp, FontWeight.Medium))
                BasicText("%.2f".format(value), style = TextStyle(sub, 13.sp))
            }
            LiquidSlider(
                value = { value },
                onValueChange = onChange,
                valueRange = range,
                visibilityThreshold = 0.005f,
                backdrop = backdrop,
                modifier = Modifier.fillMaxWidth()
            )
        }
        knob(stringResource(R.string.motion_bounce), motion.bounce, 0f..1f) { set(motion.copy(bounce = it)) }
        knob(stringResource(R.string.motion_speed), motion.speed, 0.5f..2f) { set(motion.copy(speed = it)) }
        knob(stringResource(R.string.motion_press), motion.press, 0f..2.5f) { set(motion.copy(press = it)) }
        knob(stringResource(R.string.motion_wobble), motion.wobble, 0f..3f) { set(motion.copy(wobble = it)) }
        knob(stringResource(R.string.motion_stretch), motion.stretch, 0f..2.5f) { set(motion.copy(stretch = it)) }
        knob(stringResource(R.string.motion_bloom), motion.bloom, 0f..2.5f) { set(motion.copy(bloom = it)) }
        Spacer(Modifier.height(8.dp))
        ToolPrimaryButton(
            text = stringResource(R.string.motion_reset),
            onClick = { set(com.chethan616.clearpdf.ui.components.MotionStyle.Default) },
            backdrop = backdrop,
            accent = LiquidGlassColors.Purple,
            icon = Icons.Rounded.Refresh,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** One row of the Settings index: tinted icon tile, title, current value, chevron — iOS Settings. */
@Composable
private fun SettingsNavRow(
    icon: ImageVector,
    accent: Color,
    title: String,
    value: String?,
    ink: Color,
    sub: Color,
    onClick: () -> Unit
) {
    val isLight = !com.chethan616.clearpdf.ui.theme.LocalIsDarkMode.current
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by androidx.compose.animation.core.animateFloatAsState(
        if (pressed) 0.97f else 1f,
        com.chethan616.clearpdf.ui.components.GlassMotion.press(),
        label = "navRowPress"
    )
    Row(
        Modifier
            .fillMaxWidth()
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(18.dp))
            .liquidPressGlow(interaction, onLight = isLight)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        AccentIconTile(icon, accent, size = 34, iconSize = 18)
        BasicText(title, Modifier.weight(1f), style = TextStyle(ink, 16.sp, FontWeight.Medium), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (value != null) BasicText(value, style = TextStyle(sub, 14.sp), maxLines = 1)
        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, Modifier.size(20.dp), sub.copy(alpha = 0.7f))
    }
}

/** Fade-only entrance for a glass section — translating a `liquidGlassPanel` re-samples its backdrop
 *  every frame of the slide, which is the jank this replaces (see ToolsScreen's own note). */
@Composable
private fun Transition<Boolean>.sectionFade(index: Int): Modifier {
    val fadeAlpha by animateFloat(
        transitionSpec = { tween(durationMillis = 200, delayMillis = SettingsStaggerStepMs * index, easing = FastOutSlowInEasing) },
        label = "settingsFade$index"
    ) { if (it) 1f else 0f }
    return Modifier.graphicsLayer { alpha = fadeAlpha; compositingStrategy = androidx.compose.ui.graphics.CompositingStrategy.ModulateAlpha }
}

/** One glass panel, built from [liquidGlassPanel] exactly like every tool screen's own sections. */
@Composable
private fun SettingsSection(
    backdrop: Backdrop,
    uiSensor: com.chethan616.clearpdf.ui.utils.UISensor,
    entranceModifier: Modifier,
    padding: androidx.compose.ui.unit.Dp = 20.dp,
    gap: androidx.compose.ui.unit.Dp = 16.dp,
    horizontalAlignment: Alignment.Horizontal = Alignment.Start,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .then(entranceModifier)
            .liquidGlassPanel(backdrop, uiSensor, withShadow = false)
            .padding(padding),
        verticalArrangement = Arrangement.spacedBy(gap),
        horizontalAlignment = horizontalAlignment,
        content = content
    )
}

@Composable
private fun SettingsSectionHeader(icon: ImageVector, title: String, tint: Color, bottomPad: androidx.compose.ui.unit.Dp = 0.dp) {
    Row(
        Modifier.padding(bottom = bottomPad),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(icon, null, Modifier.size(22.dp), tint)
        BasicText(title, style = TextStyle(ToolInk.text(), 17.sp, FontWeight.SemiBold))
    }
}

@Composable
private fun SettingsDivider(isLight: Boolean) {
    Box(Modifier.fillMaxWidth().padding(vertical = 4.dp).height(1.dp).background(if (isLight) Color.Black.copy(0.04f) else Color.White.copy(0.06f)))
}

private fun openExternalLink(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) })
    }
}

/** A row's accent icon badge + title/description + [LiquidToggle] — the same icon-tile language
 *  [AccentIconTile] uses, just sized for a list row instead of a hero card. */
@Composable
private fun SettingsToggleRow(
    icon: ImageVector,
    title: String,
    desc: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    backdrop: Backdrop
) {
    val ink = ToolInk.text()
    val sub = ToolInk.secondary()
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onCheckedChange(!checked) }
            .padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AccentIconTile(icon, LiquidGlassColors.Blue, size = 34, iconSize = 17)
        Column(Modifier.weight(1f)) {
            BasicText(title, style = TextStyle(ink, 15.sp, FontWeight.Medium))
            BasicText(desc, style = TextStyle(sub, 12.sp))
        }
        LiquidToggle(selected = { checked }, onSelect = onCheckedChange, backdrop = backdrop)
    }
}

private class Credit(val name: String, val author: String, val license: String, val url: String)

/**
 * Ordered roughly by how much of the app each one carries.
 *
 * Note what is *not* here: the .xlsx reader and the PowerPoint slide renderer are written in this
 * repo against the published OOXML layout, not borrowed. That was a size decision — the libraries
 * that read Office formats properly on Android (POI's OOXML half plus XmlBeans at ~17 MB, or
 * OpenDocument.core's 100 MB AAR) are far more than this app can carry for a viewer. POI appears
 * below only for the *legacy* binary .doc/.xls/.ppt formats, which are not XML and cannot be read
 * this way. Word layout is the one place a library won on merit: docx-preview delegates to the
 * browser engine the phone already has, so it costs ~48 KB rather than tens of megabytes.
 */
private val OpenSourceCredits = listOf(
    Credit("AndroidLiquidGlass", "Kyant", "Apache License 2.0", "https://github.com/Kyant0/AndroidLiquidGlass"),
    Credit("PdfBox-Android", "Tom Roush", "Apache License 2.0 — PDF text, forms and annotation export", "https://github.com/TomRoush/PdfBox-Android"),
    Credit("Apache POI", "The Apache Software Foundation", "Apache License 2.0 — legacy .doc / .xls / .ppt reading", "https://poi.apache.org"),
    Credit("Carlito", "The Carlito Project Authors", "SIL Open Font License 1.1 — Calibri-metric font for spreadsheets", "https://github.com/googlefonts/carlito"),
    Credit("ML Kit Text Recognition", "Google", "Apache License 2.0 — bundled on-device OCR, no network", "https://developers.google.com/ml-kit/vision/text-recognition"),
    Credit("Tesseract4Android", "Adaptech s.r.o.", "Apache License 2.0 — offline OCR fallback", "https://github.com/adaptech-cz/Tesseract4Android"),
    Credit("Tesseract OCR", "Google / Tesseract contributors", "Apache License 2.0", "https://github.com/tesseract-ocr/tesseract"),
    Credit("Leptonica", "Dan Bloomberg", "BSD 2-Clause — image processing behind Tesseract", "https://github.com/DanBloomberg/leptonica"),
    Credit("docx-preview", "Volodymyr Baydalka", "Apache License 2.0 — Word document layout", "https://github.com/VolodymyrBaydalka/docxjs"),
    Credit("JSZip", "Stuart Knightley", "MIT License (used under MIT of its MIT/GPLv3 dual licence)", "https://github.com/Stuk/jszip"),
    Credit("Gander", "Arjun Maniyani", "MIT License — night reading (hue-keeping colours, photos left as printed) and Word page ideas", "https://github.com/mokshablr/gander"),
    Credit("ImageToolbox", "T8RIN (Malik Mukhametzyanov)", "Apache License 2.0 — image editor cropper, perspective crop and draw engine (adapted)", "https://github.com/T8RIN/ImageToolbox"),
    Credit("GPUImage for Android", "CyberAgent, Inc.", "Apache License 2.0 — image editor adjustments and filters", "https://github.com/cats-oss/android-gpuimage"),
    Credit("ML Kit Subject Segmentation", "Google", "Google APIs Terms — optional background removal via Play services", "https://developers.google.com/ml-kit/vision/subject-segmentation"),
    Credit("LibreOffice", "The Document Foundation", "Mozilla Public License 2.0 — optional Office engine (downloaded on request, not bundled)", "https://www.libreoffice.org/about-us/licenses/"),
    Credit("Pdf_Tools", "Karna14314", "PDF viewer zoom/pan reference", "https://github.com/Karna14314/Pdf_Tools")
)

@Composable
private fun LicenseItem(name: String, author: String, license: String, url: String, labelColor: Color, subColor: Color) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            BasicText(name, style = TextStyle(labelColor, 14.sp, FontWeight.Medium))
            BasicText(stringResource(R.string.settings_license_author, author), style = TextStyle(subColor, 12.sp))
        }
        BasicText(license, style = TextStyle(subColor, 11.sp))
        val context = LocalContext.current
        BasicText(
            url,
            style = TextStyle(LiquidGlassColors.Blue, 11.sp),
            modifier = Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { openExternalLink(context, url) }
        )
    }
}
