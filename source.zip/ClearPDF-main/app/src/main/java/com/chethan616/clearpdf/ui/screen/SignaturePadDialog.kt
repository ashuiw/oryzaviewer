package com.chethan616.clearpdf.ui.screen

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import androidx.compose.ui.res.stringResource
import com.chethan616.clearpdf.R
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBackIosNew
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Undo
import androidx.compose.material.icons.rounded.Gesture
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.chethan616.clearpdf.ui.components.LiquidButton
import com.chethan616.clearpdf.ui.components.LiquidIconButton
import com.chethan616.clearpdf.ui.components.LiquidSlider
import com.chethan616.clearpdf.ui.theme.LocalIsDarkMode
import com.chethan616.clearpdf.ui.utils.rememberUISensor
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.backdrops.LayerBackdrop
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import com.chethan616.clearpdf.ui.components.GlassDialog
import com.chethan616.clearpdf.ui.components.GlassDialogAction
import com.chethan616.clearpdf.ui.theme.LiquidGlassColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Full-screen signature capture dialog. Presents a dark canvas for the user to draw
 * their signature with white ink. On "Done", exports a transparent-background bitmap.
 */
@Composable
fun SignaturePadDialog(
    backdrop: LayerBackdrop,
    onDismiss: () -> Unit,
    onSignatureCaptured: (Bitmap) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val uiSensor = rememberUISensor()
    val scope = rememberCoroutineScope()

    // Theme-adaptive chrome. Everything that sits on the SCREEN background — header, action buttons,
    // section labels — flips with the app theme: white ink on the dark screen, near-black on the
    // light one. The signing paper (canvas) and the control tray stay light in both, so dark ink is
    // always visible while drawing and stamps legibly onto white PDF pages.
    val isDark = LocalIsDarkMode.current
    val chrome = if (isDark) Color.White else Color(0xFF15171C)
    val chromeSoft = chrome.copy(0.55f)
    val chromeChip = if (isDark) Color.White.copy(0.08f) else Color.Black.copy(0.05f)
    val screenGradient = if (isDark)
        listOf(Color(0xFF171A21), Color(0xFF0C0E13), Color(0xFF060709))
    else
        listOf(Color(0xFFF3F4F6), Color(0xFFEAECEF), Color(0xFFE2E5E9))
    // Light control tray: paper-on-dark needs no outline; white-on-light needs a hairline to define
    // its edge against the near-white screen.
    val trayColor = if (isDark) Color(0xFFF2F2EE) else Color(0xFFFFFFFF)
    val cardBorder = if (isDark) Color.Transparent else Color.Black.copy(0.06f)

    data class StrokeItem(val points: List<Offset>, val color: Color, val width: Float)
    val strokes = remember { mutableStateListOf<StrokeItem>() }
    var currentStroke by remember { mutableStateOf<List<Offset>>(emptyList()) }
    var canvasSize by remember { mutableStateOf(IntSize.Zero) }

    // Dark inks for a white "paper" pad — natural to sign with, and (unlike white ink)
    // the resulting signature is actually visible when stamped onto a white PDF page.
    val signatureColors = listOf(
        Color(0xFF141414), // Black
        Color(0xFF1565C0), // Ink Blue
        Color(0xFF0D3B66), // Navy
        Color(0xFFB3261E), // Crimson
        Color(0xFF1B5E20), // Green
        Color(0xFF6A1B9A)  // Purple
    )
    var selectedColor by remember { mutableStateOf(signatureColors[0]) }

    var selectedWidth by remember { androidx.compose.runtime.mutableFloatStateOf(6.5f) }
    var contentVisible by remember { mutableStateOf(false) }
    var showNamePrompt by remember { mutableStateOf(false) }
    var signatureName by rememberSaveable { mutableStateOf("") }
    var pendingSignature by remember { mutableStateOf<Bitmap?>(null) }
    val nameFocusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        contentVisible = true
    }

    // Play the exit animation FULLY, THEN actually dismiss (Dialogs otherwise snap shut).
    // Delay must be >= the exit duration below (fade 200 / slide 300) so it never cuts off.
    val requestClose: () -> Unit = {
        contentVisible = false
        scope.launch { delay(310); onDismiss() }
        Unit
    }

    LaunchedEffect(showNamePrompt) {
        if (showNamePrompt) {
            delay(120)
            runCatching { nameFocusRequester.requestFocus() }
        }
    }

    data class SavedSignature(val name: String, val bitmap: Bitmap, val file: java.io.File)
    val savedSignatures = remember(context) {
        mutableStateListOf<SavedSignature>().apply {
            try {
                com.chethan616.clearpdf.data.repository.SignatureManager
                    .listSignatures(context)
                    .mapNotNull { file ->
                        com.chethan616.clearpdf.data.repository.SignatureManager
                            .loadSignature(file)
                            ?.let { SavedSignature(
                                com.chethan616.clearpdf.data.repository.SignatureManager.displayName(file),
                                it,
                                file
                            ) }
                    }
                    .forEach(::add)
            } catch (_: Throwable) {}
        }
    }
    // Long-pressed saved signature awaiting a delete confirmation.
    var signatureToDelete by remember { mutableStateOf<SavedSignature?>(null) }
    // Kept after dismissal so the card's exit animation doesn't flash an empty name.
    var lastDeleteName by remember { mutableStateOf("") }
    LaunchedEffect(signatureToDelete) { signatureToDelete?.let { lastDeleteName = it.name } }
    val padBackdrop = rememberLayerBackdrop()

    val confirmSignatureName = {
        val bitmap = pendingSignature
        val trimmedName = signatureName.trim()
        if (bitmap != null && trimmedName.isNotEmpty()) {
            runCatching {
                com.chethan616.clearpdf.data.repository.SignatureManager
                    .saveSignature(context, bitmap, trimmedName)
            }
            showNamePrompt = false
            pendingSignature = null
            onSignatureCaptured(bitmap)
        }
    }

    Dialog(
        onDismissRequest = requestClose,
        // decorFitsSystemWindows = false → the dialog draws edge-to-edge (behind the
        // status/nav bars) so there are no gaps above/below. dismissOnBackPress = false
        // so the back gesture routes through requestClose and plays the exit animation.
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = false,
            decorFitsSystemWindows = false
        )
    ) {
        BackHandler { requestClose() }
        // The pad is captured into its own layer so the naming / delete cards (drawn on top, inside
        // this same window) are real liquid glass refracting the signing screen. They used to be
        // solid cards in nested Dialog windows, which cannot sample anything.
        Box(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().layerBackdrop(padBackdrop)) {
        AnimatedVisibility(
            visible = contentVisible,
            modifier = Modifier.fillMaxSize(),
            // Slide in/out like a pushed screen (not a modal pop).
            enter = fadeIn(tween(200)) + slideInHorizontally(tween(300)) { it / 3 },
            exit  = fadeOut(tween(200)) + slideOutHorizontally(tween(260)) { it / 3 }
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    // A soft top-lit gradient (dark or light per theme) gives the screen depth and
                    // lets the light signing cards read as "paper on a desk" rather than floating.
                    .background(Brush.verticalGradient(screenGradient))
            ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .navigationBarsPadding()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
            // Header
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                LiquidIconButton(
                    onClick = requestClose,
                    backdrop = backdrop,
                    surfaceColor = chromeChip,
                    modifier = Modifier.size(44.dp)
                ) {
                    Icon(Icons.Rounded.ArrowBackIosNew, stringResource(R.string.back), Modifier.size(18.dp), chrome)
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Rounded.Gesture, null, Modifier.size(19.dp), chromeSoft)
                    BasicText(
                        stringResource(R.string.sig_draw_title),
                        style = TextStyle(chrome, 18.sp, FontWeight.Bold, letterSpacing = 0.2.sp)
                    )
                }

                LiquidIconButton(
                    onClick = { if (strokes.isNotEmpty()) strokes.removeAt(strokes.lastIndex) },
                    backdrop = backdrop,
                    surfaceColor = chromeChip,
                    modifier = Modifier.size(44.dp)
                ) {
                    // Subtle when there's nothing to undo.
                    Icon(
                        Icons.Rounded.Undo, stringResource(R.string.undo), Modifier.size(20.dp),
                        chrome.copy(if (strokes.isEmpty()) 0.32f else 1f)
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            // Light control tray: ink colours (no outline rings — they read cleanly on
            // the light surface) and a liquid-glass thickness slider.
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(trayColor)
                    .border(1.dp, cardBorder, RoundedCornerShape(22.dp))
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Ink colour beads — plain, no outline circle.
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    signatureColors.forEach { color ->
                        val isSelected = selectedColor == color
                        // Springy grow on selection instead of a hard size jump — the bead reads as
                        // a physical thing you press, matching the rest of the liquid chrome.
                        val beadSize by animateDpAsState(
                            if (isSelected) 40.dp else 30.dp,
                            spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMediumLow),
                            label = "beadSize"
                        )
                        LiquidIconButton(
                            onClick = {
                                selectedColor = color
                                if (strokes.isNotEmpty()) {
                                    strokes.indices.forEach { idx ->
                                        strokes[idx] = strokes[idx].copy(color = color)
                                    }
                                }
                            },
                            backdrop = backdrop,
                            surfaceColor = color,
                            modifier = Modifier.size(beadSize)
                        ) {
                            if (isSelected) Icon(Icons.Rounded.Check, null, Modifier.size(17.dp), Color.White)
                        }
                    }
                }

                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(1.dp)
                        .background(Color.Black.copy(0.07f))
                )

                // Thickness: liquid-glass slider with a live ink-dot preview.
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        Modifier.size(22.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier
                                .size((selectedWidth * 1.1f).dp.coerceIn(4.dp, 20.dp))
                                .clip(CircleShape)
                                .background(selectedColor)
                        )
                    }
                    LiquidSlider(
                        value = { selectedWidth },
                        onValueChange = { selectedWidth = it.coerceIn(2f, 20f) },
                        valueRange = 2f..20f,
                        visibilityThreshold = 0.1f,
                        backdrop = backdrop,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // Signature canvas
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xFFF7F7F3))
                    .border(1.dp, Color.Black.copy(0.10f), RoundedCornerShape(20.dp))
                    .onSizeChanged { canvasSize = it }
                    .pointerInput(selectedColor, selectedWidth) {
                        detectDragGestures(
                            onDragStart = { start ->
                                currentStroke = listOf(start)
                            },
                            onDrag = { change, _ ->
                                change.consume()
                                currentStroke = currentStroke + change.position
                            },
                             onDragEnd = {
                                if (currentStroke.size > 1) {
                                    strokes.add(StrokeItem(currentStroke, selectedColor, selectedWidth))
                                }
                                currentStroke = emptyList()
                            },
                            onDragCancel = { currentStroke = emptyList() }
                        )
                    }
            ) {
                // Empty-canvas guides: a subtle centered "Sign here", plus a faint
                // signature baseline with an × marker near the lower third.
                if (strokes.isEmpty() && currentStroke.isEmpty()) {
                    BasicText(
                        stringResource(R.string.sig_hint),
                        style = TextStyle(Color.Black.copy(0.20f), 14.sp, FontWeight.Medium),
                        modifier = Modifier.align(Alignment.Center)
                    )
                    Row(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 44.dp)
                            .fillMaxWidth(0.84f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BasicText("✕", style = TextStyle(Color.Black.copy(0.22f), 16.sp, FontWeight.Bold))
                        Box(
                            Modifier
                                .weight(1f)
                                .height(1.dp)
                                .clip(RoundedCornerShape(50))
                                .background(Color.Black.copy(0.14f))
                        )
                    }
                }

                Canvas(Modifier.fillMaxSize()) {
                    // Draw completed strokes
                    for (item in strokes) {
                        val stroke = item.points
                        if (stroke.size < 2) continue
                        val strokeStyle = Stroke(
                            width = item.width,
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                        val path = Path()
                        path.moveTo(stroke[0].x, stroke[0].y)
                        for (i in 1 until stroke.size) {
                            if (i == 1 || i == stroke.size - 1) {
                                path.lineTo(stroke[i].x, stroke[i].y)
                            } else {
                                val mid = Offset(
                                    (stroke[i].x + stroke[i + 1].x) / 2f,
                                    (stroke[i].y + stroke[i + 1].y) / 2f
                                )
                                path.quadraticTo(stroke[i].x, stroke[i].y, mid.x, mid.y)
                            }
                        }
                        drawPath(path, item.color, style = strokeStyle)
                    }
                    // Draw live stroke
                    if (currentStroke.size >= 2) {
                        val strokeStyle = Stroke(
                            width = selectedWidth,
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                        val path = Path()
                        path.moveTo(currentStroke[0].x, currentStroke[0].y)
                        currentStroke.drop(1).forEach { path.lineTo(it.x, it.y) }
                        drawPath(path, selectedColor, style = strokeStyle)
                    }
                }
            }

            // Saved Signatures row if available
            if (savedSignatures.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                BasicText(
                    stringResource(R.string.sig_saved_title),
                    style = TextStyle(chrome.copy(0.6f), 12.sp, FontWeight.SemiBold, letterSpacing = 0.3.sp)
                )
                Row(
                    Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState())
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    savedSignatures.forEach { savedBmp ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .pointerInput(savedBmp.file) {
                                    detectTapGestures(
                                        onTap = {
                                            val safeBmp = if (savedBmp.bitmap.config == Bitmap.Config.HARDWARE || !savedBmp.bitmap.isMutable) {
                                                savedBmp.bitmap.copy(Bitmap.Config.ARGB_8888, true)
                                            } else {
                                                savedBmp.bitmap
                                            }
                                            onSignatureCaptured(safeBmp)
                                        },
                                        // Long-press → ask to delete this saved signature.
                                        onLongPress = { signatureToDelete = savedBmp }
                                    )
                                }
                                .padding(2.dp)
                        ) {
                            // Preview the actual signature ink on a light "paper" tile so
                            // the dark ink reads (matches the signing surface).
                            Box(
                                Modifier
                                    .size(84.dp, 50.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFFF7F7F3))
                                    // A dark hairline reads on the light paper tile; the old white
                                    // border was invisible against it.
                                    .border(1.dp, Color.Black.copy(0.08f), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                androidx.compose.foundation.Image(
                                    bitmap = savedBmp.bitmap.asImageBitmap(),
                                    contentDescription = savedBmp.name,
                                    modifier = Modifier.fillMaxSize().padding(6.dp),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Fit
                                )
                            }
                            BasicText(
                                savedBmp.name,
                                style = TextStyle(chrome.copy(0.7f), 10.sp, FontWeight.Medium),
                                maxLines = 1
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            // Bottom draw actions. Name entry is a floating overlay (below) so the
            // keyboard never displaces this layout.
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val hasInk = strokes.isNotEmpty()
                // Secondary, subdued when there's nothing to clear.
                LiquidButton(
                    onClick = { if (hasInk) { strokes.clear(); currentStroke = emptyList() } },
                    backdrop = backdrop,
                    surfaceColor = chrome.copy(if (hasInk) 0.10f else 0.04f),
                    modifier = Modifier.weight(1f)
                ) {
                    BasicText(
                        stringResource(R.string.sig_clear),
                        style = TextStyle(chrome.copy(if (hasInk) 0.85f else 0.32f), 15.sp, FontWeight.Medium),
                        modifier = Modifier.padding(vertical = 9.dp)
                    )
                }

                LiquidButton(
                    onClick = {
                        if (strokes.isEmpty()) return@LiquidButton
                        val rawW = canvasSize.width.coerceAtLeast(200)
                        val rawH = canvasSize.height.coerceAtLeast(200)
                        val maxDim = 800f
                        val scale = kotlin.math.min(1f, maxDim / kotlin.math.max(rawW, rawH).toFloat())
                        val w = (rawW * scale).toInt().coerceIn(200, 1000)
                        val h = (rawH * scale).toInt().coerceIn(200, 1000)
                        try {
                            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                            val canvas = Canvas(bmp)
                            canvas.scale(scale, scale)
                            for (item in strokes) {
                                val stroke = item.points
                                if (stroke.size < 2) continue
                                val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                                    color = item.color.toArgb()
                                    style = Paint.Style.STROKE
                                    strokeWidth = item.width
                                    strokeCap = Paint.Cap.ROUND
                                    strokeJoin = Paint.Join.ROUND
                                }
                                val path = android.graphics.Path()
                                path.moveTo(stroke[0].x, stroke[0].y)
                                stroke.drop(1).forEach { path.lineTo(it.x, it.y) }
                                canvas.drawPath(path, paint)
                            }
                            pendingSignature = bmp
                            signatureName = ""
                            showNamePrompt = true
                        } catch (e: Throwable) {
                            e.printStackTrace()
                        }
                    },
                    backdrop = backdrop,
                    tint = if (hasInk) Color(0xFF00C853) else Color(0xFF2E7D32).copy(0.55f),
                    modifier = Modifier.weight(1.7f)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(vertical = 9.dp)
                    ) {
                        Icon(Icons.Rounded.Check, null, Modifier.size(18.dp), Color.White)
                        BasicText(
                            stringResource(R.string.sig_use),
                            style = TextStyle(Color.White, 15.sp, FontWeight.SemiBold)
                        )
                    }
                }
            }
            }

        }
    }
        }

        SignatureNameDialog(
            visible = showNamePrompt,
            backdrop = padBackdrop,
            name = signatureName,
            focusRequester = nameFocusRequester,
            onNameChange = { signatureName = it },
            onDismiss = { showNamePrompt = false; pendingSignature = null },
            onSave = confirmSignatureName
        )

        // Delete a saved signature (from a long-press on its thumbnail).
        GlassDialog(
            visible = signatureToDelete != null,
            onDismiss = { signatureToDelete = null },
            backdrop = padBackdrop,
            title = stringResource(R.string.sig_delete_title),
            actions = {
                GlassDialogAction(stringResource(R.string.cancel), onClick = { signatureToDelete = null })
                GlassDialogAction(
                    stringResource(R.string.delete),
                    onClick = {
                        signatureToDelete?.let { sig ->
                            runCatching {
                                com.chethan616.clearpdf.data.repository.SignatureManager.deleteSignature(sig.file)
                            }
                            savedSignatures.remove(sig)
                        }
                        signatureToDelete = null
                    },
                    destructive = true
                )
            }
        ) {
            BasicText(
                stringResource(R.string.sig_delete_msg, lastDeleteName),
                style = TextStyle(chrome.copy(0.72f), 15.sp)
            )
        }
        }
    }
}

@Composable
private fun SignatureNameDialog(
    visible: Boolean,
    backdrop: Backdrop,
    name: String,
    focusRequester: FocusRequester,
    onNameChange: (String) -> Unit,
    onDismiss: () -> Unit,
    onSave: () -> Unit
) {
    val canSave = name.trim().isNotEmpty()
    val isDark = LocalIsDarkMode.current
    val chrome = if (isDark) Color.White else Color(0xFF15171C)
    val fieldBg = if (isDark) Color.White.copy(0.12f) else Color.Black.copy(0.05f)

    LaunchedEffect(visible) {
        if (visible) {
            delay(150)
            runCatching { focusRequester.requestFocus() }
        }
    }

    GlassDialog(
        visible = visible,
        onDismiss = onDismiss,
        backdrop = backdrop,
        title = stringResource(R.string.sig_name_title),
        dismissOnScrimTap = false,
        actions = {
            GlassDialogAction(stringResource(R.string.cancel), onClick = onDismiss)
            GlassDialogAction(
                stringResource(R.string.sig_name_save),
                onClick = { if (canSave) onSave() },
                primary = true,
                enabled = canSave,
                tint = LiquidGlassColors.Green
            )
        }
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(fieldBg)
                .padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Rounded.Gesture, null, Modifier.size(18.dp), chrome.copy(0.6f))
            Box(Modifier.weight(1f)) {
                if (name.isEmpty()) {
                    BasicText(
                        stringResource(R.string.sig_name_hint),
                        style = TextStyle(chrome.copy(0.45f), 14.sp)
                    )
                }
                BasicTextField(
                    value = name,
                    onValueChange = onNameChange,
                    textStyle = TextStyle(chrome, 14.sp),
                    cursorBrush = SolidColor(chrome),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { if (canSave) onSave() }),
                    modifier = Modifier
                        .fillMaxWidth()
                        .focusRequester(focusRequester)
                )
            }
        }
    }
}
