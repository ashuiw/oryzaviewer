# ClearPDF design system

**Read this before you build or change any UI.** It applies to every contributor and every AI agent.
The target is Apple's iOS 26/27 *Liquid Glass*, built on Android with kyant's `backdrop` library
(the vendored `backdrop/` module; only hand-port upstream fixes into it). It should look and feel
better than Adobe Acrobat: minimal, compact, playful, smooth, and lag-free.

---

## 1. Principles (in priority order)

1. **No lag.** 60/120 fps while scrolling, switching tabs and animating. A beautiful effect that drops
   frames is a bug. Measure on a real device before you call something done.
2. **One material.** Every surface is the same liquid glass, the material the title chips use
   (`GlassTitlePill`, e.g. "ClearPDF" on Home and "Settings" on Settings). Never introduce a flat card,
   a Material surface, a ripple or a grey slab.
3. **Minimal and compact.** Show less, but make it obvious. Don't nest panels inside panels. Prefer one
   glass panel holding rows over many small cards.
4. **Physical motion.** Everything moves on springs (easing plus damping). It overshoots a little,
   settles quickly and never wobbles more than once.
5. **One tap gives one haptic.** Every tappable thing ticks once. Nothing buzzes twice.
6. **Legible everywhere.** Ink adapts to what is behind the glass (light or dark page, theme), and
   dark reader mode is covered.

---

## 2. Glass: always use the primitives

| Need | Use | Notes |
|---|---|---|
| Button / pill | `LiquidButton` | Capsule, press deformation, long-press bloom, haptic. `tint` gives the vivid "Get it" button; `surfaceColor` gives a neutral pill. |
| Round icon button | `LiquidIconButton` | Size it with `Modifier.size(...)`. Its internal 40 dp is coerced to that size. |
| Title chip | `GlassTitlePill` | The reference material. |
| Section / panel | `Modifier.liquidGlassPanel(backdrop, uiSensor)` | 28 dp corners. **No shadow** (default). |
| Viewer chrome surface | `Modifier.viewerGlass(backdrop, color)` | Not composable. Reads `GlassSettings.style` at draw time. No shadow by default. |
| List row inside a panel | `Modifier.chipGlassSurface(...)` + `liquidRowClick {}` | See Recents rows. |
| Floating menu | `Modifier.glassMenu(backdrop, dark)` | Heavier frost so text stays legible. |
| Dropdown | `LiquidGlassDropdown` | The Aug-22 share-sheet dropdown, 1:1. Menu renders in `GlassOverlayHost`. |
| Dialog | `GlassDialog` + `GlassDialogAction` | Springy entrance, vivid primary, red destructive. |
| Segmented choice in a dialog | `GlassDialogSegmented` | Jelly thumb, slide to select. |
| Colour swatch (≤ ~10) | `LiquidIconButton(tint = c)` | Real glass bead. |
| Colour swatch (many) | `GlassBead` | Drawn glass bead with no backdrop pass, so it is cheap at 80+ swatches. |
| Tappable row | `Modifier.liquidRowClick { }` | Press spring, light glow from the touch point and a haptic. Never use a ripple. |
| Press light on a custom surface | `Modifier.liquidPressGlow(interaction, onLight)` | Driven by press interactions, so it never flashes when a scroll starts. |

**Never hand-roll `drawBackdrop` effect stacks.** Use `glassEffects(style, blurPx, refractionHeightPx,
refractionAmountPx)`, `glassTint(style)` and `glassHighlight(style)` from `GlassStyle.kt`. This keeps
every surface in line with **Settings → Liquid Glass** (blur, refraction height and amount, depth,
chromatic aberration, vibrancy, brightness, tint, highlight, corners, plus presets).

### Backdrop rules (these are why things look grey or flat)
- **Glass cannot refract the layer it is drawn in.** Floating UI must be a *sibling* of the
  captured content layer, not a child of it.
  - Use `GlassOverlay { }` (app-root portal) for menus and popovers.
  - On screens, things outside the scaffold sample `screenBackdrop.glass` (the live screen).
  - In the viewer, chrome samples `contentBackdrop`.
- Content inside a screen samples the wallpaper `backdrop`. With the default flat wallpaper this goes
  through the **flat fast path** (`FlatBackdrop.kt`): it produces the same pixels with no blur or lens
  pass. Keep the wallpaper-off layer a single solid fill.
- **Don't translate or scale a glass surface every frame** (entrances, drags). Its sample region moves,
  so blur and lens run again each frame. Fade glass; move the flat content inside it.

### Shadows
- **No shadows anywhere.** Every `drawBackdrop` call passes `shadow = null` (the library's default
  adds `Shadow.Default`, so omitting it brings a shadow back), and static `innerShadow`s are null.
  Shadows flickered on fade-in, dulled colours and cost frames.
- The one exception is press-time lens shading on slider, toggle and tab thumbs (an
  `InnerShadow` driven by press progress), which is part of the drag effect, not a shadow at rest.
- When glass fades, use `graphicsLayer { alpha = a; compositingStrategy = ModulateAlpha }`. Never use
  `Modifier.alpha`, because an offscreen layer clips the glass rim and highlight and they snap back in
  when the fade ends.

### Ink and tint
- Theme surfaces use `LiquidGlassColors.text/secondary(isDark)`.
- Over documents use `chipGlass(onLight)` and `chipInk(onLight)`, picking `onLight` from the content
  behind the control (the viewer's `bandLuminance`). **In dark reader mode, invert the luminance**
  (`1 - l`).
- **Every viewer control picks its own ink** (PDF, PPT, Word, spreadsheet, find bar): wrap it with
  `rememberAdaptiveInk(barInk)` and put `probe.modifier` first on the control. It reads the real
  pixels at the control's corners and beside its glyph (`ProvideScreenInk`, a scaled window copy,
  Android 8+), so two circles in one bar can differ. The bar's ink is only the fallback.
- Vivid actions use the per-screen accent (`ToolAccents`, `LiquidGlassColors`) via `tint`.

---

## 3. Motion

Use the shared springs in `GlassMotion` (or springs close to them):

| Spec | Use for |
|---|---|
| `GlassMotion.morph()` (0.58, 420) | Things that spring open: capsules, chevrons, thumbs |
| `GlassMotion.pop()` (0.45, 500) | Small things landing (icons, beads, toasts) |
| `GlassMotion.press()` (0.5, 700) | Value-driven press (prefer `rememberJellyPress`) |
| `GlassMotion.pressIn()` / `pressOut()` | Finger down (0.72, 900) / finger up (0.46, 420): one small overshoot past rest |
| `GlassMotion.wobble()` (0.42, 420) | The release jiggle on glass: X and Y squash out of phase, one visible swing |
| `GlassMotion.unfold()` / `unfoldLag()` / `fold()` | Menus: width (0.68, 420), height a beat behind (0.6, 340), close (1, 900) |
| `GlassMotion.settle()` / `fade()` | Alpha and layout. Critically damped, never bouncy |

**The user tunes it (Settings -> Liquid Glass -> Motion).** `MotionSettings` holds multipliers on
the numbers above (bounce, speed, press depth, release jiggle, drag stretch, long-press bloom) with
the profiles Normal (the design, exactly), Performance, Bouncy and Super springy. Bouncy
(`MotionStyle.Default`) runs until the user picks one, here or in the onboarding Appearance step,
and Reset returns to it. So every bouncing
spring goes through `MotionSettings.damping(designed)` / `stiffness(designed)`, and every press
size goes through the style. The `GlassMotion` springs already do. A new bouncing spring written
by hand must do the same. `settle`, `fade` and layout springs never bounce and ignore it.

**Press jelly (the iOS 27 feel).**
- Glass buttons (`LiquidButton`, `LiquidIconButton`) share `liquidPressTransform`. The button swells
  ~4 dp under the finger and leans toward a dragging finger. On release it springs back and jiggles once,
  about 2.5 dp, with X and Y out of phase.
- Flat pressables (rows, chips, toolbar items, menu actions) use `rememberJellyPress(interaction)` and
  read `jelly.scale` in `graphicsLayer`. Never use `animateFloatAsState(if (pressed) ...)`: in a scrolling
  list a quick tap's Press and Release arrive together, so the dip never shows.
- A tap shorter than `GlassMotion.MinPressMillis` (90 ms) still plays the whole press before releasing.
- The press light (the white glow under the finger, and the brighter glow of a long-press bloom) has
  its own critically damped spring. Never drive it from the bouncy press or bloom value: those ring
  through rest on release, and under Bouncy / Super springy every swing back up re-lit the glass, a
  shine on each jiggle. The shape jiggles; the light only fades.
- Menus unfold from their anchor with anisotropic scale (the width first, then the height) and fold back
  fast without a bounce. Rows cascade in behind the unfold.

- **Alpha never bounces.** Clamp it (`coerceIn(0f, 1f)`) or drive it with `settle`.
- Stagger lists about 20–30 ms per item, and cap the stagger so long lists don't trail.
- Use **one animation per element**. Derive scale, offset and alpha from one progress value rather
  than running three animations.
- Page pushes (Settings sub-pages): slide in from the side plus a fade on a 0.74 / 380 spring.
- Opening a document grows out of the tapped row (`DocumentOpenOrigin`) and settles back into it on
  Back.
- Long-press on a glass button blooms (grows ≤ ~14 dp, glows brighter, one LongPress haptic). A
  long-press **action** runs on release, never mid-press.
- A tapped back button (`GlassBackButton`) leaves after `GlassMotion.BackTapDelayMillis` (280 ms),
  so the press is seen first, as on iOS. Not longer: it must never read as lag. The system back
  gesture stays instant, and Reduce glass motion skips the wait.

---

## 4. Haptics
- `LiquidButton` and `LiquidIconButton` tick on tap (`ContextClick`). Rows tick through
  `liquidRowClick`.
- Picks and segment changes use `SegmentTick`. Sliding across options uses `SegmentFrequentTick`.
  Destructive actions use `LongPress`.
- `ThrottledHaptics` (installed at the app root) drops anything within 90 ms of the last tick and
  respects **Settings → Personalization → Haptic feedback**. Always use `LocalHapticFeedback`, never
  `View.performHapticFeedback`, so both apply.

---

## 5. Performance checklist (before you merge)
- [ ] No new `drawBackdrop` inside a list item that has many siblings. Use `GlassBead` or
      `chipGlassSurface` with the flat path, or one panel around the list.
- [ ] No snapshot-state writes from `onGloballyPositioned` that recompose large trees. Keep geometry
      in plain holders and read it at layout or draw time.
- [ ] Read animated values inside `graphicsLayer {}` or `drawBehind {}`, not in composition.
- [ ] No infinite animations while idle.
- [ ] No Material ripples (`indication = null` + `liquidRowClick` / `liquidPressGlow`).
- [ ] Glass entrances fade with `ModulateAlpha`; they never translate.
- [ ] Tested in light, dark and dark-reader modes, with the wallpaper on and off.

---

## 6. Layout and UX
- Holding a back button goes to the root of where you are: the library from a tool or document,
  the Settings index from a Settings page (never past it to Home).
- The tab bar is rebuilt whenever it reappears, so it must follow the current tab from its first
  frame; never skip the first selection change it sees.
- Settings is an iOS-style index of rows. Each topic opens its own page with a back button. Keep the
  root light: three small panels.
- Use 16 dp screen gutters and 12–16 dp between panels. Rows are 44–48 dp tall. Text is 13–16 sp:
  titles SemiBold, values in the secondary colour.
- Menus are compact: rows about 40 dp, menu width about 228 dp.
- Every popover, menu and sheet dismisses on Back and on an outside tap.
- Asks the app makes of people (the GitHub star prompt) wait for a calm moment after something
  went right: never at launch, mid-task, in a document opened from another app, or after a failure,
  and they back off when dismissed. `GitHubStarPromptManager` holds the rules; don't add fixed counts.
- Strings live in `values/strings.xml`. Never hard-code user-facing text.

---

## 7. Document viewers: reader mode is not the app theme

- A document's light/dark **reader mode** (the moon button, or Settings -> Dark pages in dark mode)
  is separate from the app theme. A light app can show dark pages and a dark app white ones.
- Inside a viewer, **chrome follows the document, never the app theme**:
  - PDF viewer: each bar samples the luminance behind it (`bandLuminance`, inverted in dark reader)
    and picks `chipGlass(onLight)` / `chipInk(onLight)`. It reads where the page really is
    (`pageFrame`), so book mode's letterbox and trimmed margins count as dark desk, not paper.
- Reading layouts are settings, not new screens: **Trim page margins** shows one document-wide
  content rect (`PdfViewerViewModel.contentCrop`), laid out with `trimToContent` so markups, links,
  form fields and selection keep their page coordinates; **Book mode** fits one page per screen,
  a fling or sideways swipe turns exactly one page. Both stay on the vertical list.
- Gestures on a page (moving a markup, a list box) consume their pointer; the viewer's pan skips
  a one-finger drag a page child has claimed.
  - Word editor and spreadsheet: the screen provides `LocalIsDarkMode = reader mode` to everything
    inside it and draws its own desk (light grey `#E3E4E9`, near-black `#0D0D0F`) behind the pages,
    so every glass control, dropdown menu, dock, dialog and the status-bar icons follow the paper.
- Chrome that sits on the document beside the clear glass circles (title pill, page capsule,
  ribbon dropdown triggers and steppers) is **clear glass too**: `surfaceColor = Color.Transparent`
  / `viewerGlass(backdrop, Color.Transparent)`, never a `chipGlass` frost. A frost reads as a grey
  slab over pictures and makes the chip look like a different material from the buttons beside it.
  An open dropdown menu keeps its frost (`LiquidGlassDropdown` falls back to the theme frost when
  its trigger is clear), because rows of text need it.
- The find bar is the shared `PdfSearchBar`: it samples the live page layer (`contentBackdrop` /
  `screenBackdrop.content`), clear surface, adaptive ink. Never give it only the wallpaper.
- **Night colours** come from `NightPaper` (Gander's matrix: invert + 180 degree hue turn), so a blue
  heading stays blue. Never use a plain RGB invert. Pictures: a photograph is drawn as printed; a
  scan or figure that `NightPaper.looksLikePaper` turns over with the page. PDF/PPTX pages find
  their pictures with `PdfImageRegions` and redraw photographs unfiltered (also in zoom tiles).
- The reader's bottom circles (editor tools, auto-scroll, the open/share morph) are 44 dp with
  20 dp icons, the Word editor's size, in the PDF and PowerPoint viewers too. The morph grows to
  twice its size while armed. Settings -> Personalization -> Swap share and open makes the tap
  share and the hold-and-swipe open; the ink still follows what is behind it.
- The Word editor's PDF and Print buttons make the PDF from the editor's own pages
  (`DocxPdfWriter`: same styles, labels, pictures, tables and Word's page breaks, real text), or
  from the Office engine when it is installed. Never the old web-preview converter, whose output
  looks like the previous viewer.
- Word documents open as pages, desktop-like: true proportions and margins, fit to width, pinch to
  zoom (the page relays out sharp, it is never bitmap-scaled), Word's own page breaks.

